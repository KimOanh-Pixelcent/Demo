<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/includes
 * @author     Your Name <email@example.com>
 */
class Inventory_Cms {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Inventory_Cms_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $inventory_cms    The string used to uniquely identify this plugin.
	 */
	protected $inventory_cms;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'INVENTORY_CMS_VERSION' ) ) {
			$this->version = INVENTORY_CMS_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->inventory_cms = 'inventory-cms';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Inventory_Cms_Loader. Orchestrates the hooks of the plugin.
	 * - Inventory_Cms_i18n. Defines internationalization functionality.
	 * - Inventory_Cms_Admin. Defines all hooks for the admin area.
	 * - Inventory_Cms_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-inventory-cms-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-inventory-cms-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-inventory-cms-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-inventory-cms-public.php';

		$this->loader = new Inventory_Cms_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Inventory_Cms_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Inventory_Cms_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Inventory_Cms_Admin( $this->get_inventory_cms(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action( 'admin_footer', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'init', $plugin_admin, 'add_pages', 0);
		$this->loader->add_action( 'admin_menu', $plugin_admin, 'add_submenu_plugin');
		$this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'add_meta_box_filter');
		$this->loader->add_action( 'wp_ajax_bt_inventory_ajax_field_data', $plugin_admin, 'handle_ajax_request_field_data');
		$this->loader->add_action( 'save_post_inventory', $plugin_admin, 'save_post_callback' );
		$this->loader->add_action( 'widgets_init', $plugin_admin, 'register_widgets_init' );
		$this->loader->add_action( 'wp_ajax_submit_action_send_mail_more_info', $plugin_admin, 'handle_submit_form_more_info');
		$this->loader->add_action( 'wp_ajax_nopriv_submit_action_send_mail_more_info', $plugin_admin, 'handle_submit_form_more_info');
		$this->loader->add_action( 'admin_post_nopriv_submit_action_send_mail_more_info', $plugin_admin, 'handle_submit_form_more_info');
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Inventory_Cms_Public( $this->get_inventory_cms(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts_head' );
		$this->loader->add_action( 'wp_footer', $plugin_public, 'enqueue_scripts_footer' );
		$this->loader->add_filter( 'single_template', $plugin_public, 'bt_inventory_single_template_layout');
		$this->loader->add_action( 'template_redirect', $plugin_public, 'my_template_redirect');
		$this->loader->add_action( 'generate_rewrite_rules', $plugin_public, 'my_add_rewrite_rules');
		$this->loader->add_filter( 'pre_get_document_title', $plugin_public, 'custom_page_title');
		$this->loader->add_action( 'init', $plugin_public, 'customRSS');

		$this->loader->add_action( 'wp_ajax_action_get_inventory', $plugin_public, 'action_get_inventory');
		$this->loader->add_action( 'wp_ajax_nopriv_action_get_inventory', $plugin_public, 'action_get_inventory');

		add_shortcode("render-content", array($plugin_public, "bt_inventory_single_template_content"));
		add_shortcode("render-content-search", array($plugin_public, "bt_inventory_single_template_content_search"));
		add_shortcode("simple-search", array($plugin_public, "simple_search_shortcode"));

		add_shortcode("latest-boats", array($plugin_public, "latest_boats_shortcode"));
		add_shortcode("render-content-latest-boats", array($plugin_public, "bt_inventory_template_latest_boats"));

		$this->loader->add_action( 'init', $plugin_public, 'boat_register_session', 1);

		$this->loader->add_action( 'wp_ajax_action_get_inventory_latest', $plugin_public, 'action_get_inventory_latest');
		
		$this->loader->add_action( 'wp_ajax_nopriv_action_get_inventory_latest', $plugin_public, 'action_get_inventory_latest');


	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_inventory_cms() {
		return $this->inventory_cms;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Inventory_Cms_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
