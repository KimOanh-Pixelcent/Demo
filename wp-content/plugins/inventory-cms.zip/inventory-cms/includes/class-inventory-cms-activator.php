<?php

/**
 * Fired during plugin activation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/includes
 * @author     Your Name <email@example.com>
 */
class Inventory_Cms_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public function activate() {
		global $wpdb;
		# table wp_bt_inventory_setting
		$bt_inventory_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
		$this->add_table($bt_inventory_setting, "CREATE TABLE `". $bt_inventory_setting . "` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`api_key` text DEFAULT NULL,
			 	`slug` varchar(255) DEFAULT NULL,
			 	`slug_single` varchar(255) DEFAULT NULL,
			 	`name_default` varchar(255) DEFAULT NULL,
			 	`row_limit` int(11) DEFAULT 10,
			 	`filter_position` tinyint(4) DEFAULT 1 COMMENT '1: Left position\r\n2: Top position',
			 	`primary_color` varchar(30) DEFAULT NULL,
 				`primary_color_btn` varchar(30) DEFAULT NULL,
 				`type_recaptcha` tinyint(4) NOT NULL DEFAULT 2,
			 	`site_key_recaptcha_2` varchar(255) DEFAULT NULL,
				`secret_key_recaptcha_2` varchar(255) DEFAULT NULL,
				`site_key_recaptcha_3` varchar(255) DEFAULT NULL,
				`secret_key_recaptcha_3` varchar(255) DEFAULT NULL,
			 	`username_smtp` varchar(191) DEFAULT NULL,
 				`password_smtp` varchar(191) DEFAULT NULL,
			 	`from_name` varchar(191) DEFAULT NULL,
				`from_email` varchar(191) DEFAULT NULL,
				`subject_email` varchar(191) DEFAULT NULL,
				`message_email` text DEFAULT NULL,
				`notice_thanks` varchar(255) DEFAULT NULL,
				`single_params` varchar(255) DEFAULT NULL,
				`single_attributes` text DEFAULT NULL,
				`single_disclaimer` text DEFAULT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_page
		$bt_inventory_page_detail = $wpdb->prefix . (defined( 'TABLE_PAGE_DETAIL' ) && TABLE_PAGE_DETAIL != '' ? TABLE_PAGE_DETAIL : 'bt_inventory_page_detail');
		$this->add_table($bt_inventory_page_detail, "CREATE TABLE `". $bt_inventory_page_detail ."` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`post_id` varchar(255) NOT NULL,
			 	`post_row_limit` int(11) DEFAULT 10,
			 	`post_filter` text DEFAULT NULL,
			 	`post_filter_position` tinyint(4) DEFAULT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_field
		$bt_inventory_field = $wpdb->prefix . (defined( 'TABLE_FIELD' ) && TABLE_FIELD != '' ? TABLE_FIELD : 'bt_inventory_field');
		$this->add_table($bt_inventory_field, "CREATE TABLE `". $bt_inventory_field ."` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`field_key` varchar(255) NOT NULL,
			 	`field_key_api` varchar(255) DEFAULT NULL,
			 	`field_value` text NOT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_attributes
		$bt_inventory_attributes = $wpdb->prefix . (defined( 'TABLE_ATTRIBUTE' ) && TABLE_ATTRIBUTE != '' ? TABLE_ATTRIBUTE : 'bt_inventory_attributes');
		$this->add_table($bt_inventory_attributes, "CREATE TABLE `". $bt_inventory_attributes ."` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`field_key` varchar(255) NOT NULL,
			 	`field_value` text NOT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_page_filter_options
		$bt_inventory_page_filter_options = $wpdb->prefix . (defined( 'TABLE_PAGE_FILTER_OPTIONS' ) && TABLE_PAGE_FILTER_OPTIONS != '' ? TABLE_PAGE_FILTER_OPTIONS  : 'bt_inventory_page_filter_options');
		$this->add_table($bt_inventory_page_filter_options, "CREATE TABLE `". $bt_inventory_page_filter_options ."`  (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`post_id` int(11) NOT NULL,
			 	`field_id` int(11) NOT NULL,
			 	`sort` int(11) NOT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_page_sort_options
		$bt_inventory_page_sort_options = $wpdb->prefix . (defined( 'TABLE_PAGE_SORT_OPTIONS' ) && TABLE_PAGE_SORT_OPTIONS != '' ? TABLE_PAGE_SORT_OPTIONS : 'bt_inventory_page_sort_options');
		$this->add_table($bt_inventory_page_sort_options, "CREATE TABLE `". $bt_inventory_page_sort_options ."` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`post_id` int(11) NOT NULL,
			 	`field_id` int(11) NOT NULL,
			 	`sort` int(11) NOT NULL,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

		# table wp_bt_inventory_form_submits
		$bt_inventory_form_submits = $wpdb->prefix . (defined( 'TABLE_FORM_SUBMITS' ) && TABLE_FORM_SUBMITS != '' ? TABLE_FORM_SUBMITS : 'bt_inventory_form_submits');
		$this->add_table($bt_inventory_form_submits, "CREATE TABLE `". $bt_inventory_form_submits ."` (
			 	`id` int(11) NOT NULL AUTO_INCREMENT,
			 	`first_name` varchar(191) NOT NULL,
			 	`last_name` varchar(191) NOT NULL,
			 	`phone` varchar(20) DEFAULT NULL,
			 	`email` varchar(191) NOT NULL,
			 	`description` text NOT NULL,
			 	`date_submit` datetime DEFAULT NULL,
			 	`is_send` tinyint(2) NOT NULL DEFAULT 1,
			 	PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");


		#insert data for table wp_bt_inventory_field
		$data_fields = $wpdb->get_results("SELECT * FROM " . $bt_inventory_field);
		if(count($data_fields) <= 0) {
			$inser_query_field = "INSERT INTO " . $bt_inventory_field . " (field_key, field_value, field_key_api) VALUES ('make', 'Make', 'MakeStringExact'), ('model', 'Model', 'ModelExact'), ('boattype', 'Boat Type', 'BoatClassCode'), ('condition', 'Condition', 'SaleClassCode'), ('hullmaterial', 'Hull material', 'BoatHullMaterialCode'), ('location', 'Location', 'BoatLocation'), ('year', 'Model Year', 'ModelYear'), ('length', 'Boat Length', 'NormNominalLength'), ('price', 'Price', 'NormPrice')";
			$this->insert_data_table($bt_inventory_field, $inser_query_field);
		}

		#insert data for table wp_bt_inventory_attributes
		$data_fields = $wpdb->get_results("SELECT * FROM " . $bt_inventory_attributes);
		if(count($data_fields) <= 0) {
			$inser_query_field = "INSERT INTO " . $bt_inventory_attributes . " (field_key, field_value) VALUES ('ModelYear', 'Year'), ('SaleClassCode', 'Condition'), ('BoatClassCode', 'Boat Type'), ('NominalLength', 'Length (LOA)'), ('Make', 'Engine Manufacturer'), ('Model', 'Engine'), ('BoatLocation', 'Location'), ('DriveUp', 'Min Draft'), ('FuelTankCapacityMeasure', 'Fuel Capacity'), ('DryWeightMeasure', 'Dry Weight'), ('BeamMeasure', 'Beam'), ('TotalEnginePowerQuantity', 'Max HP'), ('Hours', 'Boat Hours'), ('BoatHullMaterialCode', 'Hull Type')";
			$this->insert_data_table($bt_inventory_attributes, $inser_query_field);
		}
		
		#insert data for table wp_bt_inventory_setting
		$this->insert_data_table_setting();

		#insert data for page inventory default
		$this->insert_data_page_default();
	}

	public function insert_data_page_default() {
		global $wpdb;
		#filter
		$data_insert_filter = array(
			array(
				"post_id"  => 0,
				"field_id" => 2,
				"sort"     => 1
			),
			array(
				"post_id"  => 0,
				"field_id" => 5,
				"sort"     => 2
			),
			array(
				"post_id"  => 0,
				"field_id" => 1,
				"sort"     => 3
			),
			array(
				"post_id"  => 0,
				"field_id" => 4,
				"sort"     => 4
			),
			array(
				"post_id"  => 0,
				"field_id" => 6,
				"sort"     => 5
			),
			array(
				"post_id"  => 0,
				"field_id" => 7,
				"sort"     => 6
			),
			array(
				"post_id"  => 0,
				"field_id" => 8,
				"sort"     => 7
			),
			array(
				"post_id"  => 0,
				"field_id" => 9,
				"sort"     => 8
			)
		);

		$bt_inventory_page_filter_options = $wpdb->prefix . (defined( 'TABLE_PAGE_FILTER_OPTIONS' ) && TABLE_PAGE_FILTER_OPTIONS != '' ? TABLE_PAGE_FILTER_OPTIONS  : 'bt_inventory_page_filter_options');

		foreach ($data_insert_filter as $data) {
			$item = $wpdb->get_row("SELECT id FROM " . $bt_inventory_page_filter_options . " WHERE post_id = " . $data['post_id'] . " AND field_id = " . $data['field_id']);
			if(empty($item)) {
				$wpdb->insert($bt_inventory_page_filter_options, $data);
			}
		}

		#sort
		$data_insert_filter = array(
			array(
				"post_id"  => 0,
				"field_id" => 7,
				"sort"     => 1
			),
			array(
				"post_id"  => 0,
				"field_id" => 9,
				"sort"     => 2
			)
		);

		$bt_inventory_page_sort_options = $wpdb->prefix . (defined( 'TABLE_PAGE_SORT_OPTIONS' ) && TABLE_PAGE_SORT_OPTIONS != '' ? TABLE_PAGE_SORT_OPTIONS : 'bt_inventory_page_sort_options');

		foreach ($data_insert_filter as $data) {
			$item = $wpdb->get_row("SELECT id FROM " . $bt_inventory_page_sort_options . " WHERE post_id = " . $data['post_id'] . " AND field_id = " . $data['field_id']);
			if(empty($item)) {
				$wpdb->insert($bt_inventory_page_sort_options, $data);
			}
		}
	}

	public function insert_data_table_setting() {
		global $wpdb;
		$bt_inventory_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
		$check_table = $this->check_exists_table($bt_inventory_setting);
		if($check_table) {
			$setting = $wpdb->get_row("SELECT * FROM " . $bt_inventory_setting . " WHERE id = 1");
			if(empty($setting)) {
				$wpdb->insert($bt_inventory_setting, array(
					'api_key' 			=> '',
					'slug'	  			=> 'inventory',
					'slug_single'	  	=> 'boats',
					'name_default' 		=> 'Inventory',
					'row_limit' 		=> 10,
					'primary_color' 	=> '#31a3c6',
					'primary_color_btn' => '#133c68',
					'notice_thanks' 	=> 'Your submission has been received, thank you for contacting us.',
					'single_params' 	=> 'a:3:{i:0;s:15:"MakeStringExact";i:1;s:10:"ModelExact";i:2;s:9:"ModelYear";}',
					'single_attributes' => 'a:14:{i:0;s:9:"ModelYear";i:1;s:13:"SaleClassCode";i:2;s:13:"BoatClassCode";i:3;s:13:"NominalLength";i:4;s:4:"Make";i:5;s:5:"Model";i:6;s:12:"BoatLocation";i:7;s:7:"DriveUp";i:8;s:23:"FuelTankCapacityMeasure";i:9;s:16:"DryWeightMeasure";i:10;s:11:"BeamMeasure";i:11;s:24:"TotalEnginePowerQuantity";i:12;s:5:"Hours";i:13;s:20:"BoatHullMaterialCode";}',
					'single_disclaimer' => 'Fish Tale offers the details of this vessel in good faith but cannot guarantee or warrant the accuracy of this information nor warrant the condition of the vessel. A buyer should instruct his agents, or his surveyors, to investigate such details as the buyer desires validated. This vessel is offered subject to prior sale, price change, or withdrawal without notice.',
				));
			}
		}
	}

	public function add_table($name_table, $table_query) {
		global $wpdb;
		if($wpdb->get_var("SHOW TABLES LIKE '".$name_table."'") != $name_table) {
			require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($table_query);
		}
	}

	public function insert_data_table($name_table, $insert_query) {
		global $wpdb;
		if($wpdb->get_var("SHOW TABLES LIKE '".$name_table."'") == $name_table) {
			$wpdb->query($insert_query);
		}
	}

	public function check_exists_table($name_table) {
		global $wpdb;
		if($wpdb->get_var("SHOW TABLES LIKE '".$name_table."'") != $name_table) {
			return false;
		}
		return true;
	}
}
