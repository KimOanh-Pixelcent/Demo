<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Inventory_Cms
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

function drop_table() {
	global $wpdb;
	$table_field = $wpdb->prefix . (defined( 'TABLE_FIELD' ) && TABLE_FIELD != '' ? TABLE_FIELD : 'bt_inventory_field');
	$table_attributes = $wpdb->prefix . (defined( 'TABLE_FIELD' ) && TABLE_ATTRIBUTE != '' ? TABLE_ATTRIBUTE : 'bt_inventory_attributes');
	$table_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
	$table_page_detail = $wpdb->prefix . (defined( 'TABLE_PAGE_DETAIL' ) && TABLE_PAGE_DETAIL != '' ? TABLE_PAGE_DETAIL : 'bt_inventory_page_detail');
	$table_form_submits = $wpdb->prefix . (defined( 'TABLE_FORM_SUBMITS' ) && TABLE_FORM_SUBMITS != '' ? TABLE_FORM_SUBMITS : 'bt_inventory_form_submits');
	$table_page_sort_options = $wpdb->prefix . (defined( 'TABLE_PAGE_SORT_OPTIONS' ) && TABLE_PAGE_SORT_OPTIONS != '' ? TABLE_PAGE_SORT_OPTIONS : 'bt_inventory_page_sort_options');
	$table_page_filter_options = $wpdb->prefix . (defined( 'TABLE_PAGE_FILTER_OPTIONS' ) && TABLE_PAGE_FILTER_OPTIONS != '' ? TABLE_PAGE_FILTER_OPTIONS  : 'bt_inventory_page_filter_options');

	$tables = array($table_field, $table_attributes, $table_setting, $table_page_detail, $table_form_submits, $table_page_sort_options, $table_page_filter_options);

	foreach($tables as $table) {
		$wpdb->query("DROP TABLE IF EXISTS {$table}");
	}
	
}

drop_table();