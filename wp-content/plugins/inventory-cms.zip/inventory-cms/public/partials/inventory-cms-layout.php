<?php
	#include wordpress header
	get_header();
	
	#adding short code to the page
	do_shortcode("[render-content]");

	#include wordpress header
	get_footer();
?>