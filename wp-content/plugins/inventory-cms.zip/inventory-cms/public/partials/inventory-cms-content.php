<?php
/**
 * Template Name: Inventory
 *
 */
global $wpdb;

#set class
$is_left = true;
$default_class = "archive-listing-filter-position-left";
$post_detail = null;
if(!empty($post)) {
	$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = {$post->ID}");
	if(!empty($post_detail) && !empty($post_detail->post_filter_position) && $post_detail->post_filter_position == 2) {
		$is_left = false;
		$default_class = "archive-listing-filter-position-top";
	}
}

if( 
	(empty($post) || empty($post_detail)) &&
	!empty($this->setting->filter_position) && $this->setting->filter_position == 2
) {
	$is_left = false;
	$default_class = "archive-listing-filter-position-top";
}

?>
<div class="bt-inventory-plugin">
	<div class="bti-container">
		<?php if(!empty($post) && !empty($post->post_content)) : ?>
			<div class="bti-row">
				<div class="bti-col-12">
					<?php 
						echo apply_filters('the_content', nl2br( $post->post_content ) );
					?>
				</div>
			</div>
		<?php endif ?>
		<div class="archive-listing-page <?php echo $default_class; ?>">
			<div class="bti-row">
				<div class="bti-col-12 bti-col-lg-12 bti-col-xl-3 classic-filter-row sidebar-sm-mg-bt bti-block <?php if($is_left == false) { echo 'bti-d-md-none'; } ?>">
					<?php $this->boat_filter();  ?>
					<?php 
						if($is_left == true) :
							if( is_active_sidebar( 'sidebar-bt-inventory-listing' ) ) : 
					?>
						<div class="bt-widget-sidebar single-boat bti-d-none bti-d-xl-block">
							<?php dynamic_sidebar( 'sidebar-bt-inventory-listing' ); ?>
						</div>
					<?php 
							endif;
						endif;
					?>
				</div>
				<div class="bti-col-12 bti-col-lg-12 <?php if($is_left == true) { echo 'bti-col-xl-9'; } ?>">
					<div class="">
						<div class="bti-row stm-car-listing-sort-units stm-modern-filter-actions align-items-end">
							<div class="bti-col-12 bti-col-md-12 bti-col-lg-12">
								<h1 id="maintitle"><?php 
									$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']; 
									if(!empty($post) && !empty($post->post_title)){ 
										echo $post->post_title; 
									}  
									else {
										$params = explode("/", $_SERVER["REQUEST_URI"]);
										if(end($params) == 'boat-search-results') {
											echo 'Search Results';
										} else {
											echo $setting->name_default; 
										}
									} ?>
								</h1>
							</div>
							<div class="bti-col-12 bti-col-md-5 bti-col-lg-5">
								<label for="stock">Search By Stock Number</label>
								<div class="stock-search">
									<input placeholder="Search:Stock#,Model,Manufacturer" type="text" name="stock" id="stock" class="bti-form-control"/>
									<button type="submit" id="btn-stock"><em class="fa fa-search stm-icon-search"></em></button>
								</div>
							</div>
							<div class="bti-col-12 bti-col-md-<?php if($is_left == true) { echo "5"; } else { echo "4"; } ?> bti-col-lg-5">
								<div class="stm-sort-by-options">
									<label for="sort">Sort By</label>
									<?php $this->boat_sort();  ?>
								</div>
							</div>
							<div class="bti-col-md-<?php if($is_left == true) { echo "2"; } else { echo "3"; } ?> bti-col-lg-2 bti-d-none bti-d-md-block">
								<div class="view-mode">
									<?php if($is_left == false) : ?>
										<span class="view-mode-box mode-filter">
											<i class="fa fa-filter"></i>
										</span>
									<?php endif; ?>

									<span class="view-mode-box" data-view="stm-grid" data-hide="stm-list">
										<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<rect x="3" y="3" width="7" height="7"></rect>
											<rect x="14" y="3" width="7" height="7"></rect>
											<rect x="14" y="14" width="7" height="7"></rect>
											<rect x="3" y="14" width="7" height="7"></rect>
										</svg>
									</span>
									<span class="view-mode-box active" data-view="stm-list"  data-hide="stm-grid">
										<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<line x1="8" y1="6" x2="21" y2="6"></line>
											<line x1="8" y1="12" x2="21" y2="12"></line>
											<line x1="8" y1="18" x2="21" y2="18"></line>
											<line x1="3" y1="6" x2="3" y2="6"></line>
											<line x1="3" y1="12" x2="3" y2="12"></line>
											<line x1="3" y1="18" x2="3" y2="18"></line>
										</svg>
									</span>
								</div>
							</div>

							<?php if($is_left == false) : ?>
								<div class="bti-col-12 classic-filter-row classic-filter-row-top sidebar-sm-mg-bt">
									<?php $this->boat_filter(false);  ?>
								</div>
							<?php endif; ?>
						</div>
						<!-- Container where list of boats will be displayed -->
						<div id="filterResult"></div>
						<!-- Spinning loader icon -->
						<div class="loader hidden"><i class="fa fa-spinner fa-spin">&nbsp;</i></a>
					</div>
				</div> 
			</div>

			<?php //wp_reset_postdata(); ?>
			</div>
		</div>
	</div>
</div>
	
<?php get_footer(); ?>

<script>
	jQuery(document).ready(function(){
		if(localStorage.getItem("save")){ // Determine if data needs to be saved or not - if user clicks within the page, save filters; if user navigates away from current page/filter, clear filters
			localStorage.removeItem("save");
		} else {
			localStorage.clear();
		}

		if(localStorage.getItem("backpage")){ // If the user clicked "back," display the correct page of listings
			var paged  = localStorage.getItem("backpage");
		} else {
			var paged = 1;
		}
		
		// Call boats from API
		ajaxfilter(paged);
		
		var currentpage = window.location.href;   
		var slug = '';
		var splittedStr = currentpage.split('/');
		slug = splittedStr[splittedStr.length - 2]; // save slug
	});
</script>
