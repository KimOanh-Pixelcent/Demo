<?php
/**
 * Template Name: Single Boat
 *
 */
 /* CUSTOM FUNCTION TO DISPLAY ONLY ONE BOAT USING INFORMATION FROM URL */
 	$msg = "Page doesn't exist.";
	function getInventory($api_key){
		if(empty($api_key)) {
			$msg = "API KEY does not exist. Please go to settings to enter your API KEY.";
			return null;
		}
		$pageurl = $_SERVER["REQUEST_URI"];
		$params = explode("/", $pageurl);
		$slug = end($params);
		if(empty($slug)) {
			$slug = $params[count($params) - 2];
		}

		$attributes = explode("-", $slug);
		$id = end($attributes); // Pull ID from URL params
		// Search APi for boat by ID
		$url = 'https://api.boats.com/inventory/?key=' . $api_key . '&id='. $id;
		$getInventory = wp_remote_get( $url, array(
		        'timeout'     => 120,
		        'httpversion' => '1.1',
		    ) 
		);
		$boats = $getInventory['body'];
		if ( is_wp_error( $getInventory ) ) {
			$error_message = $getInventory->get_error_message();
			echo "Something went wrong: $error_message";
		} else {
			$body = $getInventory['body'];
		} 
		$boats = json_decode($boats);	
		return $boats;
	}
	$api_key = !empty($setting) && !empty($setting->api_key) ? $setting->api_key : '';
	$disclaimer = !empty($setting) ? $setting->single_disclaimer : '';
	$attributes = !empty($setting) && !empty($setting->single_attributes) ? unserialize($setting->single_attributes) : [];
	$inventory = getInventory($api_key);
	$boats = $inventory->results;
?>
<?php 
	$description = "<meta name='description' content='Boat Details'>";
	$title = "Boat Details";
	if(!empty($boats) && !empty($boats[0])) {
		$title = $boats[0]->MakeStringExact . ' ' . $boats[0]->ModelExact . ' ' . $boats[0]->ModelYear;
		$description = mb_strimwidth( wp_strip_all_tags($boats[0]->GeneralBoatDescription[0]), 0, 150 );
		$description = "<meta name='description' content='" . $description . "'>";
	}	
	ob_start();
	get_header();
	$header = ob_get_clean();
	$header = preg_replace('#<title>(.*?)<\/title>#', '<title>' . $title . '</title>', $header);
	$header = preg_replace('#<meta name="description" content="(.*?)">#', '', $header);
	echo $description;
	echo $header;
?>

<div class="bt-inventory-plugin">
	<div class="bti-container single-boat archive-listing-page">
		<?php if(!empty($boats)) : ?>
			<div class="bti-row">
				<div class="bti-col-12 bti-col-xl-3 bti-d-none bti-d-xl-block">
					<div class="bti-inner">
						<div class="bti-wrapper">
							<div class="bti-content-element">
								<div class="bti-wrapper">
									<a href="javascript:void(0)" class="btn btn-single-boat backbtn"><i class="fa fa-long-arrow-left">&nbsp;</i> Back to Results</a>
									<button class="btn btn-single-boat printbtn">Print Details</button>
								</div>
							</div>
							<?php if( is_active_sidebar( 'sidebar-bt-inventory-detail' ) ) : ?>
							<div class="bt-widget-sidebar single-boat bti-d-none bti-d-xl-block">
								<?php dynamic_sidebar( 'sidebar-bt-inventory-detail' ); ?>
							</div>
						<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="bti-col-12 bti-col-xl-9">
				<?php foreach($boats as $boat): ?>
					<div class="bti-inner ">
						<div class="bti-wrapper">
							<div class="">
								<div class="clearfix stm-boats-single-top">
									<div class="bti-row title-row">
										<div class="bti-col-md-9"><h2 class="title"><?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?></h2></div>
										<div class="bti-col-md-3 text-right"><span class="fa fa-ship">&nbsp;</span> Listing # <strong><?php echo $boat->StockNumber; ?></strong></div>
									</div>
								</div>
							</div>
							<div class="stm-boats-featured-image ">
								<div class="stm-single-image" data-id="big-image-25553">
									<div class="stm-boats-single-price">
										<div class="single-car-prices">
											<div class="single-regular-price text-center">
												<span class="labeled">Our Price</span>
												<span class="h3"><?php $price = $boat->Price; if(!empty($price) and $price != 1){ echo '$'.number_format((float)$price, 0, '.', ','); } else { echo 'Call'; }?></span>
											</div>
										</div>
									</div>
									<?php $imgs = $boat->Images; ?>
									<a href="<?php echo esc_url($imgs[0]->Uri); ?>" class="stm_fancybox" rel="stm-car-gallery">
										<img width="1110" height="577" src="<?php echo esc_url($imgs[0]->Uri); ?>" class="img-responsive wp-post-image" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
									</a>
									<a class="gallery-button" href="#photogallery" title="View Gallery"><i class="stm-boats-icon-camera"></i> View Gallery</a>
								</div>
							</div>
							<div class="wpb_text_column wpb_content_element boat-content">
								<div class="wpb_wrapper">
									<?php echo $boat->GeneralBoatDescription[0]; ?>
								</div>
							</div>
							<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1520365552742  vc_custom_1520365552742">
								<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e6e6e6;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e6e6e6;" class="vc_sep_line"></span></span>
							</div>
							<?php echo do_shortcode("[boat_load_pdf boat_id='{$boat->DocumentID}']"); ?>
							<?php if(count($attributes)) { ?>
								<div class="stm-tech-infos">
									<div class="stm-tech-title">
										<i class="stm-icon-speedometr3" style="font-size:27px;"></i>
										<div class="title h5">Specifications</div>
									</div>
									<div class="bti-row">
										<div class="bti-col-md-6">
											<table>
												<tbody>
													<?php
														$is_float = false;
														if(is_float(count($attributes) / 2)) {
															$is_float = true;
														}
														$attributes_length_1 = round(count($attributes) / 2);
														for($i = 0; $i < $attributes_length_1; $i++ ) {
															$key = $attributes[$i];
															$flag = 0;
															if(!empty($fields[$key])) {
																$field_key = $fields[$key]->field_key;

																echo '<tr><td><span class="text-transform subtitle">'.$fields[$key]->field_value.'</span></td><td class="text-right"><span class="h6">';

																if($field_key == 'FuelTankCapacityMeasure') {
																	$flag = 1;
																 	echo str_replace("|"," ", $boat->$field_key);
																}

																if($field_key == 'BoatLocation') {
																	$flag = 1;
																	if(!empty($boat->$field_key->BoatCityName)) {
																		echo $boat->$field_key->BoatCityName;
																	}
																 	
																}

																if($field_key == 'BoatClassCode') {
																	$flag = 1;
																	if(!empty($boat->$field_key[0])) { 
																		echo $boat->$field_key[0]; 
																	}
																}
																
																if($field_key == 'Hours' || $field_key == 'Make' || $field_key == 'Model') {
																	$flag = 1;
																 	$y = 0;
																	foreach($boat->Engines as $engine) {
																		if(($field_key == 'Make' || $field_key == 'Model') && $y == 0) {
																			echo $engine->$field_key;
																			break;
																		}

																		$hours = '';
																		if(!empty($engine->$field_key)) {
																			$hours = $engine->$field_key;
																		}
																		 
																		if($y == 0) { 
																			if($hours == 0) { echo '0'; } 
																			else { echo $hours; } 
																		} 
																		$y++; 
																	}
																}

																if(!$flag && !empty($boat->$field_key)) {
																	echo $boat->$field_key;
																	
																}
																echo '</span></td></tr>';
															}
														}
													?>
												</tbody>
											</table>
										</div>
										<div class="bti-col-md-6">
											<table>
												<tbody>
													<?php
														$key_start = count($attributes) - $attributes_length_1;
														if($key_start != 0  && $key_start != count($attributes)) {
															if($is_float) $key_start += 1;
															for($i = $key_start; $i < count($attributes); $i++ ) {
																$key = $attributes[$i];
																$flag = 0;
																if(!empty($fields[$key])) {
																	$field_key = $fields[$key]->field_key;

																	echo '<tr><td><span class="text-transform subtitle">'.$fields[$key]->field_value.'</span></td><td class="text-right"><span class="h6">';

																	if($field_key == 'FuelTankCapacityMeasure' && !empty($boat->$field_key)) {
																		$flag = 1;
																	 	echo str_replace("|"," ", $boat->$field_key);
																	}

																	if($field_key == 'BoatLocation') {
																		$flag = 1;
																		if(!empty($boat->$field_key->BoatCityName)) {
																			echo $boat->$field_key->BoatCityName;
																		}
																	 	
																	}

																	if($field_key == 'BoatClassCode') {
																		$flag = 1;
																		if(!empty($boat->$field_key[0])) { 
																			echo $boat->$field_key[0]; 
																		}
																	}
																	
																	if($field_key == 'Hours' || $field_key == 'Make' || $field_key == 'Model') {
																		$flag = 1;
																	 	$y = 0;
																		foreach($boat->Engines as $engine) {
																			if(($field_key == 'Make' || $field_key == 'Model') && $y == 0) {
																				echo $engine->$field_key;
																				break;
																			}

																			$hours = '';
																			if(!empty($engine->$field_key)) {
																				$hours = $engine->$field_key;
																			}
																			 
																			if($y == 0) { 
																				if($hours == 0) { echo '0'; } 
																				else { echo $hours; } 
																			} 
																			$y++; 
																		}
																	}

																	if(!$flag && !empty($boat->$field_key)) {
																		echo $boat->$field_key;
																		
																	}
																	echo '</span></td></tr>';
																}
															}
														}
													?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							<?php } ?>
							<?php if(!empty($boat->EmbeddedVideo)):
								$vids = $boat->Videos;
							?>
							<div class="wpb_raw_code wpb_content_element wpb_raw_html stm-tech-infos">
								<div class="wpb_wrapper">
									<h3><em class="fa fa-video-camera">&nbsp;</em> Product Video</h3>
								</div>
							</div>
							<div class="boat-videos">
								<div class="stm-car-carousels">
									<div class="stm-big-car-gallery owl-carousel owl-theme owl-loaded">
										<?php if( strpos(esc_url( $vids->url[0] ),"youtube") != -1 || strpos(esc_url( $vids->url[0] ),"vimeo") != -1 || strpos(esc_url( $vids->url[0] ),"vzaar") != -1 ) : ?>
											<div class="item-video" style="height: 400px !important;">
												<a class="owl-video" href="<?php echo esc_url( $vids->url[0] ); ?>"></a>
											</div>
										<?php else : ?>
											<div class="owl-stage-outer">
												<div class="owl-stage">
													<div class="owl-item active center" data-video="<?php echo esc_url( $vids->url[0] ); ?>" style="width: 100%; margin-right: 0px;">
														<div class="item-video">
											            	<div class="owl-video-wrapper" style="height: auto !important;">
											            		<a class="owl-video" href="<?php echo esc_url( $vids->url[0] ); ?>" style="display: none;"></a>
												              	<a class="fancy-iframe" data-url="<?php echo esc_url( $vids->url[0] ); ?>">
																	<img src="<?php echo esc_url( $vids->thumbnailUrl[0] ); ?>" class="img-responsive" alt="Video preview" width="798" height="466" scale="2.5">
																</a>
												              	<div class="owl-video-play-icon"></div>
											              	</div>
											            </div> 
									            	</div>
												</div>
											</div>
										<?php endif; ?>
									</div>
								</div>
							</div>
							<?php endif; ?>
							
							<div class="wpb_raw_code wpb_content_element wpb_raw_html">
								<div class="wpb_wrapper">
									<h3 id="photogallery"><em class="stm-boats-icon-camera">&nbsp;</em> Photo Gallery</h3>
								</div>
							</div>
							<div class="boat-gallery ">
								<div class="bti-row">
									<?php $i = 1; foreach($imgs as $img){ ?>
									<div class="bti-col-md-4 bti-col-sm-4 bti-col-sm-6">
										<a href="<?php echo esc_url($img->Uri); ?>" class="stm_fancybox" rel="gallery" data-fancybox="images">
											<img src="<?php echo esc_url($img->Uri); ?>" width="255" height="132" scale="" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear . ' ' . $i; ?>" />
											<div class="overlay"><p><span class="fa fa-search-plus">&nbsp;</span></p><p>Enlarge Photo</p></div>
										</a>
									</div>
									<?php $i++; } ?>
								</div>
							</div>		
							<p style="margin-bottom: 35px;"><em><?php echo $disclaimer; ?></em></p>
						</div>
						
						</div>
					</div>
				<?php endforeach; ?>
				</div>
			<div class="clearfix"></div>
		<?php else : ?>
			<div class="bti-container">
				<div class="bti-row">
					<div class="bt-col-12">
						<h3><?php echo $msg; ?></h3>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
	<!-- html print -->
	<div class="bti-container-fluid bt-inventory-plugin single-boat single-boat-print bti-d-none" id="print-page">
		<div class="bti-row">
			<div class="bti-col-12">
			<?php foreach($boats as $boat): ?>
				<div class="bti-inner ">
					<div class="bti-wrapper">
						<dixv class="">
							<div class="clearfix stm-boats-single-top">
								<div class="bti-row title-row">
									<div class="bti-col-9"><h2 class="title"><?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?></h2></div>
									<div class="bti-col-3 text-right"><span class="fa fa-ship">&nbsp;</span> Listing # <strong><?php echo $boat->StockNumber; ?></strong></div>
								</div>
							</div>
						</div>
						<div class="stm-boats-featured-image">
							<div class="stm-single-image" data-id="big-image-25553">
								<div class="stm-boats-single-price">
									<div class="single-car-prices">
										<div class="single-regular-price text-center">
											<span class="labeled">Our Price</span>
											<span class="h3"><?php $price = $boat->Price; if(!empty($price) and $price != 1){ echo '$'.number_format((float)$price, 0, '.', ','); } else { echo 'Call'; }?></span>
										</div>
									</div>
								</div>
								<?php $imgs = $boat->Images; ?>
								<a href="#" rel="stm-car-gallery">
									<img width="1110" height="577" src="<?php echo esc_url($imgs[0]->Uri); ?>" class="img-responsive wp-post-image" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
								</a>
								<a class="gallery-button" href="#photogallery" title="View Gallery"><i class="stm-boats-icon-camera"></i> View Gallery</a>
							</div>
							<div class="stm-boats-single-content">
								<?php echo $boat->GeneralBoatDescription[0]; ?>
							</div>
						</div>
						<div class="vc_separator wpb_content_element vc_separator_align_center vc_sep_width_100 vc_sep_pos_align_center vc_separator_no_text vc_custom_1520365552742  vc_custom_1520365552742">
							<span class="vc_sep_holder vc_sep_holder_l"><span style="border-color:#e6e6e6;" class="vc_sep_line"></span></span><span class="vc_sep_holder vc_sep_holder_r"><span style="border-color:#e6e6e6;" class="vc_sep_line"></span></span>
						</div>
						<?php if(count($attributes)) { ?>
							<div class="stm-tech-infos">
								<div class="stm-tech-title">
									<i class="stm-icon-speedometr3"></i>
									<div class="title h5">Specifications</div>
								</div>
								<div class="bti-row">
									<div class="bti-col-6">
										<table>
											<tbody>
												<?php
													$attributes_length_1 = round(count($attributes) / 2);
													for($i = 0; $i < $attributes_length_1; $i++ ) {
														$key = $attributes[$i];
														$flag = 0;
														if(!empty($fields[$key])) {
															$field_key = $fields[$key]->field_key;

															echo '<tr><td><span class="text-transform subtitle">'.$fields[$key]->field_value.'</span></td><td class="text-right"><span class="h6">';

															if($field_key == 'FuelTankCapacityMeasure') {
																$flag = 1;
															 	echo str_replace("|"," ", $boat->$field_key);
															}

															if($field_key == 'BoatLocation') {
																$flag = 1;
																if(!empty($boat->$field_key->BoatCityName)) {
																	echo $boat->$field_key->BoatCityName;
																}
															 	
															}

															if($field_key == 'BoatClassCode') {
																$flag = 1;
																if(!empty($boat->$field_key[0])) { 
																	echo $boat->$field_key[0]; 
																}
															}
															
															if($field_key == 'Hours' || $field_key == 'Make' || $field_key == 'Model') {
																$flag = 1;
															 	$y = 0;
																foreach($boat->Engines as $engine) {
																	if(($field_key == 'Make' || $field_key == 'Model') && $y == 0) {
																		echo $engine->$field_key;
																		break;
																	}

																	$hours = '';
																	if(!empty($engine->$field_key)) {
																		$hours = $engine->$field_key;
																	}
																	 
																	if($y == 0) { 
																		if($hours == 0) { echo '0'; } 
																		else { echo $hours; } 
																	} 
																	$y++; 
																}
															}

															if(!$flag && !empty($boat->$field_key)) {
																echo $boat->$field_key;
																
															}
															echo '</span></td></tr>';
														}
													}
												?>
											</tbody>
										</table>
									</div>
									<div class="bti-col-6">
										<table>
											<tbody>
												<?php
														$key_start = count($attributes) - $attributes_length_1;
														if($key_start != 0  && $key_start != count($attributes)) {
															if($is_float) $key_start += 1;
															for($i = $key_start; $i < count($attributes); $i++ ) {
																$key = $attributes[$i];
																$flag = 0;
																if(!empty($fields[$key])) {
																	$field_key = $fields[$key]->field_key;

																	echo '<tr><td><span class="text-transform subtitle">'.$fields[$key]->field_value.'</span></td><td class="text-right"><span class="h6">';

																	if($field_key == 'FuelTankCapacityMeasure') {
																		$flag = 1;
																	 	echo str_replace("|"," ", $boat->$field_key);
																	}

																	if($field_key == 'BoatLocation') {
																		$flag = 1;
																		if(!empty($boat->$field_key->BoatCityName)) {
																			echo $boat->$field_key->BoatCityName;
																		}
																	 	
																	}

																	if($field_key == 'BoatClassCode') {
																		$flag = 1;
																		if(!empty($boat->$field_key[0])) { 
																			echo $boat->$field_key[0]; 
																		}
																	}
																	
																	if($field_key == 'Hours' || $field_key == 'Make' || $field_key == 'Model') {
																		$flag = 1;
																	 	$y = 0;
																		foreach($boat->Engines as $engine) {
																			if(($field_key == 'Make' || $field_key == 'Model') && $y == 0) {
																				echo $engine->$field_key;
																				break;
																			}

																			$hours = '';
																			if(!empty($engine->$field_key)) {
																				$hours = $engine->$field_key;
																			}
																			 
																			if($y == 0) { 
																				if($hours == 0) { echo '0'; } 
																				else { echo $hours; } 
																			} 
																			$y++; 
																		}
																	}

																	if(!$flag && !empty($boat->$field_key)) {
																		echo $boat->$field_key;
																		
																	}
																	echo '</span></td></tr>';
																}
															}
														}
													?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						<?php } ?>
						<?php if(!empty($boat->EmbeddedVideo)): ?>
						<div class="wpb_raw_code wpb_content_element wpb_raw_html stm-tech-infos">
							<div class="wpb_wrapper">
								<h3><em class="fa fa-video-camera">&nbsp;</em> Product Video</h3>
							</div>
						</div>
						<div class="boat-videos">
							<div class="stm-car-carousels">
								<div class="owl-carousel owl-theme owl-loaded">
									<div class="owl-stage-outer">
										<div class="owl-stage">
											<div class="owl-item active center" data-video="<?php echo esc_url( $vids->url[0] ); ?>" style="width: 100%; margin-right: 0px;">
												<div class="item-video">
									            	<div class="owl-video-wrapper" style="">
									            		<a class="owl-video" href="<?php echo esc_url( $vids->url[0] ); ?>" style="display: none;"></a>
										              	<a class="fancy-iframe" data-url="<?php echo esc_url( $vids->url[0] ); ?>">
															<img src="<?php echo esc_url( $vids->thumbnailUrl[0] ); ?>" class="img-responsive" alt="Video preview" width="798" height="466" scale="2.5">
														</a>
										              	<div class="owl-video-play-icon"></div>
									              	</div>
									            </div> 
							            	</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endif; ?>
						<p style="margin-bottom: 35px;"><em><?php echo $disclaimer; ?></em></p>
					</div>
					
					</div>
				</div>
			<?php endforeach; ?>
			</div>
	</div>
</div>
<?php get_footer(); ?>

<script type="text/javascript">
	(function ($) {
		jQuery(document).ready(function () {

			localStorage.removeItem("save");
			jQuery('body').mouseover(function() {
				if(localStorage.getItem("save")) {
					localStorage.removeItem("save");
				}
				
			});

			jQuery('body').mouseleave(function() {
				localStorage.setItem('save', true);
			});

			jQuery('.boat-content span').attr('style', 'font-weight: normal;'); // set font styling for content

			jQuery('.backbtn').on('click', function(e){
				localStorage.setItem('save', true);
				history.back();
				
			});

			jQuery(".printbtn").on("click", function() {
				jQuery("#print-page").printThis();
			});

			// Enable carousel
			var big_car = $('.stm-big-car-gallery');
			var flag_car = false;
			var duration_car = 800;

			var owlRtl_car = false;
			if( $('body').hasClass('rtl') ) {
				owlRtl_car = true;
			}
			
			big_car.owlCarousel({
				rtl: owlRtl_car,
				items: 1,
				smartSpeed: 800,
				dots: false,
				nav: false,
				margin:0,
				video:true,
				autoplay: false,
				loop: false,
				responsiveRefreshRate: 1000,
				touchDrag: false,
				mouseDrag: false,
			});

			var big = $('.stm-car-gallery');
			var flag = false;
			var duration = 800;

			var owlRtl = false;
			if( $('body').hasClass('rtl') ) {
				owlRtl = true;
			}
			
			big.owlCarousel({
				rtl: owlRtl,
				items: 1,
				smartSpeed: 800,
				dots: false,
				nav: false,
				margin:0,
				autoplay: false,
				loop: false,
				responsiveRefreshRate: 1000
			});

			wheelzoom(jQuery('.fancybox-image'));
			jQuery("a.stm_fancybox").fancybox({
				protect: true,
				smallBtn   : true,
				buttons : [
				    'zoom',
				    'thumbs',
				    'close'
			  	]
			});
			
		});
	})(jQuery);
	
</script>