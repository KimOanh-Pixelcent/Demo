<?php
/**
 * Template Name: Inventory latest boat
 *
 */
?>

<div class="bt-inventory-plugin">
	<div class="bti-container">
		<?php if(!empty($post) && !empty($post->post_content)) : ?>
			<div class="bti-row">
				<div class="bti-col-12">
					<?php 
						echo apply_filters('the_content', nl2br( $post->post_content ) );
					?>
				</div>
			</div>
		<?php endif ?>
		<div class="archive-listing-page archive-listing-filter-position-left">
			<div class="bti-row">
				<div class="bti-col-12 bti-col-lg-12">
					<div class="">
						<div class="bti-row stm-car-listing-sort-units stm-modern-filter-actions align-items-end bti-pd-0">
							<div class="bti-col-12 bti-col-md-12 bti-col-lg-12">
								<h1 id="maintitle">Latest boats</h1>
							</div>
							<div class="bti-col-12 bti-col-md-12 bti-col-lg-12">
								<span id="text-results"></span>
							</div>
						</div>
						<!-- Container where list of boats will be displayed -->
						<div id="filterResult"></div>
						<!-- Spinning loader icon -->
						<div class="loader hidden"><i class="fa fa-spinner fa-spin">&nbsp;</i></div>
					</div>
				</div> 
			</div>

			<?php //wp_reset_postdata(); ?>
			</div>
		</div>
	</div>
</div>
	
<?php get_footer(); ?>

<script>
	jQuery(document).ready(function(){
		if(localStorage.getItem("save")){
			localStorage.removeItem("save");
		} else {
			localStorage.clear();
		}

		if(localStorage.getItem("backpage")){
			var paged  = localStorage.getItem("backpage");
		} else {
			var paged = 1;
		}
		
		let lastestCondition = "<?php echo $_SESSION['condition'] ?>";
		let lastestLimit = "<?php echo $_SESSION['limit'] ?>";
		let lastestDisplay = "<?php echo $_SESSION['display'] ?>";

		localStorage.setItem('condition', lastestCondition); 
		localStorage.setItem('limit', lastestLimit); 
		localStorage.setItem('display', lastestDisplay); 

		// Call boats from API
		// ajaxfilter_latest(paged, lastestCondition, lastestLimit);
		ajaxfilter_latest(paged);
		
		var currentpage = window.location.href;   
		var slug = '';
		var splittedStr = currentpage.split('/');
		slug = splittedStr[splittedStr.length - 2];
	});
</script>
