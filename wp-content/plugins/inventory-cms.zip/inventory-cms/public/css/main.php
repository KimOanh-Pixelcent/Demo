<?php
	require_once('../../../../../wp-load.php');
	header("Content-type: text/css; charset: UTF-8");
	global $wpdb;
	$table_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
	$setting = $wpdb->get_row("SELECT * FROM {$table_setting} where id = 1");
	$primary_color = !empty($setting) && !empty($setting->primary_color) ? $setting->primary_color : '#31a3c6';
	$primary_color_btn = !empty($setting) && !empty($setting->primary_color_btn) ? $setting->primary_color_btn : '#133c68';
?>

.bt-inventory-plugin input[type=text]:focus, 
.bt-inventory-plugin input[type=number]:focus, 
.bt-inventory-plugin input[type=tel]:focus, 
.bt-inventory-plugin input[type=email]:focus, input[type=search]:focus, 
.bt-inventory-plugin input[type=password]:focus,
.bt-inventory-plugin textarea:focus {
  background-color: #fff;
  color: #333;
  border: 1px solid <?php echo $primary_color; ?>;
  outline: none !important;
}

.stock-search button {
  width: 35px;
  padding: 0;
  box-shadow: none;
  border-radius: 0;
  display: block;
  text-align: center;
  line-height: 14px;
  font-weight: 700;
  letter-spacing: .3px;
  text-transform: uppercase;
  color: #fff !important;
  background-color: <?php echo $primary_color; ?> !important;
  text-decoration: none;
  outline: none !important;
  visibility: visible;
  white-space: normal;
  border: 1px solid <?php echo $primary_color; ?>;
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
}


.stm-filter-sidebar-boats .stm-price-range-unit .ui-slider .ui-slider-range {
  background-color: <?php echo $primary_color; ?> !important;
  position: absolute;
  top: 0;
  height: 100%;
  z-index: 1;
  font-size: .7em;
  display: block;
  border: 0;
  background-position: 0 0;
}

.stm-filter-sidebar-boats .stm-price-range-unit .ui-slider .ui-slider-handle:after {
  height: 5px;
  width: 5px;
  margin: -2.5px 0 0 -2.5px;
  background-color: <?php echo $primary_color; ?> !important;
  position: absolute;
  content: '';
  display: block;
  top: 50%;
  left: 50%;
  border-radius: 50%
}

.listing-list-loop .image .image-inner .price {
  position: absolute;
  right: 0;
  bottom: 0;
  min-width: 95px;
  color: #fff;
  background-color: <?php echo $primary_color; ?> !important;
  z-index: 1;
  text-align: right;
}

.listing-list-loop .image .image-inner .price:before {
  content: "";
  position: absolute;
  width: 32px;
  height: 100%;
  top: 0;
  left: -11px;
  -webkit-transform: skew(-23deg,0deg);
  transform: skew(-23deg,0deg);
  background: <?php echo $primary_color; ?> !important;
  z-index: -1;
}


.listing-list-loop .image .links a.btn.btn-round-outline {
  display: block;
  text-align: center;
  font-size: 16px;
  color: #133c68;
  text-transform: uppercase;
  font-weight: 700;
  border: solid 2px <?php echo $primary_color_btn; ?> !important;
  margin-bottom: 5px;
}

.listing-list-loop .image .links a.btn.btn-round-outline:hover,
.listing-list-loop .image .links a.btn.btn-round-outline:focus {
  color: #fff;
  background-color: <?php echo $primary_color_btn; ?> !important;
  transition: all .3s ease;
  text-decoration: none;
}

.listing-list-loop .image .links a.btn.btn-round-outline i.fa-phone {
  font-size: 16px;
  font-weight: 700;
}

.listing-list-loop .image .links a.btn.btn-round-outline svg.fa-phone {
  font-size: 13px;
  transform: rotate(90deg);
  position: relative;
  top: -1px;
}


.listing-list-loop .image .links a.btn.btn-round-db {
  display: block;
  text-align: center;
  font-size: 16px;
  background-color: <?php echo $primary_color_btn; ?> !important;
  color: #fff;
  text-transform: uppercase;
  font-weight: 700;
  border: solid 2px <?php echo $primary_color_btn; ?> !important;
  margin-bottom: 5px;
}

.listing-list-loop .image .links a.btn.btn-round-db:hover,
.listing-list-loop .image .links a.btn.btn-round-db:focus {
  text-decoration: none;
  color: #133c68;
  background-color: #fff !important;
  transition: all .3s ease;
}

.listing-list-loop .content .title a:hover {
  text-decoration: none;
  color: <?php echo $primary_color; ?> !important;
  cursor: pointer;
}

.single-boat .btn-single-boat {
  background-color: <?php echo $primary_color; ?> !important;
  box-shadow: 0 2px 0 <?php echo $primary_color; ?> !important;
  border: 1px solid <?php echo $primary_color; ?> !important;
  font-weight: 800;
  width: 100%;
  display: block;
  text-align: center;
  color: #FFF;
  padding: 17px 28px 15px;
  text-decoration: none;
  text-transform: uppercase;
  outline: none;
}

.bt-widget-contact .bti-contact-list li .bti-icon i {
  color: <?php echo $primary_color; ?> !important;
  font-size: 24px;
}

.single-boat .stm-tech-infos .stm-tech-title .stm-icon-speedometr3 {
  font-size: 27px;
  color: <?php echo $primary_color; ?> !important;
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
}

.single-boat .stm-tech-infos .stm-tech-title .title {
  color: <?php echo $primary_color; ?> !important;
  font-weight: 700 ;
  font-size: 22px;
  margin-bottom: 7px;
  line-height: 22px;
}

.single-boat .boat-gallery .stm_fancybox .overlay {
  display: flex;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  z-index: 500;
  background-color: <?php echo $primary_color; ?> !important;
  text-align: center;
  flex-direction: column;
  justify-content: center;
  color: #fff;
  opacity: 0;
  -webkit-transition: all .25s ease;
  -moz-transition: all .25s ease;
  -o-transition: all .25s ease;
  transition: all .25s ease;
}

.single-boat .stm-boats-featured-image  .stm-single-image .stm-boats-single-price:before {
  content: '';
  display: block;
  width: 30px;
  height: 100%;
  position: absolute;
  top: 0;
  left: -30px;
  border-right: solid 20px <?php echo $primary_color; ?> !important;
  border-top: solid 60px transparent;
  border-left: none;
  border-bottom: none;
}

.single-boat .stm-boats-featured-image  .stm-single-image .stm-boats-single-price {
  position: absolute;
  top: 0;
  right: 0;
  z-index: 1;
  background: <?php echo $primary_color; ?> !important;
  padding: 15px;
  color: #FFF;
}

.single-boat .title-row .fa-ship {
  color: <?php echo $primary_color; ?> !important;
  font-size: 18px;
  vertical-align: text-bottom;
}

.loader .fa-spinner {
  font-size: 46px;
  color: <?php echo $primary_color; ?> !important;
}

.loader .fa-spinner path {
  fill: <?php echo $primary_color; ?> !important;
}

.view-mode .view-mode-box.active,
.view-mode .view-mode-box:hover {
  color: <?php echo $primary_color; ?>;
}