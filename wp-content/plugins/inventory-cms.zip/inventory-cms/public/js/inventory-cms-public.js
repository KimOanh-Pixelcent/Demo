
var view_mode = "stm-list";

/* BEGIN AJAX FUNCTIONALITY: PULL DATA FROM API USING AJAX BASED ON INFORMATION FROM FILTER */
function ajaxfilter(paged){ // paged = current page variable. In most instances, this should default to page 1
	jQuery('select').each(function(){ // Check local variables to see if any filters on current page are selected
		var name = jQuery(this).attr('name');
		var val = localStorage.getItem(name);
		if(val){
			jQuery(this).children("option[value='"+ val +"']").attr('selected', 'selected');
		} else {
			val = jQuery(this).val();
			localStorage.setItem(name, val);
		}
	});
	
	/* Set filter variables and map to their form fields */
	// Lowest price
	var lowprice = jQuery('#stm_filter_min_price').map(function(){
		return jQuery(this).val();      
	}).get();
	if(lowprice[0] == ''){
		lowprice[0] = '0';
	}
	localStorage.setItem("lowprice", lowprice[0]);
	
	// Highest Price
	var highprice = jQuery('#stm_filter_max_price').map(function(){
		return jQuery(this).val();       
	}).get();
	if(highprice[0] == ''){
		highprice[0] = '1000000';
	}
	localStorage.setItem("highprice", highprice[0]);
	
	// Boat Length
	var boatlength = jQuery('select[name="length"] option:selected').map(function(){
		return jQuery(this).val();       
	}).get();
	localStorage.setItem("boatlength", boatlength[0]);
	
	// Stock Number
	var stocknum = localStorage.getItem("stocknum");
	if(!stocknum) {
		stocknum = jQuery('input[name="stock"]').map(function(){
			return jQuery(this).val();       
		}).get()[0];
		localStorage.setItem("stocknum", stocknum);
	}
	
	// Check to see if any variables have been previously set - this uses localstorage to persist across pages (so that the filter can work properly even in incognito)
	var make = localStorage.getItem("make");
	var model = localStorage.getItem("model");
	var boattype = localStorage.getItem("boattype");
	var condition = localStorage.getItem("condition");
	var hullmaterial = localStorage.getItem("hullmaterial");
	var loc = localStorage.getItem("location");
	var year = localStorage.getItem("year");
	var sort = localStorage.getItem("sort");
	
	// current page = page number defined when funtion is called
	var paged = paged;
	localStorage.setItem('page', paged); // store current page number
	
	var currentpage = window.location.href;
	var requestData = {
		'action': 'action_get_inventory',
		'post_id': bt_inventory.post_id,
		'paged': paged,
		'currentpage': currentpage,
	};

	// find search
	let search = getQueryVariable("bti-search");
	if(search !== false) {
		requestData = Object.assign(requestData, {
			'search': search,
		});
	} else {
		requestData = Object.assign(requestData, {
			'make' : make,
			'model' : model,
			'boattype' : boattype,
			'condition' : condition,
			'hullmaterial' : hullmaterial,
			'loc' : loc,
			'year' : year,
			'lowprice' : lowprice,
			'highprice' : highprice,
			'boatlength' : boatlength,
			'stocknum' : stocknum,
			'sort' : sort,
			'view_mode': view_mode
		});
	}

	// Begin Ajax call
	jQuery.ajax(
	{
		type: "POST",
		url: bt_inventory.ajax_url,
		dataType: "json",
		data: requestData,
		beforeSend: function(data){
			jQuery('html, body').animate({ // Scroll to top of page when filter is activated
				scrollTop: jQuery('body').offset().top
			}, 1000);
			jQuery('.loader').removeClass('hidden'); // show loading wheel
			jQuery('#filterResult').addClass('bti-d-none'); // hide page content while loading
			
		},
		error: function(xhr,err){
			jQuery('#filterResult').removeClass('bti-d-none').html(xhr.responseText);
			if(search) {
				let total = jQuery("input[name*='total_row']").val();
				let text  = '<strong>' + (total ? total : 0) + '</strong>' + ' results for "<strong>' + search + '</strong>"';
				jQuery('#text-results').html(text);
			}

			jQuery('.loader').addClass('hidden');

			//Check show button 'Clear All'
			if(search == false) {
				checkShowClearAll();
			}
		},
		success: function(response){
			jQuery('#filterResult').removeClass('bti-d-none').html(response); // Show page content once loaded
			if(search) {
				let total = jQuery("input[name*='total_row']").val();
				let text  = '<strong>' + (total ? total : 0) + '</strong>' + ' results for "<strong>' + search + '</strong>"';
				jQuery('#text-results').html(text);
			}

			jQuery('.loader').addClass('hidden');

			//Check show button 'Clear All'
			if(search == false) {
				checkShowClearAll();
			}
		},
		timeout: 30000 // sets timeout to 3 seconds
	});
	
	return false;
}

function ajaxfilter_latest(paged){ // paged = current page variable. In most instances, this should default to page 1
	jQuery('select').each(function(){ // Check local variables to see if any filters on current page are selected
		var name = jQuery(this).attr('name');
		var val = localStorage.getItem(name);
		if(val){
			jQuery(this).children("option[value='"+ val +"']").attr('selected', 'selected');
		} else {
			val = jQuery(this).val();
			localStorage.setItem(name, val);
		}
	});
	
	/* Set filter variables and map to their form fields */
	// Lowest price
	var lowprice = jQuery('#stm_filter_min_price').map(function(){
		return jQuery(this).val();      
	}).get();
	if(lowprice[0] == ''){
		lowprice[0] = '0';
	}
	localStorage.setItem("lowprice", lowprice[0]);
	
	// Highest Price
	var highprice = jQuery('#stm_filter_max_price').map(function(){
		return jQuery(this).val();       
	}).get();
	if(highprice[0] == ''){
		highprice[0] = '1000000';
	}
	localStorage.setItem("highprice", highprice[0]);
	
	// Boat Length
	var boatlength = jQuery('select[name="length"] option:selected').map(function(){
		return jQuery(this).val();       
	}).get();
	localStorage.setItem("boatlength", boatlength[0]);
	
	// Stock Number
	var stocknum = localStorage.getItem("stocknum");
	if(!stocknum) {
		stocknum = jQuery('input[name="stock"]').map(function(){
			return jQuery(this).val();       
		}).get()[0];
		localStorage.setItem("stocknum", stocknum);
	}

	var condition;
	condition = localStorage.getItem("condition");

	var limit;	
	limit = localStorage.getItem("limit");

	var display;	
	display = localStorage.getItem("display");
	
	// current page = page number defined when funtion is called
	var paged = paged;
	localStorage.setItem('page', paged); // store current page number
	
	var currentpage = window.location.href;
	var requestData = {
		'action': 'action_get_inventory_latest',
		'post_id': bt_inventory.post_id,
		'paged': paged,
		'currentpage': currentpage,
	};

	// find search
	let search = getQueryVariable("bti-search");
	if(search !== false) {
		requestData = Object.assign(requestData, {
			'search': search,
		});
	} else {
		requestData = Object.assign(requestData, {
			'condition' : condition,
			'limit': limit,
			'display': display
		});
	}

	// Begin Ajax call
	jQuery.ajax(
	{
		type: "POST",
		url: bt_inventory.ajax_url,
		dataType: "json",
		data: requestData,
		beforeSend: function(data){
			jQuery('html, body').animate({ // Scroll to top of page when filter is activated
				scrollTop: jQuery('body').offset().top
			}, 1000);
			jQuery('.loader').removeClass('hidden'); // show loading wheel
			jQuery('#filterResult').addClass('bti-d-none'); // hide page content while loading
			
		},
		error: function(xhr,err){
			jQuery('#filterResult').removeClass('bti-d-none').html(xhr.responseText);
			if(search) {
				let total = jQuery("input[name*='total_row']").val();
				let text  = '<strong>' + (total ? total : 0) + '</strong>' + ' results for "<strong>' + search + '</strong>"';
				jQuery('#text-results').html(text);
			}

			jQuery('.loader').addClass('hidden');

			//Check show button 'Clear All'
			if(search == false) {
				checkShowClearAll();
			}
		},
		success: function(response){
			jQuery('#filterResult').removeClass('bti-d-none').html(response); // Show page content once loaded
			if(search) {
				let total = jQuery("input[name*='total_row']").val();
				let text  = '<strong>' + (total ? total : 0) + '</strong>' + ' results for "<strong>' + search + '</strong>"';
				jQuery('#text-results').html(text);
			}

			jQuery('.loader').addClass('hidden');

			//Check show button 'Clear All'
			if(search == false) {
				checkShowClearAll();
			}
		},
		timeout: 30000 // sets timeout to 3 seconds
	});
	
	return false;
}

function checkShowClearAll() {
	let isCheck = false;
	let keys = ['make', 'model', 'boattype', 'condition', 'hullmaterial', 'location', 'year', 'boatlength', 'stocknum', 'lowprice', 'highprice'];
	for(let i = 0; i < keys.length; i++) {
		let key = keys[i];
		if(!localStorage.getItem(key)) continue;
		let value = localStorage.getItem(key).trim();
		if(
			(
				(key != 'lowprice' && key != 'highprice' && key != 'boatlength') && 
				value != '' && value != 'undefined' && value != null  && value != 'null'
			) ||
			(
				(key == 'lowprice' && value != 0) ||
				(key == 'highprice' && value != 1000000) ||
				(key == 'boatlength' && value != '0:200')
			)
		) {
			isCheck = true;
			break;
		}
	}

	if(isCheck) {
		console.log(isCheck);
		jQuery(".stm-boats-shorten-filter .clear-all").css('display', 'block');
	} else {
		jQuery(".stm-boats-shorten-filter .clear-all").css('display', 'none');
	}
}

function getQueryVariable(variable) {
   	var query = window.location.search.substring(1);
   	var vars = query.split("&");
   	for (var i=0;i<vars.length;i++) {
        var pair = vars[i].split("=");
        if(pair[0] == variable) {
         	return pair[1];
        }
   }
   return false;
}
	
jQuery(document).ready(function(){

	/* EVENT HANDLERS FOR ACTIVATING THE FILTER */

	if ( jQuery('div').hasClass('latest-boat-section') ) {

		jQuery(document).on('click', '.latest-boat-section a.inactive', function() { // Filter when clicking pagination links
			var paged = jQuery(this).attr('href');		
			// var condition = localStorage.getItem("condition");
			// var limit = localStorage.getItem("limit");
			ajaxfilter_latest(paged);
		});	

		jQuery(document).on('click', '.latest-boat-section .stock-search #btn-stock', function() { // Filter when user clicks the button to search by stock number
			var paged = 1;
			localStorage.setItem("stocknum", jQuery('input*[name="stock"]').val());
			checkShowClearAll();
			ajaxfilter_latest(paged);
		});
		jQuery(document).on('keypress', '.latest-boat-section input*[name="stock"]' ,function(e) { // Filter when user hits the "enter" key
			if(e.which == 13) {
				var paged = 1;
				localStorage.setItem("stocknum", jQuery('input*[name="stock"]').val());
				checkShowClearAll();
				ajaxfilter_latest(paged);
			}
		});
		jQuery(document).on('change', '.latest-boat-section select', function() { // filter when a filter option has changed
			var paged = 1;
			var name = jQuery(this).attr('name');
			var val = jQuery(this).val();
			if(name == 'key') return;
			localStorage.setItem(name, val); // set localstorage item to reflect the changed value
			checkShowClearAll();
			ajaxfilter_latest(paged);
		});	
		jQuery(document).on('click', '.stm-blog-pagination a.page-numbers', function(e) { // Ensure pagination and filters are not operating on engines/trailers page, since they use the built in theme inventory system
			var currentpage = window.location.href;   
			var slug = '';
			var splittedStr = currentpage.split('/');
			slug = splittedStr[splittedStr.length - 2];
			if(slug == 'engines-trailers' ){
				
			} else { 
				e.preventDefault();
				var num = jQuery(this).attr('href');
				localStorage.setItem("backpage",num);
				ajaxfilter_latest(num);	
			}
		});
	}
	else{
		jQuery(document).on('click', 'a.inactive', function() { // Filter when clicking pagination links
			var paged = jQuery(this).attr('href');
			ajaxfilter(paged);
		});	

		jQuery(document).on('click', '.stock-search #btn-stock', function() { // Filter when user clicks the button to search by stock number
			var paged = 1;
			localStorage.setItem("stocknum", jQuery('input*[name="stock"]').val());
			checkShowClearAll();
			ajaxfilter(paged);
		});
		jQuery(document).on('keypress', 'input*[name="stock"]' ,function(e) { // Filter when user hits the "enter" key
			if(e.which == 13) {
				var paged = 1;
				localStorage.setItem("stocknum", jQuery('input*[name="stock"]').val());
				checkShowClearAll();
				ajaxfilter(paged);
			}
		});
		jQuery(document).on('change', 'select', function() { // filter when a filter option has changed
			var paged = 1;
			var name = jQuery(this).attr('name');
			var val = jQuery(this).val();
			if(name == 'key') return;
			localStorage.setItem(name, val); // set localstorage item to reflect the changed value
			checkShowClearAll();
			ajaxfilter(paged);
		});	
		jQuery(document).on('click', '.stm-blog-pagination a.page-numbers', function(e) { // Ensure pagination and filters are not operating on engines/trailers page, since they use the built in theme inventory system
			var currentpage = window.location.href;   
			var slug = '';
			var splittedStr = currentpage.split('/');
			slug = splittedStr[splittedStr.length - 2];
			if(slug == 'engines-trailers' ){
				
			} else { 
				e.preventDefault();
				var num = jQuery(this).attr('href');
				localStorage.setItem("backpage",num);
				ajaxfilter(num);		
			}
		});
	}

	jQuery('.filter-sidebar h3').on('click', function(){ // Open/close filter options
		jQuery('.filter-sidebar').toggleClass('short');
	});		
	
	jQuery(document).on('slidestop', '#boatinv .stm-price-range, #boatinv .stm-length_range-range', function() { // filter when the price range/boat length filters have been changed
		var paged = 1;
		ajaxfilter(paged);
		// ajaxfilter_latest(paged, lastestCondition, lastestLimit);
	});	

	const regex_email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	const regex_phone = /[0-9]{3}-[0-9]{3}-[0-9]{4}/;
	/*form more info*/
	jQuery(document).on('click', '#form-bti-more-info #btn-more-info', function() { // Filter when clicking pagination links
		var form_id = 'form-bti-more-info';
		var post_data = jQuery("#" + form_id).serialize();

        if(!jQuery("#" + form_id).hasClass("bt-form-validate")) {
            jQuery("#" + form_id).addClass("bt-form-validate");
        }
       
        let isCheck = true;
        let arr = jQuery("#" + form_id).serializeArray();
        arr.forEach(function(item) {
        	jQuery("#form-bti-more-info input[name*='" + item.name + "'").next('.bt-invalid').removeClass("bt-invalid-error");
            if(!item.value) {
                isCheck = false;
                if(item.name == 'description') {
                	jQuery("#form-bti-more-info textarea[name*='" + item.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
                	return;
                }
                jQuery("#form-bti-more-info input[name*='" + item.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
                return;
            }

            if((item.name == 'first_name' || item.name == 'last_name') && (item.value.length < 2 || item.value.length > 20)) {
            	isCheck = false;
            	jQuery("#form-bti-more-info input[name*='" + item.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
            }

            if(item.name == 'email' && !regex_email.test(String(item.value).toLowerCase())) {
        		isCheck = false;
        		jQuery("#form-bti-more-info input[name*='" + item.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
            }

            if(item.name == 'phone' && !regex_phone.test(String(item.value).toLowerCase())) {
        		isCheck = false;
        		jQuery("#form-bti-more-info input[name*='" + item.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
            }
        });
        
        if(jQuery("#recaptcha-token").length) {
        	if(typeof grecaptcha !== 'undefined' && grecaptcha && !grecaptcha.getResponse()) {
	        	isCheck = false;
	        	jQuery(".g-recaptcha").next('.bt-invalid').addClass("bt-invalid-error");
	        }
        }

        if(isCheck) {
            jQuery("#" + form_id).removeClass("bt-form-validate");
            jQuery.post(bt_inventory.ajax_url, post_data, function(response) {
                if(response.hasOwnProperty('status')) {
                	if(response.status == 1) {
                		jQuery("#" + form_id).remove();
	                    jQuery("#bt-form-widget").append("<h5 style='line-height: 23px;'>" + response.msg + "</h5>");
	                    window.scrollTo(0, jQuery('.archive-listing-page').offset().top);
                	}
                    if(response.status == 0) {
                		alert(response.msg);
                	}
                }
            });
        }
	});

	jQuery("#form-bti-more-info input[type*='text']").keyup(function() {
		let name = jQuery(this).attr('name');
		if((name == 'first_name' || name == 'last_name')) {
			if((jQuery(this).length < 2 || jQuery(this).length > 20)) {
				jQuery(this).next(".bt-invalid").removeClass("bt-invalid-error");
        		return;
			}
        	jQuery(this).next(".bt-invalid").addClass("bt-invalid-error");
        	return;
        }

        if(jQuery(this).val() && jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
            jQuery(this).next(".bt-invalid").removeClass("bt-invalid-error");
        }

        if(!jQuery(this).val() && !jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
            jQuery(this).next(".bt-invalid").addClass("bt-invalid-error");
        } 
    });

    jQuery("#form-bti-more-info textarea[type*='text']").keyup(function() {
        if(jQuery(this).val() && jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
            jQuery(this).next(".bt-invalid").removeClass("bt-invalid-error");
        }

        if(!jQuery(this).val() && !jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
            jQuery(this).next(".bt-invalid").addClass("bt-invalid-error");
        } 
    });

    jQuery("#form-bti-more-info input[name*='phone']").keypress(function(e) {
    	if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
		  return false;
		}
		var curchr = jQuery(this).val().length;
		var curval = jQuery(this).val();
		if (curchr == 3 && curval.indexOf("-") <= -1) {
		  	jQuery(this).val(curval + "-");
		} else if (curchr == 7 && curval.indexOf("-") > -1) {
		  	jQuery(this).val(curval + "-");
		} else if (curchr == 12) {
		  	jQuery(this).attr('maxlength', '12');
		}
    });

    jQuery(".stm-boats-shorten-filter .clear-all").on('click ',function() {
    	jQuery('.filter-sidebar select').each(function(){
			var name = jQuery(this).attr('name');
			jQuery(this).children('option').prop('selected', false);
			jQuery(this).children('option').first().attr('selected', 'selected');
			localStorage.setItem(name, '');

		});
    	jQuery(this).css('display', 'none');
		ajaxfilter(1);
		// ajaxfilter_latest(1, lastestCondition, lastestLimit);
    });

    jQuery(".view-mode-box").on('click ',function() {
    	let view = jQuery(this).attr("data-view");
    	let hide = jQuery(this).attr("data-hide");
    	if( (!view || !hide) && jQuery(this).hasClass("mode-filter") ) {
    		jQuery(this).toggleClass("active");
    		jQuery(".classic-filter-row").toggleClass("active");
    		return;
    	} else {
    		jQuery(".classic-filter-row").removeClass("active");
    	}

    	jQuery(".view-mode-box").removeClass("active");
    	jQuery(this).addClass("active");
    	jQuery(`.${view}`).removeClass("bti-d-none");
    	jQuery(`.${hide}`).addClass("bti-d-none");

    	view_mode = view;
    });

	// single boat
	jQuery('.stm-big-car-gallery .owl-item .item-video').on('click', function() {
		let url = jQuery(this).children('.owl-video-wrapper').children('.fancy-iframe').attr('data-url');
		let split = url.split("/");
		let name = split[split.length - 1];
		jQuery.ajax({
		  	url: url,
            method: 'GET',
            responseType: 'blob',
		})
		.done(function( response ) {
		    const url = window.URL.createObjectURL(new Blob([response]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', name);
            document.body.appendChild(link);
            link.click();
		});
	});
});

/* JAVASCRIPT TO MAKE THE OPTION SLIDERS FOR PRICE AND BOAT LENGTH WORK */
var stmOptions;
(function ($) {
	jQuery(document).ready(function () {
		var stmMinPrice = 0;
		var stmMaxPrice = 1000000;
		stmOptions = {
			range: true,
			min: 0,
			max: 1000000,
			values: [0, 1000000],
			step: 1000,
			slide: function (event, ui) {
				jQuery("#stm_filter_min_price").val(ui.values[0]);
				jQuery("#stm_filter_max_price").val(ui.values[1]);						
					var stmText = "";
					stmText += "$";
						stmText += ui.values[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
						stmText += ' — $';
						stmText += ui.values[1].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
						jQuery('.filter-price .stm-current-slider-labels').html(stmText);
			}
		}
		jQuery(".stm-price-range").slider(stmOptions);
		jQuery("#stm_filter_min_price").val(jQuery(".stm-price-range").slider("values", 0));
		jQuery("#stm_filter_max_price").val(jQuery(".stm-price-range").slider("values", 1));

		jQuery("#stm_filter_min_price").keyup(function () {
			jQuery(".stm-price-range").slider("values", 0, jQuery(this).val());
		});

		jQuery("#stm_filter_min_price").focusout(function () {
			if (jQuery(this).val() < stmMinPrice) {
				jQuery(".stm-price-range").slider("values", 0, stmMinPrice);
				jQuery(this).val(stmMinPrice);
			}
		});

		jQuery("#stm_filter_max_price").keyup(function () {
			jQuery(".stm-price-range").slider("values", 1, jQuery(this).val());
		});

		jQuery("#stm_filter_max_price").focusout(function () {
			if (jQuery(this).val() > stmMaxPrice) {
				jQuery(".stm-price-range").slider("values", 1, stmMaxPrice);
				jQuery(this).val(stmMaxPrice);
			}
		});

		var store_key_search = function () {
			let key = jQuery('#bti-key').val();
			let key_all = jQuery('input[name*="key_all"]').val();
			let search = jQuery('input[name*="bti-search"]').val();
			if(key == 'all') {
				let params = key_all.split(",");
				if(params.length) {
					params.forEach(item => {
						localStorage.setItem(item, search);
					});
				}
			} else if(key) {
				localStorage.setItem(key, search);
			}
			localStorage.setItem("page", 1);
			localStorage.setItem("backpage", 1);
			localStorage.setItem("save", true);
			jQuery('#bti-form-search').submit();
		}

		jQuery(document).on('keypress', 'input[name*="bti-search"]', function(e) {
			if(e.which == 13) {
				store_key_search();
			}			
		});
	})
})(jQuery);