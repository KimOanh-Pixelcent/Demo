<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/public
 * @author     Your Name <email@example.com>
 */
class Inventory_Cms_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $inventory_cms    The ID of this plugin.
	 */
	private $inventory_cms;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $inventory_cms       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $setting;
	private $table_field;
	private $table_attribute;
	private $table_setting;
	private $table_page_detail;
	private $table_page_sort_options;
	private $table_page_filter_options;
	private $table_form_submits;

	public function __construct( $inventory_cms, $version ) {
		global $wpdb;
		$this->version = $version;
		$this->inventory_cms = $inventory_cms;

		$this->table_field = $wpdb->prefix . (defined( 'TABLE_FIELD' ) && TABLE_FIELD != '' ? TABLE_FIELD : 'bt_inventory_field');
		$this->table_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
		$this->table_attribute = $wpdb->prefix . (defined( 'TABLE_ATTRIBUTE' ) && TABLE_ATTRIBUTE != '' ? TABLE_ATTRIBUTE : 'bt_inventory_attributes');
		$this->table_page_detail = $wpdb->prefix . (defined( 'TABLE_PAGE_DETAIL' ) && TABLE_PAGE_DETAIL != '' ? TABLE_PAGE_DETAIL : 'bt_inventory_page_detail');
		$this->table_form_submits = $wpdb->prefix . (defined( 'TABLE_FORM_SUBMITS' ) && TABLE_FORM_SUBMITS != '' ? TABLE_FORM_SUBMITS : 'bt_inventory_form_submits');
		$this->table_page_sort_options = $wpdb->prefix . (defined( 'TABLE_PAGE_SORT_OPTIONS' ) && TABLE_PAGE_SORT_OPTIONS != '' ? TABLE_PAGE_SORT_OPTIONS : 'bt_inventory_page_sort_options');
		$this->table_page_filter_options = $wpdb->prefix . (defined( 'TABLE_PAGE_FILTER_OPTIONS' ) && TABLE_PAGE_FILTER_OPTIONS != '' ? TABLE_PAGE_FILTER_OPTIONS  : 'bt_inventory_page_filter_options');
		
		$this->setting = $wpdb->get_row("SELECT * FROM {$this->table_setting} WHERE id = 1");
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Inventory_Cms_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Inventory_Cms_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->inventory_cms, plugin_dir_url( __FILE__ ) . 'css/inventory-cms-public.min.css', array(), $this->version, 'all' );
		wp_enqueue_style('bt-main', plugin_dir_url( __FILE__ ) . 'css/main.php', array(), $this->version, 'all' );
		wp_enqueue_style('fancyboxCss', plugin_dir_url( __FILE__ ) . 'css/jquery.fancybox.min.css', $this->version, 'all' );
		wp_enqueue_style('carousel', plugin_dir_url( __FILE__ ) . 'css/owl.carousel.min.css', array(), $this->version, 'all');
		
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts_footer() {
		global $post;
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Inventory_Cms_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Inventory_Cms_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_enqueue_script( 'uiJquery',  plugin_dir_url( __FILE__ ) . 'js/jquery-ui.min.js', array( 'jquery' ));
		wp_enqueue_script( 'fancybox',  plugin_dir_url( __FILE__ ) . 'js/jquery.fancybox.min.js', array( 'jquery' ));
		wp_enqueue_script( 'carousel',  plugin_dir_url( __FILE__ ) . 'js/owl.carousel.min.js', array( 'jquery' ));
		wp_enqueue_script( 'printThis', plugin_dir_url( __FILE__ ) . 'js/printThis.js', array( 'jquery' ));
		wp_enqueue_script( 'wheelzoom', plugin_dir_url( __FILE__ ) . 'js/wheelzoom.js', array( 'jquery' ), array( 'jquery' ));
		wp_enqueue_script( $this->inventory_cms, plugin_dir_url( __FILE__ ) . 'js/inventory-cms-public.js', array( 'jquery' ), $this->version, false );
		wp_localize_script( $this->inventory_cms, "bt_inventory", array(
			"post_id"  => !empty($post) ? $post->ID : '', 
			"ajax_url" => admin_url('admin-ajax.php')
		));

		if(!empty($this->setting)) {
			if($this->setting->type_recaptcha == 3 && !empty($this->setting->site_key_recaptcha_3) && !empty($this->setting->secret_key_recaptcha_3)) {
				wp_enqueue_script( 'btiReCAPTCHA', 'https://www.google.com/recaptcha/api.js?render='.$this->setting->site_key_recaptcha_3, false );
				$script = "grecaptcha.ready(function () {
					    grecaptcha.execute('".$this->setting->site_key_recaptcha_3."')
					      .then(function (token) {
					        jQuery('#g-recaptcha-response').val(token);
					      });
					});";
				wp_add_inline_script( 'btiReCAPTCHA', $script );
			}
		}		
	}

	public function enqueue_scripts_head() {
		/*reCAPTCHA for form widget*/
		if(!empty($this->setting)) {
			if($this->setting->type_recaptcha == 2 && !empty($this->setting->site_key_recaptcha_2) && !empty($this->setting->secret_key_recaptcha_2)) {
				wp_enqueue_script( 'btiReCAPTCHAv2', 'https://www.google.com/recaptcha/api.js', false );
			}
		}
	}

	public function bt_inventory_single_template_layout($single_template) {
		global $post;
		if($post->post_type == 'inventory') {
			$single_template = plugin_dir_path( __FILE__ ) .'partials/inventory-cms-layout.php';
			return $single_template;
		}
		return $single_template;
	}

	public function bt_inventory_single_template_content() {
		ob_start();
		if(!empty($this->setting) && !empty($this->setting->api_key)) {
			global $post;
			$setting = $this->setting;
			include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-content.php';
		}
		else {
			?><h3>API KEY does not exist. Please go to settings to enter your API KEY.</h3><?php
		}
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	public function bt_inventory_single_template_content_search() {
		ob_start();
		if(!empty($this->setting) && !empty($this->setting->api_key)) {
			global $post;
			$setting = $this->setting;
			include_once plugin_dir_path( __FILE__ ) .'partials/search/inventory-cms-content.php';
		}
		else {
			?><h3>API KEY does not exist. Please go to settings to enter your API KEY.</h3><?php
		}
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	public function bt_inventory_template_latest_boats() {
		ob_start();
		if(!empty($this->setting) && !empty($this->setting->api_key)) {
			global $post;
			$setting = $this->setting;
			// echo $condition.'lplp';
			include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-latest-content.php';
		}
		else {
			?><h3>API KEY does not exist. Please go to settings to enter your API KEY.</h3><?php
		}
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	public function boat_filter($is_show_title = true){
		global $wpdb, $post;

		#set default column
		$column = "12";

		$vars = '';
		#get post detail
		$lowprice  = '1';
		$highprice =  '1000000';
		$post_detail = null;
		if(!empty($post)) {
			$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = " . $post->ID);
		}

		if(!empty($post_detail)) {
			if(!empty($post_detail->post_filter_position) && $post_detail->post_filter_position == 2) {
				$column = "3";
			}

			if(!empty($post_detail->post_filter)) {
				$aliases = array(
					"make"         => "make",
					"model"        => "exactModel",
					"boattype" 	   => "class",
					"condition"    => "condition",
					"hullmaterial" => "hull",
					"location"     => "BoatCityNameNoCaseAlnumOnly",
					"year"         => "year",
					"length"       => "length",
				);
				$post_filters = unserialize($post_detail->post_filter);
				foreach($post_filters as $post_filter) {
					$filter = json_decode($post_filter);
					$key_filter = key($filter);

					if($key_filter == "price") {
						$lowprice  = '0';
						$highprice =  '1000000';
						if(!empty($filter->price)) {
							if(!empty($filter->price[0])) {
								$lowprice = $filter->price[0];
							}

							if(!empty($filter->price[1])) {
								$highprice = $filter->price[1];
							}
						}

						$price = $lowprice . ':'. $highprice;

						$vars .= '&price=' . $price . '|USD';
						continue;
					}

					$value = $filter->{$key_filter};
					if(is_array($value)) {
						$value = implode(",", $value);
					}
					if($key_filter == 'length') {
						$value .= '|feet';
					}

					$vars .= '&' . $aliases[$key_filter] . '=' . $value;
				}
			}
		} else  {
			if(!empty($this->setting->filter_position) && $this->setting->filter_position == 2) {
				$column = "3";
			}
		}

		if(isset($_POST['key']) && isset($_POST['search'])) {
			if($_POST['key'] == 'location') {
				$_POST['loc'] = $_POST['search'];
			}
			else if($_POST['key'] == 'length') {
				$_POST['boatlength'] = $_POST['search'];
			}else {
				$_POST[$_POST['key']] = $_POST['search'];
			}
			$_POST[$item] = $_POST['search'];
		}

		/* GET AJAX VARIABLES */
		$stocknum = '';
		$rows = '10';
		if(isset($_POST['stocknum']) && ($_POST['stocknum'] != '')){ // Determines how many rows/items to display per page - if searching by stock number, must pull all rows from API first so the second search can be run; if not, use the row number specified in the POST
			$stocknum  =  $_POST['stocknum'];
			$rows = '200';
		} else {
			if(!empty($post_detail)) {
				$rows = $post_detail->post_row_limit;
			}
		}

		$vars .= '&rows=' . $rows;
		
		$paged = '1';
		if(isset($_POST['paged'])){
			$paged  =  $_POST['paged'];
			if($paged != 1){
				$offset = ($paged - 1) * $rows;	
				$vars .= '&offset=' . $offset; // This allows for pagination to work between the API and Wordpress; for example with a pagesize of 10, viewing page 3 would require an offset of 20 (so the first 20 listings are not displayed on page 3)
			}
		}
		
		$currentpage = '/inventory';
		if(isset($_POST['currentpage'])){
			$currentpage  =  $_POST['currentpage'];
		}
		
		// Make
		$make = '';
		if(isset($_POST['make']) && $_POST['make'] != ''){
			$make  =  $_POST['make'];
			$vars .= '&make=' . $make;
		}
		
		//  Model
		$model = '';
		if(isset($_POST['model']) && $_POST['model'] != ''){
			$model  =  $_POST['model'];
			$vars .= '&exactModel=' . $model;
		}
		
		// Boat Type
		$boattype = '';
		if(isset($_POST['boattype']) && $_POST['boattype'] != ''){
			$boattype  =  $_POST['boattype'];
			$vars .= '&class=' . $boattype;
		}
		
		// Condition
		$condition = '';
		if(isset($_POST['condition']) && $_POST['condition'] != ''){
			$condition  =  $_POST['condition'];
			$vars .= '&condition=' . $condition;
		}
		
		// Hull Material
		$hullmaterial = '';
		if(isset($_POST['hullmaterial']) && $_POST['hullmaterial'] != ''){
			$hullmaterial  =  $_POST['hullmaterial'];
			$vars .= '&hull=' . $hullmaterial;
		}
		
		// Location
		$location = '';
		if(isset($_POST['loc']) && $_POST['loc'] != ''){
			$location  =  $_POST['loc'];
			$vars .= '&BoatCityNameNoCaseAlnumOnly=' . $location;
		}
		
		// Year
		$year = '';
		if(isset($_POST['year']) && $_POST['year'] != ''){
			$year  =  $_POST['year'];
			$vars .= '&year=' . $year;
		}
		
		// Price Range: Low Limit and High Limit, formatted as required by Boats.com API
		$price = '';
		if(isset($_POST['lowprice']) || isset($_POST['highprice']) ){
			if(isset($_POST['lowprice']) && $_POST['lowprice'] != ''){
				$lowprice  =  $_POST['lowprice'][0];
			} else {
				$lowprice  =  '0';
			}
			
			if(isset($_POST['highprice']) && $_POST['highprice'] != '' ){
				$highprice  =  $_POST['highprice'][0];
			} else {
				$highprice  =  '1000000';
			}
			$price = $lowprice . ':'. $highprice;
			$vars .= '&price=' . $price . '|USD';

		}

		// Boat Length
		$boatlength = '';
		if(isset($_POST['boatlength'])){
			$boatlength  =  $_POST['boatlength'][0];
			$vars .= '&length=' . $boatlength . '|feet';
		}
		
		// Sorting Option
		$sort = '';
		if(isset($_POST['sort'])){
			$sort  =  $_POST['sort'];
			$vars .= '&sort=' . $sort;
		}
		
		$url = 'https://api.boats.com/inventory/search?key=' . $this->setting->api_key . $vars .'&rows=200&status=active';
		$data = array(
			"make"         => array(),
			"model"        => array(),
			"boattype" 	   => array(),
			"condition"    => array(),
			"hullmaterial" => array(),
			"location"     => array(),
			"year"         => array()
		);

		// Check page default
		$params = explode("/", $_SERVER["REQUEST_URI"]);
		$slug_plugin = $params[(count($params) - 2)];
		if(($slug_plugin == $this->setting->slug && end($params) == '') || ($slug_plugin != $this->setting->slug && end($params) ==  $this->setting->slug) || ($slug_plugin != $this->setting->slug && end($params) == 'boat-search-results')) {
			$post_id = 0;
		} else {
			$post_id = $post->ID;
		}

		$fields = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_filter_options} ON {$this->table_page_filter_options}.field_id = {$this->table_field}.id WHERE post_id = " . $post_id);

		if(!count($fields)) {
			$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		}

		$getInventory = wp_remote_get( $url, array(
		        'timeout'     => 120,
		        'httpversion' => '1.1',
		    ) 
		);
		if(isset($getInventory['body'])) {
			$boats = $getInventory['body'];
			$boats = json_decode($boats);
			if(!empty($boats->results)):
			$boats = $boats->results;	
			foreach($boats as $boat): 
				array_push($data['make'], $boat->MakeString);
				array_push($data['model'], $boat->Model);
				foreach($boat->BoatClassCode as $boatclass){
					array_push($data['boattype'], $boatclass);
				}
				array_push($data['condition'],$boat->SaleClassCode);
				array_push($data['hullmaterial'],$boat->BoatHullMaterialCode);
				array_push($data['location'],$boat->BoatLocation->BoatCityName);
				array_push($data['year'], $boat->ModelYear);
			endforeach; 
				//only save one instance of each parameter
				$data['make'] = array_unique($data['make']);
				$data['model'] = array_unique($data['model']);
				$data['boattype'] = array_unique($data['boattype']);
				$data['condition'] = array_unique($data['condition']);
				$data['hullmaterial'] = array_unique($data['hullmaterial']);
				$data['location'] = array_unique($data['location']);
				$data['year']  =array_unique($data['year']);

				sort($data['make']);
				sort($data['model']);
				sort($data['boattype']);
				sort($data['condition']);
				sort($data['hullmaterial']);
				sort($data['location']);
				sort($data['year']);
			?>
				<!-- Begin oututting HTML for the filter-->
				<form method="get">
					<div class="filter filter-sidebar stm-filter-sidebar-boats" id="boatinv">
						<?php if($is_show_title == true) : ?>
							<div class="bti-col-md-12"><h3>Filter Results</h3></div>
						<?php endif; ?>
						<div class="bti-row stm-boats-shorten-filter">
							<div class="bti-col-12">
								<p class="clear-all" style="display: none;"><span><i class="fa fa-times"></i> Clear All</span></p>
							</div>
							<?php
								if(count($fields) > 0) {
									foreach($fields as $field) {
										if(!empty($data[$field->field_key])) {
											?>
												<div class="bti-col-12 bti-col-md-<?php echo $column;?> stm-filter_make">
													<div class="bti-form-group">
														<label class="sr-only" for="<?php echo $field->field_key; ?>"><?php echo $field->field_value; ?></label>
														<select name="<?php echo $field->field_key; ?>" class="bti-form-control" id="<?php echo $field->field_key; ?>">
															<option value=""><?php echo $field->field_value; ?></option>
															<?php foreach ($data[$field->field_key] as $value) {
																echo '<option value="' . $value . '">' . $value . '</option>';
															} ?>
														</select>
													</div>
												</div>
											<?php
										}

										if($field->field_key == "length") {
											?>
												<div class="bti-col-12 bti-col-md-<?php echo $column;?>">
													<div class="bti-form-group">
														<label class="sr-only" for="length">Length</label>
														<select name="length" class="bti-form-control" id="length">
															<option value="0:200">Boat Length</option>
															<option value="0:10">1 - 10ft</option>
															<option value="10:20">10 - 20ft</option>
															<option value="20:30">20 - 30ft</option>
															<option value="30:40">30 - 40ft</option>
															<option value="40:50">40 - 50ft</option>
														</select>
													</div>
												</div>
											<?php
										}

										if($field->field_key == "price") {
											?>
												<div class="bti-col-12 bti-col-md-<?php echo $column;?>">
													<div class="filter-price stm-slider-filter-type-unit">
														<div class="clearfix">
															<p class="pull-left">Price Range</p>
															<div class="stm-current-slider-labels">$<?php echo number_format($lowprice, 0, ",", " "); ?> — $<?php echo number_format($highprice, 0, ",", " "); ?></div>
														</div>
														<div class="stm-price-range-unit">
															<div class="stm-price-range ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all"><div class="ui-slider-range ui-widget-header ui-corner-all" ></div><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" ></span><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" ></span></div>
														</div>
														<div class="row">
															<div class="bti-col-md-6 bti-col-sm-6 bti-col-md-wider-right">
																<label class="sr-only" for="stm_filter_min_price">Minimum Price</label>
																<input type="text" name="min_price" id="stm_filter_min_price" value="0">
															</div>
															<div class="bti-col-md-6 bti-col-sm-6 bti-col-md-wider-left">
																<label class="sr-only" for="stm_filter_max_price">Maximum Price</label>
																<input type="text" name="max_price" id="stm_filter_max_price" value="1000000">
															</div>
														</div>
													</div>
												</div>
											<?php
										}
									}
								}
							?>
						</div>
					</div>
				</form>
			<?php endif; 
		}
	}

	public function boat_sort() {
		global $wpdb, $post;
		// Check page default
		$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		$params = explode("/", $_SERVER["REQUEST_URI"]);
		$slug_plugin = $params[(count($params) - 2)];
		if(($slug_plugin == $this->setting->slug && end($params) == '') || ($slug_plugin != $this->setting->slug && end($params) ==  $this->setting->slug) || ($slug_plugin != $this->setting->slug && end($params) == 'boat-search-results')) {
			$post_id = 0;
		} else {
			$post_id = $post->ID;
		}

		$fields = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_sort_options} ON {$this->table_page_sort_options}.field_id = {$this->table_field}.id WHERE post_id = " . $post_id);

		if(!count($fields)) {
			$fields = $wpdb->get_results("SELECT * FROM {$this->table_field} WHERE field_key = 'year' OR field_key = 'price'");
		}
		
		$aliases = array(
			"make"         => [
				"key"  => "make",
				"asc"  => "Make (A - Z)",
				"desc" => "Make (Z - A)"
			],
			"model"        => [
				"key"  => "exactModel",
				"asc"  => "Model (A - Z)",
				"desc" => "Model (Z - A)"
			],
			// "boattype" 	   => [
			// 	"key"  => "BoatClassCode",
			// 	"asc"  => "Oldest First",
			// 	"desc" => "Newest First"
			// ],
			"condition"    => [
				"key"  => "condition",
				"asc"  => "Used First",
				"desc" => "New First"
			],
			// "hullmaterial" => [
			// 	"key"  => "hull",
			// 	"asc"  => "Hull material (A - Z)",
			// 	"desc" => "Hull material (Z - A)"
			// ],
			"location"     => [
				"key"  => "BoatCityNameNoCaseAlnumOnly",
				"asc"  => "Location (A - Z)",
				"desc" => "Location (Z - A)"
			],
			"year"         => [
				"key"  => "year",
				"asc"  => "Oldest First",
				"desc" => "Newest First"
			],
			"length"       => [
				"key"  => "length",
				"asc"  => "Shortest First",
				"desc" => "Longest First"
			],
			"price"        => [
				"key"  => "price",
				"asc"  => "Lower First",
				"desc" => "Highest First"
			],
		);
		?>
			<select name="sort" class="bti-form-control" id="sort">
				<?php 
					foreach ($fields as $field) {
						if($field->field_key == "boattype") continue;
						echo '<option value="' . $aliases[$field->field_key]["key"] .'|asc">' . $field->field_value .': ' . $aliases[$field->field_key]["asc"] .'</option>';
						echo '<option value="' . $aliases[$field->field_key]["key"] .'|desc">' . $field->field_value .': ' . $aliases[$field->field_key]["desc"] .'</option>';
					}
				?>
			</select>
		<?php
	}

	public function action_get_inventory() {
		global $wpdb;

		$column_left = "4";
		$column_right = "8";
		$column_grid_view = "6";

		#get post detail
		if(!empty($_POST['post_id'])) {
			$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = " . $_POST['post_id']);
		}

		if(!empty($post_detail)) {
			if(!empty($post_detail->post_filter_position) && $post_detail->post_filter_position == 2) {
				$column_left = "3";
				$column_right = "9";
				$column_grid_view = "4";
			}

			if(!empty($post_detail->post_filter)) {
				$aliases = array(
					"make"         => "make",
					"model"        => "exactModel",
					"boattype" 	   => "class",
					"condition"    => "condition",
					"hullmaterial" => "hull",
					"location"     => "BoatCityNameNoCaseAlnumOnly",
					"year"         => "year",
					"length"       => "length"
				);
				$post_filters = unserialize($post_detail->post_filter);
				foreach($post_filters as $post_filter) {
					$filter = json_decode($post_filter);
					$key_filter = key($filter);

					if($key_filter == "price") {
						$lowprice  = '0';
						$highprice =  '1000000';
						if(!empty($filter->price)) {
							if(!empty($filter->price[0])) {
								$lowprice = $filter->price[0];
							}

							if(!empty($filter->price[1])) {
								$highprice = $filter->price[1];
							}
						}

						$price = $lowprice . ':'. $highprice;

						$vars .= '&price=' . $price . '|USD';
						continue;
					}

					$value = $filter->{$key_filter};
					if(is_array($value)) {
						$value = implode(",", $value);
					}
					if($key_filter == 'length') {
						$value .= '|feet';
					}

					$vars .= '&' . $aliases[$key_filter] . '=' . $value;
				}
			}
		} else  {
			if(!empty($this->setting->filter_position) && $this->setting->filter_position == 2) {
				$column_left = "3";
				$column_right = "9";
				$column_grid_view = "4";
			}
		}

		/* GET AJAX VARIABLES */
		$stocknum = '';
		$rows = '10';
		if(isset($_POST['stocknum']) && ($_POST['stocknum'] != '')){ // Determines how many rows/items to display per page - if searching by stock number, must pull all rows from API first so the second search can be run; if not, use the row number specified in the POST
			$stocknum  =  $_POST['stocknum'];
			$rows = '200';
		} else {
			if(!empty($post_detail)) {
				$rows = $post_detail->post_row_limit;
			}
		}

		$vars .= '&rows=' . $rows;
		
		$paged = '1';
		if(isset($_POST['paged'])){
			$paged  =  $_POST['paged'];
			if($paged != 1){
				$offset = ($paged - 1) * $rows;	
				$vars .= '&offset=' . $offset; // This allows for pagination to work between the API and Wordpress; for example with a pagesize of 10, viewing page 3 would require an offset of 20 (so the first 20 listings are not displayed on page 3)
			}
		}
		
		$currentpage = '/inventory';
		if(isset($_POST['currentpage'])){
			$currentpage  =  $_POST['currentpage'];
		}
		
		// Make
		$make = '';
		if(isset($_POST['make']) && $_POST['make'] != ''){
			$make  =  $_POST['make'];
			$vars .= '&make=' . $make;
		}
		
		//  Model
		$model = '';
		if(isset($_POST['model']) && $_POST['model'] != ''){
			$model  =  $_POST['model'];
			$vars .= '&exactModel=' . $model;
		}
		
		// Boat Type
		$boattype = '';
		if(isset($_POST['boattype']) && $_POST['boattype'] != ''){
			$boattype  =  $_POST['boattype'];
			$vars .= '&class=' . $boattype;
		}
		
		// Condition
		$condition = '';
		if(isset($_POST['condition']) && $_POST['condition'] != ''){
			$condition  =  $_POST['condition'];
			$vars .= '&condition=' . $condition;
		}
		
		// Hull Material
		$hullmaterial = '';
		if(isset($_POST['hullmaterial']) && $_POST['hullmaterial'] != ''){
			$hullmaterial  =  $_POST['hullmaterial'];
			$vars .= '&hull=' . $hullmaterial;
		}
		
		// Location
		$location = '';
		if(isset($_POST['loc']) && $_POST['loc'] != ''){
			$location  =  $_POST['loc'];
			$vars .= '&BoatCityNameNoCaseAlnumOnly=' . $location;
		}
		
		// Year
		$year = '';
		if(isset($_POST['year']) && $_POST['year'] != ''){
			$year  =  $_POST['year'];
			$vars .= '&year=' . $year;
		}
		
		// Price Range: Low Limit and High Limit, formatted as required by Boats.com API
		$price = '';
		if(isset($_POST['lowprice']) || isset($_POST['highprice']) ){
			if(isset($_POST['lowprice']) && $_POST['lowprice'] != ''){
				$lowprice  =  $_POST['lowprice'][0];
			} else {
				$lowprice  =  '0';
			}
			
			if(isset($_POST['highprice']) && $_POST['highprice'] != '' ){
				$highprice  =  $_POST['highprice'][0];
			} else {
				$highprice  =  '1000000';
			}
			$price = $lowprice . ':'. $highprice;
			$vars .= '&price=' . $price . '|USD';

		}

		// Boat Length
		$boatlength = '';
		if(isset($_POST['boatlength'])){
			$boatlength  =  $_POST['boatlength'][0];
			$vars .= '&length=' . $boatlength . '|feet';
		}
		
		// Sorting Option
		$sort = '';
		if(!empty($_POST['sort'])){
			$sort  =  $_POST['sort'];
			$vars .= '&sort=' . $sort;
		}

		if(!empty($_POST['search'])){
			$vars .= '&AdvancedKeywordSearch=' . $_POST['search'];
		}

		$view_mode = "stm-list";
		if(isset($_POST['view_mode'])){
			$view_mode = $_POST['view_mode'];
		}
		
		$url = 'https://api.boats.com/inventory/search?key=' . $this->setting->api_key .'&status=active'. $vars;
		$getInventory = wp_remote_get( $url, array(
		        'timeout'     => 120,
		        'httpversion' => '1.1',
		    ) 
		);
		$boats = $getInventory['body'];
		$boats = json_decode($boats);
		$total = $boats->numResults;
		$boats = $boats->results;

		?> 
			<?php if(!empty($boats) && count($boats) > 0) {?>
			<!-- Check to see if the user searched for a Stock number before beginning to loop through boats -->
			<?php if($stocknum != ''){
				$boatstock = array();
				$stocknum = strtoupper($stocknum);
				foreach($boats as $boat){
					if($boat->StockNumber == $stocknum){
						array_push($boatstock, $boat);
					}
				}
				$boats = $boatstock;
				// count the total number (needed for pagination)
				$total = count($boatstock);
			} else { } ?>
			<div class="stm-grid bti-row <?php if($view_mode != 'stm-grid') { echo 'bti-d-none'; } ?>">
			<?php foreach($boats as $boat): ?>
				<div class="stm-isotope-sorting bti-col-md-6 bti-col-lg-<?php echo $column_grid_view; ?>">
					<div class="listing-list-loop stm-isotope-listing-item all bti-row" data-price="<?php echo $boat->Price; ?>" data-date="<?php echo $boat->ItemReceivedDate; ?>" >
						<div class="image bti-col-12">
							<?php if(!empty($boat->EmbeddedVideo)): ?>
								<span id="download" class="video-preview fancy-iframe" data-url="<?php $vids = $boat->Videos; echo esc_url( $vids->url[0] ); ?>"><i class="fa fa-film"></i><?php esc_html_e('Video', 'motors'); ?></span>
							<?php endif; ?>
							<?php
								$slug_single = 'boats';
								if(!empty($this->setting->slug_single)) $slug_single = $this->setting->slug_single;
								$link = '/' . $slug_single . '/' . $boat->MakeStringExact . '-' . $boat->ModelExact . '-' . $boat->ModelYear . '-' . $boat->DocumentID;

								if(!empty($this->setting) && !empty($this->setting->single_params)) {
									$params = unserialize($this->setting->single_params);
									$link = '/' . $slug_single .'/';
									foreach($params as $param) {
										if($param == 'none') continue;

										if($param == 'BoatLocation') {
											$link .= $boat->$param->BoatCityName . '-';
											continue;
										}
										if($param == 'BoatClassCode') {
											$link .= $boat->$param[0] . '-';
											continue;
										}
										$link .= $boat->$param . '-';
									}
									$link .= $boat->DocumentID;

								}
								$link = str_replace(' ', '-', $link);
								$link = strtolower($link); 
							?>
							<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
								<div class="image-inner">

									<?php if(!empty($boat->Images)): ?>
										<?php $img = $boat->Images; ?>
										<img src="<?php echo esc_url($img[0]->Uri); ?>" class="img-responsive" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
									<?php else: ?>
										<img src="<?php echo esc_url(get_stylesheet_directory_uri().'/assets/images/boats-placeholders/boats-170.png'); ?>" class="img-responsive" alt="<?php esc_html_e('Placeholder', 'motors'); ?>" />
									<?php endif; ?>

									<?php $price = $boat->Price; $price = number_format($price, 0, '.', ','); if(!empty($price) and $price != 1): ?>
										<div class="price">
											<div class="normal-price">
												<span class="heading-font">$<?php echo $price; ?></span>
											</div>
										</div>
									<?php elseif($price = 1): // Used to display "Call" for some boats - for our dealer, the Call message is displayed if the boat price is set to "1" in the API ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php else: ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<div class="boats-image-unit">				
									<div class="stm-listing-photos-unit grid-stm-car-photos-<?php echo $boat->DocumentID; //Give Fancybox a unique ID since multiple boats are displaye per page ?>">
										<i class="stm-boats-icon-camera"></i>
									<span><?php echo count($img); ?></span>
								</div>

								<script type="text/javascript">
									jQuery(document).ready(function(){
										jQuery(".grid-stm-car-photos-<?php echo $boat->DocumentID; ?>").click(function(e) {
											e.preventDefault();
											jQuery.fancybox.open([
												<?php foreach($img as $url): ?>
													{ src  : "<?php echo $url->Uri; ?>" },
												<?php endforeach; ?>
											], { 
												padding: 0, 
												protect: true,
												smallBtn   : true,
												buttons : [
												    'zoom',
												    'thumbs',
												    'close'
											  	]
											});
										});
									});

								</script>
										</div>
							</a>
							<div class="links bti-row">
								<div class="bti-col-md-5"><a href="tel:2393092653" class="btn btn-round-outline"><i class="fa fa-phone" aria-hidden="true"></i> Call Us</a></div>
								<div class="bti-col-md-7"><a href="<?php echo site_url($link); ?>" class="btn btn-round-db bt-view-detail"><i class="fa fa-plus"></i> View Details</a></div>
							</div>
						</div>

						<div class="content bti-col-12">
							<div class="meta-top">
								<div class="title heading-font">
									<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
										<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>
									</a>
								</div>
								<div class="excerpt">
									<p>
										<?php $text =  strip_tags($boat->GeneralBoatDescription[0]); echo implode(' ', array_slice(explode(' ', $text), 0, 20)); ?>
									</p>
								</div>
							</div>
							
							<div class="meta-middle">					
								<div class="meta-middle-unit font-exists ca-year">
									<div class="meta-middle-unit-top">
										<strong>Year</strong><div class="name"><?php echo $boat->ModelYear;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists boat-type">
									<div class="meta-middle-unit-top">
										<strong>Stock Number</strong><div class="name"><?php echo $boat->StockNumber; ?></div>
									</div>
								</div>																	
								<div class="meta-middle-unit font-exists condition">
									<div class="meta-middle-unit-top">
										<strong>Condition</strong><div class="name"><?php echo $boat->SaleClassCode;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists length_range">
									<div class="meta-middle-unit-top">
										<strong>Boat Length</strong><div class="name"><?php echo $boat->NominalLength;?></div>
									</div>
								</div>																									
								<div class="meta-middle-unit font-exists engine">
									<div class="meta-middle-unit-top">
										<strong>Engine</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Model; } $engnum++; } ?></div>
									</div>
								</div>	
								<?php if($boat->SaleClassCode != 'New'){ ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Boat Hours</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Hours; } $engnum++; } ?></div>
									</div>
								</div>
								<?php } ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Location</strong><div class="name"><?php echo $boat->BoatLocation->BoatCityName;?></div>
									</div>
								</div>						
							</div>

							<a href="<?php echo site_url($link); ?>" class="stm-car-view-more btn bti-d-block bti-d-md-none bt-view-detail"><?php esc_html_e('View more', 'motors'); ?></a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
			<div class="bti-row stm-list <?php if($view_mode != 'stm-list') { echo 'bti-d-none'; } ?>">
				<div class="stm-isotope-sorting bti-col-12">
				<!-- Check to see if the user searched for a Stock number before beginning to loop through boats -->
				<?php if($stocknum != ''){
					$boatstock = array();
					$stocknum = strtoupper($stocknum);
					foreach($boats as $boat){
						if($boat->StockNumber == $stocknum){
							array_push($boatstock, $boat);
						}
					}
					$boats = $boatstock;
					// count the total number (needed for pagination)
					$total = count($boatstock);
				} else { } ?>
				
				<?php foreach($boats as $boat): ?>
					<div class="listing-list-loop stm-isotope-listing-item all bti-row" data-price="<?php echo $boat->Price; ?>" data-date="<?php echo $boat->ItemReceivedDate; ?>" >
						<div class="image bti-col-12 bti-col-md-6 bti-col-lg-<?php echo $column_left; ?>">
							<?php if(!empty($boat->EmbeddedVideo)): ?>
								<span id="download" class="video-preview fancy-iframe" data-url="<?php $vids = $boat->Videos; echo esc_url( $vids->url[0] ); ?>"><i class="fa fa-film"></i><?php esc_html_e('Video', 'motors'); ?></span>
							<?php endif; ?>
							<?php
								$slug_single = 'boats';
								if(!empty($this->setting->slug_single)) $slug_single = $this->setting->slug_single;
								$link = '/' . $slug_single . '/' . $boat->MakeStringExact . '-' . $boat->ModelExact . '-' . $boat->ModelYear . '-' . $boat->DocumentID;

								if(!empty($this->setting) && !empty($this->setting->single_params)) {
									$params = unserialize($this->setting->single_params);
									$link = '/' . $slug_single .'/';
									foreach($params as $param) {
										if($param == 'none') continue;

										if($param == 'BoatLocation') {
											$link .= $boat->$param->BoatCityName . '-';
											continue;
										}
										if($param == 'BoatClassCode') {
											$link .= $boat->$param[0] . '-';
											continue;
										}
										$link .= $boat->$param . '-';
									}
									$link .= $boat->DocumentID;

								}
								$link = str_replace(' ', '-', $link);
								$link = strtolower($link); 
							?>
							<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
								<div class="image-inner">

									<?php if(!empty($boat->Images)): ?>
										<?php $img = $boat->Images; ?>
										<img src="<?php echo esc_url($img[0]->Uri); ?>" class="img-responsive" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
									<?php else: ?>
										<img src="<?php echo esc_url(get_stylesheet_directory_uri().'/assets/images/boats-placeholders/boats-170.png'); ?>" class="img-responsive" alt="<?php esc_html_e('Placeholder', 'motors'); ?>" />
									<?php endif; ?>

									<?php $price = $boat->Price; $price = number_format($price, 0, '.', ','); if(!empty($price) and $price != 1): ?>
										<div class="price">
											<div class="normal-price">
												<span class="heading-font">$<?php echo $price; ?></span>
											</div>
										</div>
									<?php elseif($price = 1): // Used to display "Call" for some boats - for our dealer, the Call message is displayed if the boat price is set to "1" in the API ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php else: ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<div class="boats-image-unit">				
									<div class="stm-listing-photos-unit list-stm-car-photos-<?php echo $boat->DocumentID; //Give Fancybox a unique ID since multiple boats are displaye per page ?>">
										<i class="stm-boats-icon-camera"></i>
									<span><?php echo count($img); ?></span>
								</div>

								<script type="text/javascript">
									jQuery(document).ready(function(){
										jQuery(".list-stm-car-photos-<?php echo $boat->DocumentID; ?>").click(function(e) {
											e.preventDefault();
											jQuery.fancybox.open([
												<?php foreach($img as $url): ?>
													{ src  : "<?php echo $url->Uri; ?>" },
												<?php endforeach; ?>
											], { 
												padding: 0, 
												protect: true,
												smallBtn   : true,
												buttons : [
												    'zoom',
												    'thumbs',
												    'close'
											  	]
											});
										});
									});

								</script>
										</div>
							</a>
							<div class="links bti-row">
								<div class="bti-col-md-5"><a href="tel:2393092653" class="btn btn-round-outline"><i class="fa fa-phone" aria-hidden="true"></i> Call Us</a></div>
								<div class="bti-col-md-7"><a href="<?php echo site_url($link); ?>" class="btn btn-round-db bt-view-detail"><i class="fa fa-plus"></i> View Details</a></div>
							</div>
						</div>

						<div class="content bti-col-12 bti-col-md-6 bti-col-lg-<?php echo $column_right; ?>">
							<div class="meta-top">
								<div class="title heading-font">
									<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
										<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>
									</a>
								</div>
								<div class="excerpt">
									<p>
										<?php $text =  strip_tags($boat->GeneralBoatDescription[0]); echo implode(' ', array_slice(explode(' ', $text), 0, 20)); ?>
									</p>
								</div>
							</div>
							
							<div class="meta-middle">					
								<div class="meta-middle-unit font-exists ca-year">
									<div class="meta-middle-unit-top">
										<strong>Year</strong><div class="name"><?php echo $boat->ModelYear;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists boat-type">
									<div class="meta-middle-unit-top">
										<strong>Stock Number</strong><div class="name"><?php echo $boat->StockNumber; ?></div>
									</div>
								</div>																	
								<div class="meta-middle-unit font-exists condition">
									<div class="meta-middle-unit-top">
										<strong>Condition</strong><div class="name"><?php echo $boat->SaleClassCode;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists length_range">
									<div class="meta-middle-unit-top">
										<strong>Boat Length</strong><div class="name"><?php echo $boat->NominalLength;?></div>
									</div>
								</div>																									
								<div class="meta-middle-unit font-exists engine">
									<div class="meta-middle-unit-top">
										<strong>Engine</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Model; } $engnum++; } ?></div>
									</div>
								</div>	
								<?php if($boat->SaleClassCode != 'New'){ ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Boat Hours</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Hours; } $engnum++; } ?></div>
									</div>
								</div>
								<?php } ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Location</strong><div class="name"><?php echo $boat->BoatLocation->BoatCityName;?></div>
									</div>
								</div>						
							</div>

							<a href="<?php echo site_url($link); ?>" class="stm-car-view-more btn bti-d-block bti-d-md-none bt-view-detail"><?php esc_html_e('View more', 'motors'); ?></a>
						</div>
					</div>
				<?php endforeach; ?>
				</div>
			</div>
			<script type="text/javascript">
				jQuery('#download').on('click', function() {
					let url = jQuery(this).attr('data-url');
					let split = url.split("/");
					let name = split[split.length - 1];
					jQuery.ajax({
					  	url: url,
			            method: 'GET',
			            responseType: 'blob',
					})
					.done(function( response ) {
					    const url = window.URL.createObjectURL(new Blob([response]));
			            const link = document.createElement('a');
			            link.href = url;
			            link.setAttribute('download', name);
			            document.body.appendChild(link);
			            link.click();
					});
				});
			</script>
			<!-- Initiate Pagination (function near top of file) -->
			<?php $numpages = ceil($total/$rows); echo $this->pagination($numpages,3,$paged); ?>
			<?php } else { // If no boats from query results, display "No results" message ?>
				<div class="row">
					<div class="bti-col-md-12">
						<div class="stm-isotope-sorting">
							<h3><?php esc_html_e('Sorry, No results', 'motors'); ?></h3>
						</div>
					</div>
				</div>
			<?php } ?>
			<input type="hidden" name="total_row" value="<?php echo $total; ?>"/>
		<?php
		wp_die('');
	}

	public function action_get_inventory_latest() {
		global $wpdb;

		$column_left = "4";
		$column_right = "8";
		$column_grid_view = "6";

		#get post detail
		if(!empty($_POST['post_id'])) {
			$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = " . $_POST['post_id']);
		}

		if(!empty($post_detail)) {
			if(!empty($post_detail->post_filter_position) && $post_detail->post_filter_position == 2) {
				$column_left = "3";
				$column_right = "9";
				$column_grid_view = "4";
			}

			if(!empty($post_detail->post_filter)) {
				$aliases = array(
					"make"         => "make",
					"model"        => "exactModel",
					"boattype" 	   => "class",
					"condition"    => "condition",
					"hullmaterial" => "hull",
					"location"     => "BoatCityNameNoCaseAlnumOnly",
					"year"         => "year",
					"length"       => "length"
				);
				$post_filters = unserialize($post_detail->post_filter);
				foreach($post_filters as $post_filter) {
					$filter = json_decode($post_filter);
					$key_filter = key($filter);

					if($key_filter == "price") {
						$lowprice  = '0';
						$highprice =  '1000000';
						if(!empty($filter->price)) {
							if(!empty($filter->price[0])) {
								$lowprice = $filter->price[0];
							}

							if(!empty($filter->price[1])) {
								$highprice = $filter->price[1];
							}
						}

						$price = $lowprice . ':'. $highprice;

						$vars .= '&price=' . $price . '|USD';
						continue;
					}

					$value = $filter->{$key_filter};
					if(is_array($value)) {
						$value = implode(",", $value);
					}
					if($key_filter == 'length') {
						$value .= '|feet';
					}

					$vars .= '&' . $aliases[$key_filter] . '=' . $value;
				}
			}
		} else  {
			if(!empty($this->setting->filter_position) && $this->setting->filter_position == 2) {
				$column_left = "3";
				$column_right = "9";
				$column_grid_view = "4";
			}
		}

		/* GET AJAX VARIABLES */
		$stocknum = '';
		$rows = 10;

		if(isset($_POST['stocknum']) && ($_POST['stocknum'] != '')){ // Determines how many rows/items to display per page - if searching by stock number, must pull all rows from API first so the second search can be run; if not, use the row number specified in the POST
			$stocknum  =  $_POST['stocknum'];
			$rows = '200';

		} else {
			if(!empty($post_detail)) {
				$rows = $post_detail->post_row_limit;
			}
		}
		
		$paged = '1';
		if(isset($_POST['paged'])){
			$paged  =  $_POST['paged'];
			if($paged != 1){
				$offset = ($paged - 1) * $rows;	
				$vars .= '&offset=' . $offset; // This allows for pagination to work between the API and Wordpress; for example with a pagesize of 10, viewing page 3 would require an offset of 20 (so the first 20 listings are not displayed on page 3)
			}
		}

		$currentpage = '/inventory';
		if(isset($_POST['currentpage'])){
			$currentpage  =  $_POST['currentpage'];
		}

		if($paged > 1){

			if((isset($_POST['limit']) && ($_POST['limit'] != '')) && (isset($_POST['limit']) && ($_POST['limit'] != '-1'))){
				if(($_POST['limit'] - $offset) < 10){
					$rows = $_POST['limit'] - $offset;
				}
				else{
					$rows = 10;
				}
				echo 'row test: '.$_POST['limit'];	
			}	

		}
		
		$vars .= '&rows=' . $rows;
	
		// Condition

		if(isset($_POST['condition']) && $_POST['condition'] == 'news'){
			$condition  =  'new';
			$vars .= '&condition=' . $condition;
		}
		else if(isset($_POST['condition']) && $_POST['condition'] == 'all'){
			$condition  =  '';
			$vars .= '&condition=' . $condition;
		}
		else{
			if(isset($_POST['condition']) && $_POST['condition'] != ''){
				$condition  =  $_POST['condition'];
				$vars .= '&condition=' . $condition;
			}
		}

		// display: PriceHideInd

		if(isset($_POST['display']) && $_POST['display'] == 'with_price'){
			$display  =  'false';
			$vars .= '&PriceHideInd=' . $display;
		}

		$view_mode = "stm-list";
		if(isset($_POST['view_mode'])){
			$view_mode = $_POST['view_mode'];
		}
		
		$url = 'https://api.boats.com/inventory/search?key=' . $this->setting->api_key .'&status=active'. $vars;
		$getInventory = wp_remote_get( $url, array(
		        'timeout'     => 120,
		        'httpversion' => '1.1',
		    ) 
		);

		if((isset($_POST['limit']) && $_POST['limit'] != '') && isset($_POST['limit']) && $_POST['limit'] != '-1'){			
			$boats = $getInventory['body'];
			$boats = json_decode($boats);
			if($boats->numResults <= 10){
				$total = $boats->numResults;
			}
			else{
				$total = $_POST['limit']; 
			}			
			$boats = $boats->results; 
		}
		else{
			$boats = $getInventory['body'];
			$boats = json_decode($boats);
			$total = $boats->numResults;
			$boats = $boats->results;


		}		

		?> 
			<?php if(!empty($boats) && count($boats) > 0) {?>
			<!-- Check to see if the user searched for a Stock number before beginning to loop through boats -->
			<?php if($stocknum != ''){
				$boatstock = array();
				$stocknum = strtoupper($stocknum);
				foreach($boats as $boat){
					if($boat->StockNumber == $stocknum){
						array_push($boatstock, $boat);
					}
				}
				$boats = $boatstock;
				// count the total number (needed for pagination)
				$total = count($boatstock);
			} else { } ?>
			<div class="stm-grid bti-row <?php if($view_mode != 'stm-grid') { echo 'bti-d-none'; } ?>">
			<?php foreach($boats as $boat): ?>
				<div class="stm-isotope-sorting bti-col-md-6 bti-col-lg-<?php echo $column_grid_view; ?>">
					<div class="listing-list-loop stm-isotope-listing-item all bti-row" data-price="<?php echo $boat->Price; ?>" data-date="<?php echo $boat->ItemReceivedDate; ?>" >
						<div class="image bti-col-12">
							<?php if(!empty($boat->EmbeddedVideo)): ?>
								<span id="download" class="video-preview fancy-iframe" data-url="<?php $vids = $boat->Videos; echo esc_url( $vids->url[0] ); ?>"><i class="fa fa-film"></i><?php esc_html_e('Video', 'motors'); ?></span>
							<?php endif; ?>
							<?php
								$slug_single = 'boats';
								if(!empty($this->setting->slug_single)) $slug_single = $this->setting->slug_single;
								$link = '/' . $slug_single . '/' . $boat->MakeStringExact . '-' . $boat->ModelExact . '-' . $boat->ModelYear . '-' . $boat->DocumentID;

								if(!empty($this->setting) && !empty($this->setting->single_params)) {
									$params = unserialize($this->setting->single_params);
									$link = '/' . $slug_single .'/';
									foreach($params as $param) {
										if($param == 'none') continue;

										if($param == 'BoatLocation') {
											$link .= $boat->$param->BoatCityName . '-';
											continue;
										}
										if($param == 'BoatClassCode') {
											$link .= $boat->$param[0] . '-';
											continue;
										}
										$link .= $boat->$param . '-';
									}
									$link .= $boat->DocumentID;

								}
								$link = str_replace(' ', '-', $link);
								$link = strtolower($link); 
							?>
							<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
								<div class="image-inner">

									<?php if(!empty($boat->Images)): ?>
										<?php $img = $boat->Images; ?>
										<img src="<?php echo esc_url($img[0]->Uri); ?>" class="img-responsive" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
									<?php else: ?>
										<img src="<?php echo esc_url(get_stylesheet_directory_uri().'/assets/images/boats-placeholders/boats-170.png'); ?>" class="img-responsive" alt="<?php esc_html_e('Placeholder', 'motors'); ?>" />
									<?php endif; ?>

									<?php $price = $boat->Price; 
									$price = number_format($price, 0, '.', ','); 
									if(!empty($price) and $price != 1): ?>
										<div class="price">
											<div class="normal-price">
												<span class="heading-font">$<?php echo $price; ?></span>
											</div>
										</div>
									<?php elseif($price = 1): // Used to display "Call" for some boats - for our dealer, the Call message is displayed if the boat price is set to "1" in the API ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php else: ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<div class="boats-image-unit">				
									<div class="stm-listing-photos-unit grid-stm-car-photos-<?php echo $boat->DocumentID; //Give Fancybox a unique ID since multiple boats are displaye per page ?>">
										<i class="stm-boats-icon-camera"></i>
									<span><?php echo count($img); ?></span>
								</div>

								<script type="text/javascript">
									jQuery(document).ready(function(){
										jQuery(".grid-stm-car-photos-<?php echo $boat->DocumentID; ?>").click(function(e) {
											e.preventDefault();
											jQuery.fancybox.open([
												<?php foreach($img as $url): ?>
													{ src  : "<?php echo $url->Uri; ?>" },
												<?php endforeach; ?>
											], { 
												padding: 0, 
												protect: true,
												smallBtn   : true,
												buttons : [
												    'zoom',
												    'thumbs',
												    'close'
											  	]
											});
										});
									});

								</script>
										</div>
							</a>
							<div class="links bti-row">
								<div class="bti-col-md-5"><a href="tel:2393092653" class="btn btn-round-outline"><i class="fa fa-phone" aria-hidden="true"></i> Call Us</a></div>
								<div class="bti-col-md-7"><a href="<?php echo site_url($link); ?>" class="btn btn-round-db bt-view-detail"><i class="fa fa-plus"></i> View Details</a></div>
							</div>
						</div>

						<div class="content bti-col-12">
							<div class="meta-top">
								<div class="title heading-font">
									<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
										<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>
									</a>
								</div>
								<div class="excerpt">
									<p>
										<?php $text =  strip_tags($boat->GeneralBoatDescription[0]); echo implode(' ', array_slice(explode(' ', $text), 0, 20)); ?>
									</p>
								</div>
							</div>
							
							<div class="meta-middle">					
								<div class="meta-middle-unit font-exists ca-year">
									<div class="meta-middle-unit-top">
										<strong>Year</strong><div class="name"><?php echo $boat->ModelYear;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists boat-type">
									<div class="meta-middle-unit-top">
										<strong>Stock Number</strong><div class="name"><?php echo $boat->StockNumber; ?></div>
									</div>
								</div>																	
								<div class="meta-middle-unit font-exists condition">
									<div class="meta-middle-unit-top">
										<strong>Condition</strong><div class="name"><?php echo $boat->SaleClassCode;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists length_range">
									<div class="meta-middle-unit-top">
										<strong>Boat Length</strong><div class="name"><?php echo $boat->NominalLength;?></div>
									</div>
								</div>																									
								<div class="meta-middle-unit font-exists engine">
									<div class="meta-middle-unit-top">
										<strong>Engine</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Model; } $engnum++; } ?></div>
									</div>
								</div>	
								<?php if($boat->SaleClassCode != 'New'){ ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Boat Hours</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Hours; } $engnum++; } ?></div>
									</div>
								</div>
								<?php } ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Location</strong><div class="name"><?php echo $boat->BoatLocation->BoatCityName;?></div>
									</div>
								</div>						
							</div>

							<a href="<?php echo site_url($link); ?>" class="stm-car-view-more btn bti-d-block bti-d-md-none bt-view-detail"><?php esc_html_e('View more', 'motors'); ?></a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
			<div class="bti-row stm-list <?php if($view_mode != 'stm-list') { echo 'bti-d-none'; } ?>">
				<div class="stm-isotope-sorting bti-col-12">
				<!-- Check to see if the user searched for a Stock number before beginning to loop through boats -->
				<?php if($stocknum != ''){
					$boatstock = array();
					$stocknum = strtoupper($stocknum);
					foreach($boats as $boat){
						if($boat->StockNumber == $stocknum){
							array_push($boatstock, $boat);
						}
					}
					$boats = $boatstock;
					// count the total number (needed for pagination)
					$total = count($boatstock);
				} else { } ?>
				
				<?php foreach($boats as $boat): ?>
					<div class="listing-list-loop stm-isotope-listing-item all bti-row" data-price="<?php echo $boat->Price; ?>" data-date="<?php echo $boat->ItemReceivedDate; ?>" >
						<div class="image bti-col-12 bti-col-md-6 bti-col-lg-<?php echo $column_left; ?>">
							<?php if(!empty($boat->EmbeddedVideo)): ?>
								<span id="download" class="video-preview fancy-iframe" data-url="<?php $vids = $boat->Videos; echo esc_url( $vids->url[0] ); ?>"><i class="fa fa-film"></i><?php esc_html_e('Video', 'motors'); ?></span>
							<?php endif; ?>
							<?php
								$slug_single = 'boats';
								if(!empty($this->setting->slug_single)) $slug_single = $this->setting->slug_single;
								$link = '/' . $slug_single . '/' . $boat->MakeStringExact . '-' . $boat->ModelExact . '-' . $boat->ModelYear . '-' . $boat->DocumentID;

								if(!empty($this->setting) && !empty($this->setting->single_params)) {
									$params = unserialize($this->setting->single_params);
									$link = '/' . $slug_single .'/';
									foreach($params as $param) {
										if($param == 'none') continue;

										if($param == 'BoatLocation') {
											$link .= $boat->$param->BoatCityName . '-';
											continue;
										}
										if($param == 'BoatClassCode') {
											$link .= $boat->$param[0] . '-';
											continue;
										}
										$link .= $boat->$param . '-';
									}
									$link .= $boat->DocumentID;

								}
								$link = str_replace(' ', '-', $link);
								$link = strtolower($link); 
							?>
							<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
								<div class="image-inner">

									<?php if(!empty($boat->Images)): ?>
										<?php $img = $boat->Images; ?>
										<img src="<?php echo esc_url($img[0]->Uri); ?>" class="img-responsive" alt="<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>" />
									<?php else: ?>
										<img src="<?php echo esc_url(get_stylesheet_directory_uri().'/assets/images/boats-placeholders/boats-170.png'); ?>" class="img-responsive" alt="<?php esc_html_e('Placeholder', 'motors'); ?>" />
									<?php endif; ?>

									<?php 
									$price = $boat->Price; 
									$price = number_format($price, 0, '.', ','); 
									
									if(!empty($price) and $price != 1): ?>
										<div class="price">
											<div class="normal-price">
												<span class="heading-font">$<?php echo $price; ?></span>
											</div>
										</div>
									<?php elseif($price = 1): // Used to display "Call" for some boats - for our dealer, the Call message is displayed if the boat price is set to "1" in the API ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php else: ?>
									<div class="price">
											<div class="normal-price">
												<span class="heading-font">Call</span>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<div class="boats-image-unit">				
									<div class="stm-listing-photos-unit list-stm-car-photos-<?php echo $boat->DocumentID; //Give Fancybox a unique ID since multiple boats are displaye per page ?>">
										<i class="stm-boats-icon-camera"></i>
									<span><?php echo count($img); ?></span>
								</div>

								<script type="text/javascript">
									jQuery(document).ready(function(){
										jQuery(".list-stm-car-photos-<?php echo $boat->DocumentID; ?>").click(function(e) {
											e.preventDefault();
											jQuery.fancybox.open([
												<?php foreach($img as $url): ?>
													{ src  : "<?php echo $url->Uri; ?>" },
												<?php endforeach; ?>
											], { 
												padding: 0, 
												protect: true,
												smallBtn   : true,
												buttons : [
												    'zoom',
												    'thumbs',
												    'close'
											  	]
											});
										});
									});

								</script>
										</div>
							</a>
							<div class="links bti-row">
								<div class="bti-col-md-5"><a href="tel:2393092653" class="btn btn-round-outline"><i class="fa fa-phone" aria-hidden="true"></i> Call Us</a></div>
								<div class="bti-col-md-7"><a href="<?php echo site_url($link); ?>" class="btn btn-round-db bt-view-detail"><i class="fa fa-plus"></i> View Details</a></div>
							</div>
						</div>

						<div class="content bti-col-12 bti-col-md-6 bti-col-lg-<?php echo $column_right; ?>">
							<div class="meta-top">
								<div class="title heading-font">
									<a href="<?php echo site_url($link); ?>" class="rmv_txt_drctn bt-view-detail">
										<?php echo $boat->MakeStringExact . ' ' . $boat->ModelExact . ' ' . $boat->ModelYear; ?>
									</a>
								</div>
								<div class="excerpt">
									<p>
										<?php $text =  strip_tags($boat->GeneralBoatDescription[0]); echo implode(' ', array_slice(explode(' ', $text), 0, 20)); ?>
									</p>
								</div>
							</div>
							
							<div class="meta-middle">					
								<div class="meta-middle-unit font-exists ca-year">
									<div class="meta-middle-unit-top">
										<strong>Year</strong><div class="name"><?php echo $boat->ModelYear;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists boat-type">
									<div class="meta-middle-unit-top">
										<strong>Stock Number</strong><div class="name"><?php echo $boat->StockNumber; ?></div>
									</div>
								</div>																	
								<div class="meta-middle-unit font-exists condition">
									<div class="meta-middle-unit-top">
										<strong>Condition</strong><div class="name"><?php echo $boat->SaleClassCode;?></div>
									</div>
								</div>																		
								<div class="meta-middle-unit font-exists length_range">
									<div class="meta-middle-unit-top">
										<strong>Boat Length</strong><div class="name"><?php echo $boat->NominalLength;?></div>
									</div>
								</div>																									
								<div class="meta-middle-unit font-exists engine">
									<div class="meta-middle-unit-top">
										<strong>Engine</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Model; } $engnum++; } ?></div>
									</div>
								</div>	
								<?php if($boat->SaleClassCode != 'New'){ ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Boat Hours</strong><div class="name"><?php $engnum = 0; foreach($boat->Engines as $eng){ if($engnum == 0){ echo $eng->Hours; } $engnum++; } ?></div>
									</div>
								</div>
								<?php } ?>
								<div class="meta-middle-unit font-exists hull-color">
									<div class="meta-middle-unit-top">
										<strong>Location</strong><div class="name"><?php echo $boat->BoatLocation->BoatCityName;?></div>
									</div>
								</div>						
							</div>

							<a href="<?php echo site_url($link); ?>" class="stm-car-view-more btn bti-d-block bti-d-md-none bt-view-detail"><?php esc_html_e('View more', 'motors'); ?></a>
						</div>
					</div>
				<?php endforeach; ?>
				</div>
			</div>
			<script type="text/javascript">
				jQuery('#download').on('click', function() {
					let url = jQuery(this).attr('data-url');
					let split = url.split("/");
					let name = split[split.length - 1];
					jQuery.ajax({
					  	url: url,
			            method: 'GET',
			            responseType: 'blob',
					})
					.done(function( response ) {
					    const url = window.URL.createObjectURL(new Blob([response]));
			            const link = document.createElement('a');
			            link.href = url;
			            link.setAttribute('download', name);
			            document.body.appendChild(link);
			            link.click();
					});
				});
			</script>
			<!-- Initiate Pagination (function near top of file) -->
			<?php $numpages = ceil($total/10); echo $this->pagination($numpages,3,$paged); ?>
			<?php } else { // If no boats from query results, display "No results" message ?>
				<div class="row">
					<div class="bti-col-md-12">
						<div class="stm-isotope-sorting">
							<h3><?php esc_html_e('Sorry, No results', 'motors'); ?></h3>
						</div>
					</div>
				</div>
			<?php } ?>
			<input type="hidden" name="total_row" value="<?php echo $total; ?>"/>
		<?php
		wp_die('');
	}

	public function pagination($pages, $range, $paged){
	    if(empty($paged)) $paged = 1; // If the current page is not set, set to 1
		$result = '';
		if($pages > 1){
			$result .= "<div class='stm-blog-pagination bti-col-12'><ul class='page-numbers'>";
			for ($i=1; $i <= $pages; $i++) {
				if (0 != $pages ) {
				 	$result .= ($paged == $i)? "<li><a data-type='paging' class='page-numbers current inactive' href='".$i."'>".$i."</a></li>":"<li><a data-type='paging' class='page-numbers inactive' href='".$i."'>".$i."</a><li>";
				}
			}	
			$result .= "</ul></div>";
			return $result;
		}
	}

	public function my_template_redirect($original_template) {
		global $wpdb, $post;
		$url = $_SERVER["REQUEST_URI"];

		$params = explode("/", $_SERVER["REQUEST_URI"]);
		$slug_plugin = $params[(count($params) - 2)];
		if(
			($slug_plugin == $this->setting->slug && end($params) == '') || 
			(
				$slug_plugin != $this->setting->slug && 
				(
					end($params) ==  $this->setting->slug || 
					end($params) == 'boat-search-results' ||
					$slug_plugin == 'boat-search-results' ||
					strpos(end($params),"boat-search-results") !== false
				)
			)
		) {
			$post = null;

			if(end($params) == 'boat-search-results' || $slug_plugin == 'boat-search-results' || strpos(end($params),"boat-search-results") !== false) {
				include_once plugin_dir_path( __FILE__ ) .'partials/search/inventory-cms-layout.php';
				exit;
			}
			include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-layout.php';
			exit;
		}

		#check REQUEST_URI redirect RSS
		if(($params[(count($params) - 3)] == $this->setting->slug && $slug_plugin == 'used-boats') 
			|| ($params[(count($params) - 2)] == $this->setting->slug && end($params) == 'used-boats')) {
			include_once plugin_dir_path( __FILE__ ) .'rss-used-boats.php';
			exit;
		}

		$slug_single = 'boats';
		if(!empty($this->setting->slug_single)) {
			$slug_single = $this->setting->slug_single;
		
		}

		$boats = strpos($url, $this->setting->slug_single);
		if($boats !== false){
			$setting = $this->setting;
			$fields = [];
			$table_field = $wpdb->get_results("SELECT * FROM {$this->table_attribute}");
			foreach($table_field as $field) {
				$fields[$field->field_key] = $field;
			}
			include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-single-boat.php';
			exit;
		}
	}

	//Creating rewrite urls to recognize when a boat listing is to be dislayed
	public function my_add_rewrite_rules( $wp_rewrite ) {
		$newrules = array();
		$rule = '^boats/';
		$slug = 'page.php?';
		if(!empty($this->setting) && !empty($this->setting->single_params)) {
			$params = array_merge(unserialize($this->setting->single_params), ['id']);

			if(!empty($this->setting->slug_single)) {
				$rule = '^' . $this->setting->slug_single .'/';
			}
			
			$key = 1;
			foreach($params as $param) {
				if($param == 'none') continue;
				$rule .= '(.*)-';
				$slug .= $param . '=$matches[' . $key . ']';
				$key++;
			}
		}
		
		$new_rules[trim($rule, '-')] = $slug;
		$new_rules['^boat-search-results/?$'] = 'page.php';
		$new_rules['^boat-search-results?$'] = 'page.php';
		$wp_rewrite->rules = $new_rules + $wp_rewrite->rules;
	}

	public function custom_page_title( $title  ) {
		global $post;
		$params = explode("/", $_SERVER["REQUEST_URI"]);
		$slug_plugin = $params[(count($params) - 2)];
		if(
			($slug_plugin == $this->setting->slug && end($params) == '') || 
			(
				$slug_plugin != $this->setting->slug && 
				(
					end($params) ==  $this->setting->slug || 
					end($params) == 'boat-search-results' ||
					$slug_plugin == 'boat-search-results' ||
					strpos(end($params),"boat-search-results") !== false
				)
			)
		) {
			$title = $this->setting->name_default;
			if(end($params) == 'boat-search-results' || $slug_plugin == 'boat-search-results' || strpos(end($params),"boat-search-results") !== false) {
				$title = 'Boat search results';
			}
		} else {
			$title = !empty($post) ? $post->post_title : '';
		}
		return $title;
	}

	public function customRSS(){
		add_feed('used-boats', array($this, 'customRSSFunc'));
	}

	public function customRSSFunc(){
	    include_once plugin_dir_path( __FILE__ ) .'rss-used-boats.php';
	}

	public function simple_search_shortcode($args, $content) {
		ob_start();
		?>
			<form method="get" id="bti-form-search" action="<?php echo site_url('/boat-search-results'); ?>">
				<div class="bti-simple-search">
					<div class="stock-search">
						<input type="text" name="bti-search" id="search" placeholder="Search: Stock#, Model, Manufacturer" class="bti-form-control">
						<button type="submit" id="bti-bnt-search"><em class="fa fa-search"></em></button>
					</div>
				</div>
			</form>
		<?php
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	public function latest_boats_shortcode($args, $content) {
		
		ob_start();

		global $wpdb;	

		if(!empty($args['condition'])){
			$condition = $args['condition'];
		}
		else{
			$condition = null; 
		}

		if(!empty($args['limit'])){
			$limit = $args['limit'];
		}
		else{
			$limit = ''; 
		}
		if(!empty($args['display']) && $args['display']=='with_price'){
			$display = $args['display'];
		}
		else{
			$display = 'all'; 
		}

		$_SESSION['condition'] = $condition;
		$_SESSION['limit'] = $limit;
		$_SESSION['display'] = $display;
	
		include_once plugin_dir_path( __FILE__ ) .'partials/inventory-latest-layout.php';		

		$template_latest_boats = ob_get_contents();

		ob_end_clean();

		echo '<div class="latest-boats latest-boat-section">'.$template_latest_boats.'</div>';
	}
	public function boat_register_session(){
	    if( !session_id() ) {
	        session_start();
		}
	}
}
