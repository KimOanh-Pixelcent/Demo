<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Inventory_Cms
 * @subpackage Inventory_Cms/admin
 * @author     Your Name <email@example.com>
 */
class Inventory_Cms_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $inventory_cms    The ID of this plugin.
	 */
	private $inventory_cms;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $inventory_cms       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	private $post_type = "inventory";

	private $setting;
	private $table_field;
	private $table_attribute;
	private $table_setting;
	private $table_page_detail;
	private $table_page_sort_options;
	private $table_page_filter_options;
	private $table_form_submits;

	public function __construct( $inventory_cms, $version ) {
		global $wpdb;
		$this->version = $version;
		$this->inventory_cms = $inventory_cms;

		$this->table_field = $wpdb->prefix . (defined( 'TABLE_FIELD' ) && TABLE_FIELD != '' ? TABLE_FIELD : 'bt_inventory_field');
		$this->table_attribute = $wpdb->prefix . (defined( 'TABLE_ATTRIBUTE' ) && TABLE_ATTRIBUTE != '' ? TABLE_ATTRIBUTE : 'bt_inventory_attributes');
		$this->table_setting = $wpdb->prefix . (defined( 'TABLE_SETTING' ) && TABLE_SETTING != '' ? TABLE_SETTING : 'bt_inventory_setting');
		$this->table_page_detail = $wpdb->prefix . (defined( 'TABLE_PAGE_DETAIL' ) && TABLE_PAGE_DETAIL != '' ? TABLE_PAGE_DETAIL : 'bt_inventory_page_detail');
		$this->table_form_submits = $wpdb->prefix . (defined( 'TABLE_FORM_SUBMITS' ) && TABLE_FORM_SUBMITS != '' ? TABLE_FORM_SUBMITS : 'bt_inventory_form_submits');
		$this->table_page_sort_options = $wpdb->prefix . (defined( 'TABLE_PAGE_SORT_OPTIONS' ) && TABLE_PAGE_SORT_OPTIONS != '' ? TABLE_PAGE_SORT_OPTIONS : 'bt_inventory_page_sort_options');
		$this->table_page_filter_options = $wpdb->prefix . (defined( 'TABLE_PAGE_FILTER_OPTIONS' ) && TABLE_PAGE_FILTER_OPTIONS != '' ? TABLE_PAGE_FILTER_OPTIONS  : 'bt_inventory_page_filter_options');
		
		$this->setting = $wpdb->get_row("SELECT * FROM {$this->table_setting} where id = 1");
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Inventory_Cms_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Inventory_Cms_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->inventory_cms, plugin_dir_url( __FILE__ ) . 'css/inventory-cms-admin.css', array(), $this->version, 'all' );
		wp_enqueue_style( "btiSelect2-css", plugin_dir_url( __FILE__ ) . 'css/select2.min.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Inventory_Cms_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Inventory_Cms_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( 'uiJquery',  plugin_dir_url( __FILE__ ) . 'js/jquery-ui.min.js', array( 'jquery' ));
		wp_enqueue_script( 'btiSelect2',  plugin_dir_url( __FILE__ ) . 'js/select2.full.min.js', array( 'jquery' ));
		wp_enqueue_script( $this->inventory_cms, plugin_dir_url( __FILE__ ) . 'js/inventory-cms-admin.js', array( 'jquery' ), $this->version, false );
		wp_localize_script( $this->inventory_cms, "bt_inventory", array(
			"ajax_url" => admin_url('admin-ajax.php')
		));

	}

	public function add_pages() {
		$labels = array(
			'label' => 'BT Inventory',
			'name' => 'BT Inventory',
			'menu_name' => 'BT Inventory',
			'singular_name' => 'BT Inventory',
			'add_new' => 'Add New Page',
			'all_items' => 'All Pages',
			'add_new_item' => 'Add Page',
			'edit_item' => 'Edit Page',
			'new_item' => 'New Page',
			'view_item' => 'View Page',
			'search_item' => 'Search Page',
			'not_found' => 'No items found',
			'not_found_in_trash' => 'No items found in trash',
			'parent_item_colon' => 'Parent Item'
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'has_archive' => true,
			'slug' => 'bt-inventory',
			'publicly_queryable' => true,
			'query_var' => true,
		 	'rewrite' => array( 'slug' => !empty($this->setting) && !empty($this->setting->slug) ? $this->setting->slug : 'inventory' ),
			'capability_type' => 'page',
			'hierarchical' => false,
			'supports' => array(
				'title',
				'editor',
				'excerpt',
				'thumbnail',
				'revisions',
			),
			'menu_position' => 10,
			'menu_icon'           => 'dashicons-performance',
			'exclude_from_search' => false
		);
		register_post_type($this->post_type, $args);
		flush_rewrite_rules ();
	}

	/*add submenu*/
	public function add_submenu_plugin() {
		add_submenu_page("edit.php?post_type=inventory", "Settings", "Settings", "manage_options", "{$this->inventory_cms}-setting", array($this, "bt_inventory_setting"));
		add_submenu_page("edit.php?post_type=inventory", "Users Submitted", "Users Submitted", "manage_options", "{$this->inventory_cms}-submit-form", array($this, "bt_inventory_list_submit_form"));
	}

	public function bt_inventory_setting() {
		global $wpdb;
		$setting = $this->setting;
		$post_type = $this->post_type;
		$name_plugin = "{$this->inventory_cms}-setting";

  		$tab = isset($_GET['tab']) ? $_GET['tab'] : null;

  		if($tab === null) {
  			#sort
		    $sort = $wpdb->get_col("SELECT field_id FROM {$this->table_page_sort_options} WHERE post_id = 0 ORDER BY sort");
			if(empty($sort)) {
				$field_sorts = $wpdb->get_results("SELECT * FROM {$this->table_field}");
			} else {
				$field_sorts = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_sort_options} ON {$this->table_page_sort_options}.field_id = {$this->table_field}.id WHERE post_id = 0 UNION SELECT id, field_key, field_value, null as post_id, null as field_id, null as sort FROM {$this->table_field} WHERE {$this->table_field}.id NOT IN (" . implode(",",$sort) . ") ORDER BY case when sort is null then 1 else 0 end");
			}

			#filter
			$filter = $wpdb->get_col("SELECT field_id FROM {$this->table_page_filter_options} WHERE post_id = 0 ORDER BY sort");
			if(empty($filter)) {
				$field_filters = $wpdb->get_results("SELECT * FROM {$this->table_field}");
			} else {
				$field_filters = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_filter_options} ON {$this->table_page_filter_options}.field_id = {$this->table_field}.id WHERE post_id = 0 UNION SELECT id, field_key, field_value, null as post_id, null as field_id, null as sort FROM {$this->table_field} WHERE {$this->table_field}.id NOT IN (" . implode(",",$filter) . ") ORDER BY case when sort is null then 1 else 0 end");
			}
		}

		if($tab == 'single-boat') {
  			$field_attributes = [];
			$table_field = $wpdb->get_results("SELECT * FROM {$this->table_attribute}");
			foreach($table_field as $field) {
				$field_attributes[$field->field_key] = $field;
			}

			$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		}

		ob_start();
		include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-admin-setting.php';
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	public function bt_inventory_list_submit_form() {
		ob_start();
		include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-admin-list-submit-form.php';
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}

	/*begin - add meta box*/
	public function add_meta_box_filter() {
		add_meta_box( 'meta-box-custom-1', 'BT Inventory Filters', array($this, 'hcf_display_callback'), $this->post_type );
		add_meta_box( 'meta-box-custom-2', 'BT Inventory Filter Option', array($this, 'filter_options_callback'), $this->post_type );
		add_meta_box( 'meta-box-custom-3', 'BT Inventory Filter Position', array($this, 'filter_position_callback'), $this->post_type );
		add_meta_box( 'meta-box-custom-4', 'BT Inventory Sort Option', array($this, 'sort_options_callback'), $this->post_type );
		remove_meta_box( 'postexcerpt', $this->post_type, 'normal' );
	}

	public function hcf_display_callback() {
		global $wpdb, $post;
		$post_filters = [];
		if(!empty($post)) {
			$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = " . $post->ID);
			if(!empty($post_detail) && !empty($post_detail->post_filter)) {
				$post_filters = unserialize($post_detail->post_filter);
			}
		}
		
		$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		$filters = [];
		?>
			<div class="bt-inventory-page-filter">
				<div class="page-filter-title flex">
					<h4><i>Add Filter</i></h4>
					<select name="field" id="bt-inventory-field">
						<option disabled selected value="None">Choose a filter</option>
						<?php 
							foreach ($fields as $field) {
								echo '<option value="' . $field->field_key . '">' . $field->field_value . '</option>';
								$filters[$field->field_key] = $field->field_value;
							} 
						?>
					</select>
				</div>
				<div class="bt-loader bt-d-none"><i class="fa fa-spinner fa-spin">&nbsp;</i></a></div>
				<div class="page-filter-content">
					<div class="alert">
						<div class="title">
							<span>Filter results by <strong id="field-choosen">Price</strong></span>
							<span class="closebtn close-alert">&times;</span>
						</div>
						<div class="content flex">
							<div id="bt-inventory-filter-ajax"></div>
							<div class="group-btn">
								<button type="button" class="btn-transparent close-alert">Cancel</button>
								<button type="button" class="btn-submit" id="btn-update-filter">Update this Filter</button>
							</div>
						</div>
					</div>
					<div class="flex">
						<span>Filters</span>
						<div id="list-filter-tag">
							<?php
								if(count($post_filters) > 0) {
									foreach($post_filters as $post_filter) {
										$val = json_decode($post_filter, true);
										$key = key($val);
										$html = $filters[$key] . ': ';
										if(is_array($val[$key])) {
											$sign = ',';
											if($key == 'price') $sign = ':';
											$html .= '<u><strong>' . implode($sign, $val[key($val)]) . '</strong></u>';
										} else {
											$html .= '<u><strong>' . $val[key($val)] . '</strong></u>';
										}
										echo "<div class='filter-tag ". $key ."' id='".$key."' data-text='".$filters[$key]."'><span>" . $html . "</span><input type='hidden' name='page_filters[]' value='" . $post_filter ."' /><button type='button' class='btn-close tag-close'>×</button></div>";
									}
									$json = json_encode($post_filters);
									echo "<input type='hidden' name='post_filters' value='{$json}'/>";
								}
							?>
						</div>
					</div>
				</div>
			</div>
		<?php
	}

	public function filter_options_callback() {
		global $wpdb, $post;
		$filter = $wpdb->get_col("SELECT field_id FROM {$this->table_page_filter_options} WHERE post_id = " . $post->ID . " ORDER BY sort");
		if(empty($filter)) {
			$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		} else {
			$fields = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_filter_options} ON {$this->table_page_filter_options}.field_id = {$this->table_field}.id WHERE post_id = " . $post->ID . " UNION SELECT id, field_key, field_value, null as post_id, null as field_id, null as sort FROM {$this->table_field} WHERE {$this->table_field}.id NOT IN (" . implode(",",$filter) . ") ORDER BY case when sort is null then 1 else 0 end");
		}

		?>
			<div class="bt-inventory-page-filter">
				<ul id="bt-inventory-sortable" class="bt-inventory-ui-sortable" name="filters">
					<?php 
						foreach ($fields as $field) {
							$html_li = '<li class="bt-inventory-sort-item ' . (!empty($field->sort) ?  'active' : '') .'" data-key="' . $field->field_key .'"><span class="dashicons' . (!empty($field->sort) ?  ' dashicons-yes-alt' : '') .'"></span>' . $field->field_value;

							if(!empty($field->sort)) {
								$html_li .= '<input type="hidden" name="filters[]" value="' . $field->field_key . '">';
							}

							$html_li .= '</li>';
							echo $html_li;
						}
					?>
				</ul>
			</div>
		<?php
	}

	public function filter_position_callback() {
		global $wpdb, $post;
		$post_filter_position = $this->setting->filter_position;

		$page_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = '{$post->ID}'");
		if(!empty($page_detail)) {
			$post_filter_position = $page_detail->post_filter_position;
		}

		?>
			<label><strong>Position:</strong></label>
			<div class="box-meta-filter-position">
				<div class="bti-form-group">
					<input type="radio" name="post_filter_position" value="1" <?php if(!empty($post_filter_position) && $post_filter_position == 1) { echo "checked"; } ?>><label for="post_filter_position">Left</label><br>
				</div>
				<div class="bti-form-group">
					<input type="radio" name="post_filter_position" value="2" <?php if(!empty($post_filter_position) && $post_filter_position == 2) { echo "checked"; } ?>><label for="post_filter_position">Top</label><br>
				</div>
			</div>
		<?php
	}

	public function sort_options_callback() {
		global $wpdb, $post;
		$sort = $wpdb->get_col("SELECT field_id FROM {$this->table_page_sort_options} WHERE post_id = " . $post->ID . " ORDER BY sort");
		if(empty($sort)) {
			$fields = $wpdb->get_results("SELECT * FROM {$this->table_field}");
		} else {
			$fields = $wpdb->get_results("SELECT {$this->table_field}.id, field_key, field_value, post_id, field_id, sort FROM {$this->table_field} LEFT JOIN {$this->table_page_sort_options} ON {$this->table_page_sort_options}.field_id = {$this->table_field}.id WHERE post_id = " . $post->ID . " UNION SELECT id, field_key, field_value, null as post_id, null as field_id, null as sort FROM {$this->table_field} WHERE {$this->table_field}.id NOT IN (" . implode(",",$sort) . ") ORDER BY case when sort is null then 1 else 0 end");
		}

		?>
			<ul id="bt-inventory-option-sortable" class="bt-inventory-ui-sortable" name="sorts">
				<?php 
					foreach ($fields as $field) {
						if($field->field_key == 'boattype' || $field->field_key == 'hullmaterial') continue;
						$html_li = '<li class="bt-inventory-sort-item ' . (!empty($field->sort) ?  'active' : '') .'" data-key="' . $field->field_key .'"><span class="dashicons' . (!empty($field->sort) ?  ' dashicons-yes-alt' : '') .'"></span>' . $field->field_value;

						if(!empty($field->sort)) {
							$html_li .= '<input type="hidden" name="sorts[]" value="' . $field->field_key . '">';
						}

						$html_li .= '</li>';
						echo $html_li;
					}
				?>
			</ul>
		<?php
	}
	/*end - add meta box*/

	public function handle_ajax_request_field_data() {
		global $wpdb;
		$param = isset($_REQUEST["param"]) ? $_REQUEST["param"] : "";

		if(!empty($param)) {
			if($param == "field_data_inventory_ajax") {
				if(empty($this->setting) || empty($this->setting->api_key)) {
					wp_send_json(
						array(
							"status" => 0,
							"msg"   => "API key does not exist. Please go to settings to enter API KEY"
						)
					);
				}
				
				$field = isset($_REQUEST["field"]) ? $_REQUEST["field"] : "";
				if(!empty($field)) {
					wp_send_json(
						array(
							"status" => 1,
							"data"   => $this->get_data_field_api_board($field)
						)
					);
				}
			}

			/* save setting */
			if($param == "update_setting" || $param == "update_setting_recaptcha" || $param == "update_setting_single_boat") {

				if($param == "update_setting") {
					$data = [
						"slug"              => isset($_REQUEST["slug"]) ? trim($_REQUEST["slug"]) : '',
						"name_default"      => isset($_REQUEST["name_default"]) ? trim($_REQUEST["name_default"]) : '',
						"api_key"           => isset($_REQUEST["api_key"]) ? trim($_REQUEST["api_key"]) : '',
						"row_limit"         => isset($_REQUEST["row_limit"]) ? trim($_REQUEST["row_limit"]) : '',
						"primary_color"     => isset($_REQUEST["primary_color"]) ? trim($_REQUEST["primary_color"]) : '',
						"primary_color_btn" => isset($_REQUEST["primary_color_btn"]) ? trim($_REQUEST["primary_color_btn"]) : '',
						"filter_position"   => isset($_REQUEST["filter_position"]) ? $_REQUEST["filter_position"] : ''
					];

					if(empty($data['slug']) || empty($data['name_default']) || empty($data['api_key']) || empty($data['row_limit'])) {
						wp_send_json(
							array(
								"status" => 0,
								"msg"    => "Slug Page or Default Page Name or Limit Page or API Key don't exists."
							)
						);
						wp_die();
					}

					if($data['slug'] == 'boats') {
						wp_send_json(
							array(
								"status" => 0,
								"msg"    => "Slug has already existed."
							)
						);
						wp_die();
					}

					$post_id = 0;
					$wpdb->delete($this->table_page_filter_options, array("post_id" => $post_id));
					$wpdb->delete($this->table_page_sort_options, array("post_id" => $post_id));

					#Filter
					$filters = isset($_REQUEST["filters"]) ? $_REQUEST["filters"] : [];
					if(count($filters)) {
						$inser_query_filters = "INSERT INTO " . $this->table_page_filter_options . " (post_id, field_id, sort) VALUES ";
						foreach($filters as $key => $filter) {
							$id = $wpdb->get_var("SELECT id FROM {$this->table_field} WHERE field_key = '" . $filter . "'");
							if(!empty($id)) {
								$inser_query_filters .= "(" . $post_id . ", " . $id .", " . ($key + 1) ."), ";
							}
						}

						$wpdb->query(trim($inser_query_filters, ", "));
					}
					

					#Sort
					$sorts = isset($_REQUEST["sorts"]) ? $_REQUEST["sorts"] : [];
					if(count($sorts)) {
						$inser_query_sorts = "INSERT INTO " . $this->table_page_sort_options . " (post_id, field_id, sort) VALUES ";
						foreach($sorts as $key => $sort) {
							$id = $wpdb->get_var("SELECT id FROM {$this->table_field} WHERE field_key = '" . $sort . "'");
							if(!empty($id)) {
								$inser_query_sorts .= "(" . $post_id . ", " . $id .", " . ($key + 1) ."), ";
							}
						}

						$wpdb->query(trim($inser_query_sorts, ", "));
					}
				}

				if($param == "update_setting_recaptcha") {
					$data = [
						"type_recaptcha"         => isset($_REQUEST["recaptcha"]) ? trim($_REQUEST["recaptcha"]) : '',
						"username_smtp" => isset($_REQUEST["username_smtp"]) ? trim($_REQUEST["username_smtp"]) : '',
						"password_smtp" => isset($_REQUEST["password_smtp"]) ? trim($_REQUEST["password_smtp"]) : '',
						"from_name"     => isset($_REQUEST["from_name"]) ? trim($_REQUEST["from_name"]) : '',
						"from_email"    => isset($_REQUEST["from_email"]) ? trim($_REQUEST["from_email"]) : '',
						"subject_email" => isset($_REQUEST["subject_email"]) ? trim($_REQUEST["subject_email"]) : '',
						"message_email" => isset($_REQUEST["message_email"]) ? htmlentities(wpautop($_REQUEST["message_email"])) : '',
						"notice_thanks" => isset($_REQUEST["notice_thanks"]) ? trim($_REQUEST["notice_thanks"]) : '',
					];


					if($data['type_recaptcha'] == 2) {
						if(empty($_REQUEST["site_key_recaptcha_2"]) || empty($_REQUEST["secret_key_recaptcha_2"])) {
							wp_send_json(
								array(
									"status" => 0,
									"msg"   => "Site Key or Secret Key don't exists."
								)
							);
							wp_die();
						}
						$data['site_key_recaptcha_2']   = trim($_REQUEST["site_key_recaptcha_2"]);
						$data['secret_key_recaptcha_2'] = trim($_REQUEST["secret_key_recaptcha_2"]);
					}

					if($data['type_recaptcha'] == 3) {
						if(empty($_REQUEST["site_key_recaptcha_3"]) || empty($_REQUEST["secret_key_recaptcha_3"])) {
							wp_send_json(
								array(
									"status" => 0,
									"msg"   => "Site Key or Secret Key don't exists."
								)
							);
							wp_die();
						}
						$data['site_key_recaptcha_3']   = trim($_REQUEST["site_key_recaptcha_3"]);
						$data['secret_key_recaptcha_3'] = trim($_REQUEST["secret_key_recaptcha_3"]);
					}

					if(empty($data['username_smtp']) || empty($data['password_smtp']) || empty($data['subject_email']) || empty($data['message_email'])|| empty($data['notice_thanks'])) {
						wp_send_json(
							array(
								"status" => 0,
								"msg"   => "Username STMP or Password SMTP or Subject or Message or Notice Thank You don't exists."
							)
						);
						wp_die();
					}
				}

				if($param == "update_setting_single_boat") {
					$data = [
						"slug_single"       => isset($_REQUEST["slug_single"]) ? trim($_REQUEST["slug_single"]) : null,
						"single_params"     => isset($_REQUEST["params"]) ? serialize($_REQUEST["params"]) : ["make", "model", "year"],
						"single_attributes" => isset($_REQUEST["sorts"]) ? serialize($_REQUEST["sorts"]) : null,
						"single_disclaimer" => isset($_REQUEST["single_disclaimer"]) ? trim($_REQUEST["single_disclaimer"]) : null
					];
				}

				$check_exists = $wpdb->get_row("SELECT * FROM {$this->table_setting} WHERE id = 1");
				if(!empty($check_exists)) {
					$wpdb->update($this->table_setting, $data, array("id" => 1));

				} else {
					$wpdb->insert($this->table_setting, $data);
				}

				wp_send_json(
					array(
						"status" => 1,
						"msg"   => "Updated Successfully!"
					)
				);
			}
		}

		wp_die();
	}

	public function get_data_field_api_board($field = '') {
		
		$data = array(
			"make"         => array(),
			"model"        => array(),
			"boattype" 	   => array(),
			"condition"    => array(),
			"hullmaterial" => array(),
			"location"     => array(),
			"year"         => array()
		);

		if(empty($field) || !isset($data[$field])) {
			return array();
		}

		if(empty($this->setting) || empty($this->setting->api_key)) {
			return array();
		}
		$rows = 200;
		$vars .= '&rows=' . $rows;
		$url = 'https://api.boats.com/inventory/search?key=' . $this->setting->api_key . '&status=active' . $vars; 

		$getInventory = wp_remote_get( $url, array(
		        'timeout'     => 120,
		        'httpversion' => '1.1',
		    ) 
		);
		$boats = $getInventory['body'];
		$boats = json_decode($boats);
		$boats = $boats->results;
		if(!empty($boats)) {
			
			foreach($boats as $boat) {
				//find all the filters that are actually used by the boats pulled in, and push boat values into the arrays defined above
				array_push($data['make'], $boat->MakeString);
				array_push($data['model'], $boat->Model);
				foreach($boat->BoatClassCode as $boatclass){
					array_push($data['boattype'], $boatclass);
				}
				array_push($data['condition'],$boat->SaleClassCode);
				array_push($data['hullmaterial'],$boat->BoatHullMaterialCode);
				array_push($data['location'],$boat->BoatLocation->BoatCityName);
				array_push($data['year'], $boat->ModelYear);
			}

			//only save one instance of each parameter
			$data['make'] = array_unique($data['make']);
			$data['model'] = array_unique($data['model']);
			$data['boattype'] = array_unique($data['boattype']);
			$data['condition'] = array_unique($data['condition']);
			$data['hullmaterial'] = array_unique($data['hullmaterial']);
			$data['location'] = array_unique($data['location']);
			$data['year']  =array_unique($data['year']);

			sort($data['make']);
			sort($data['model']);
			sort($data['boattype']);
			sort($data['condition']);
			sort($data['hullmaterial']);
			sort($data['location']);
			sort($data['year']);
		}

		return $data[$field];
	}

	public function save_post_callback() {
		global $post, $wpdb;

		if(!empty($post)) {
			#Delele filter and sort
			$wpdb->delete($this->table_page_filter_options, array("post_id" => $post->ID));
			$wpdb->delete($this->table_page_sort_options, array("post_id" => $post->ID));

			#Filter
			$filters = isset($_REQUEST["filters"]) ? $_REQUEST["filters"] : [];
			if(count($filters)) {
				$insert_query_filters = "INSERT INTO " . $this->table_page_filter_options . " (post_id, field_id, sort) VALUES ";
				foreach($filters as $key => $filter) {
					$id = $wpdb->get_var("SELECT id FROM {$this->table_field} WHERE field_key = '" . $filter . "'");
					if(!empty($id)) {
						$insert_query_filters .= "(" . $post->ID . ", " . $id .", " . ($key + 1) ."), ";
					}
				}

				$wpdb->query(trim($insert_query_filters, ", "));
			}
			

			#Sort
			$sorts = isset($_REQUEST["sorts"]) ? $_REQUEST["sorts"] : [];
			if(count($sorts)) {
				$insert_query_sorts = "INSERT INTO " . $this->table_page_sort_options . " (post_id, field_id, sort) VALUES ";
				foreach($sorts as $key => $sort) {
					$id = $wpdb->get_var("SELECT id FROM {$this->table_field} WHERE field_key = '" . $sort . "'");
					if(!empty($id)) {
						$insert_query_sorts .= "(" . $post->ID . ", " . $id .", " . ($key + 1) ."), ";
					}
				}

				$wpdb->query(trim($insert_query_sorts, ", "));
			}
			

			#Save post detail sort
			$post_filter = NULL;
			if(isset($_REQUEST["page_filters"])) {
				$page_filters = $_REQUEST['page_filters'];
				foreach($page_filters as $key => $filter) {
					$page_filters[$key] = str_replace('\"', '"', $filter);
				}

				$post_filter = serialize($page_filters);
			}

			$post_detail = $wpdb->get_row("SELECT * FROM {$this->table_page_detail} WHERE post_id = " . $post->ID);
			if(empty($post_detail)) {
				$wpdb->insert($this->table_page_detail, array(
					"post_id"     		   => $post->ID,
					"post_filter" 		   => $post_filter,
					"post_filter_position" => isset($_REQUEST["post_filter_position"]) ? $_REQUEST["post_filter_position"] : $this->setting->filter_position
				));
			}
			else {
				$wpdb->update($this->table_page_detail, array(
					"post_id"     		   => $post->ID,
					"post_filter" 		   => $post_filter,
					"post_filter_position" => isset($_REQUEST["post_filter_position"]) ? $_REQUEST["post_filter_position"] : $this->setting->filter_position
				), array("post_id" => $post->ID));
			}
		}
	}

	/*add custom widget sidebar*/
	public function register_widgets_init() {
	    register_sidebar( array(
	        'name'          => __( 'BT Inventory Sidebar Listing', 'theme_name' ),
	        'id'            => 'sidebar-bt-inventory-listing',
	        'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
	        'after_widget'  => '</li></ul>',
	        'before_title'  => '<h3 class="widget-title">',
	        'after_title'   => '</h3>',
	    ));

	    register_sidebar( array(
	        'name'          => __( 'BT Inventory Sidebar Detail', 'theme_name' ),
	        'id'            => 'sidebar-bt-inventory-detail',
	        'before_widget' => '<ul><li id="%1$s" class="widget %2$s">',
	        'after_widget'  => '</li></ul>',
	        'before_title'  => '<h3 class="widget-title">',
	        'after_title'   => '</h3>',
	    ));

		require_once plugin_dir_path( __FILE__ ) . 'widget-form.php';
	    $widge_form = new WP_Widget_Form();
	    register_widget($widge_form);

	    require_once plugin_dir_path( __FILE__ ) . 'widget-contact.php';
	    $widget_contact = new WP_Widget_Contact();
	    register_widget($widget_contact);
	}

	public function handle_submit_form_more_info() {
		global $wpdb;
		$action = isset($_POST['action']) ? $_POST['action'] : '';
		if($action == 'submit_action_send_mail_more_info') {
			if(isset($_POST['g-recaptcha-response'])) {
				$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$this->setting->secret_key_recaptcha_3."&response={$_POST['g-recaptcha-response']}");
		        $resp = json_decode($response);
		        if(!$resp->success || $resp->score < 0.5) {
		        	wp_send_json(
						array(
							"status" => 0,
							"msg"    => 'Recaptcha verification failed. Please try again.'
						)
					);
		        }
			}
			
			$data = [
				'email'       => isset($_POST['email']) ? $_POST['email'] : '',
				'phone'       => isset($_POST['phone']) ? $_POST['phone'] : '',
				'description' => isset($_POST['description']) ? $_POST['description'] : '',
				'first_name'  => isset($_POST['first_name']) ? $_POST['first_name'] : '',
				'last_name'   => isset($_POST['last_name']) ? $_POST['last_name'] : '',
				'date_submit' => date('Y-m-d H:s:i', time()),
			];
			
			$is_send = $this->send_email($data['email'], "{$data['first_name']} {$data['last_name']}", $data);
			$data['is_send'] = $is_send;
			$wpdb->insert($this->table_form_submits, $data);
			wp_send_json(
				array(
					"status" => 1,
					"msg"    => $this->setting->notice_thanks
				)
			);
			wp_die();
		}
	}

	public function send_email ($email_send, $name_send, $data_send) {
		if(empty($this->setting) || (empty($this->setting->username_smtp) && empty($this->setting->password_smtp))) {
			return false;
		}

		require_once plugin_dir_path( __FILE__ ) . 'php-mailer/PHPMailer.php';
		require_once plugin_dir_path( __FILE__ ) . 'php-mailer/SMTP.php';

		$mail = new PHPMailer(true);

		try {
		    //Server settings
		    $mail->isSMTP();
		    $mail->Host       = 'smtp.gmail.com';
		    $mail->SMTPAuth   = true;
		    $mail->Username   = $this->setting->username_smtp;
		    $mail->Password   = $this->setting->password_smtp;
		    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		    $mail->Port       = 587;

		    //Recipients
		    $from_email = !empty($this->setting->from_email) ? $this->setting->from_email : $this->setting->username_smtp;
		    $mail->setFrom($from_email, $this->setting->from_name);
		    $mail->addAddress($email_send, $name_send);

		    // Content
		    $mail->isHTML(true);
		    $mail->Subject = $this->setting->subject_email;

		    $content = stripslashes(html_entity_decode($this->setting->message_email));
		    $parsed = preg_replace_callback('/{(.*?)}/', function ($matches) use ($data_send) {
			  	list($shortCode, $index) = $matches;
			  	if (isset($data_send[$index])) {
			    	return $data_send[$index];
			  	}
			}, $content);
			
		    $mail->Body = $parsed;

		    $mail->send();
		    return true;
		} catch (Exception $e) {
			return $mail->ErrorInfo;
		}
	}
}
