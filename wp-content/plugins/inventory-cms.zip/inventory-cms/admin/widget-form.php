<?php
// Creating the widget 
class WP_Widget_Form extends WP_Widget {
  
	function __construct() {
		parent::__construct(
		  
			// Base ID of your widget
			'WP_Widget_Form', 
			  
			// Widget name will appear in UI
			__('BT Inventory Widget Contact Form', 'wpb_widget_domain'), 
			  
			// Widget description
			array( 'description' => __( 'Form Receive More Info of BT Inventory Plugin', 'wpb_widget_domain' ), ) 
		);
	}
	  
	// Creating widget front-end
	public function widget( $args, $instance ) {
		global $wpdb;
		$title = apply_filters( 'widget_title', $instance['title'] );
		$setting = $wpdb->get_row("SELECT * FROM wp_bt_inventory_setting WHERE id = 1");
		ob_start();
		include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-admin-widget-form.php';
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}
	          
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = __( 'Title Form', 'wpb_widget_domain' );
		}
		// Widget admin form
		?>
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title Form:' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
		<?php 
	}
	      
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		return $instance;
	}
}