<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class Submit_Form_List extends WP_List_Table {

	private $table_form_submits;

	public function __construct() {
		global $wpdb;
		$this->table_form_submits = $wpdb->prefix . (defined( 'TABLE_FORM_SUBMITS' ) && TABLE_FORM_SUBMITS != '' ? TABLE_FORM_SUBMITS : 'bt_inventory_form_submits');

		parent::__construct( [
			'singular' => __( 'All Submit Form', 'sp' ), //singular name of the listed records
			'plural'   => __( 'All Submit Form', 'sp' ), //plural name of the listed records
			'ajax'     => false //does this table support ajax?
		] );
	}

	public function get_submit_forms( $per_page = 5, $page_number = 1 ) {
		global $wpdb;
		$sql = "SELECT * FROM {$this->table_form_submits} ";
		
		$where = 'WHERE 1';

		$search = isset($_POST['s']) ? $_POST['s']: '';
		if(!empty($search)) {
			$where .= " AND first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR phone LIKE '%$search%' OR email LIKE '%$search%' OR description LIKE '%$search%' ";
		}

		$sql .= $where;
		if (!empty($_REQUEST['orderby'])) {
			$sql .= ' ORDER BY ' . esc_sql($_REQUEST['orderby']);
			$sql .= !empty($_REQUEST['order']) ? ' ' . esc_sql($_REQUEST['order']) : ' ASC';
		}

		$sql .= " LIMIT $per_page";
		$sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;

		$result = $wpdb->get_results( $sql, 'ARRAY_A' );

		return $result;
	}

	public function record_count() {
		global $wpdb;

		$sql = "SELECT COUNT(*) FROM {$this->table_form_submits}";

		return $wpdb->get_var( $sql );
	}

	public function delete_customer( $id ) {
		global $wpdb;

		$wpdb->delete(
			"{$this->table_form_submits}",
			[ 'id' => $id ]
		);
	}

	public function prepare_items()	{
		$columns = $this->get_columns();
		$sortable = $this->get_sortable_columns();
		$hidden = $this->get_hidden_columns();
		$this->_column_headers = array($columns, $hidden, $sortable);

		/** Process bulk action */
		$this->process_bulk_action();

		$per_page     = $this->get_items_per_page( 'paged', 25 );
		$current_page = $this->get_pagenum();
		$total_items  = $this->record_count();

		$this->set_pagination_args( [
			'total_items' => $total_items,
			'per_page'    => $per_page
		] );

		$this->items = $this->get_submit_forms($per_page, $current_page);
	}

	public function get_sortable_columns() {
		$sortable_columns = array(
			'first_name'  => array( 'first_name', true ),
			'last_name'   => array( 'last_name', true ),
			'phone'       => array( 'phone', true ),
			'email'       => array( 'email', true ),
			'date_submit' => array( 'date_submit', true ),
		);

		return $sortable_columns;
	}

	public function get_hidden_columns() {
		return array();
	}

	public function get_columns() {
		$columns = [
			'cb'         => '<input type="checkbox" />',
			'first_name' => 'First Name',
			'last_name'  => 'Last Name',
			'phone'      => 'Phone',
			'email'      => 'Email',
			'description'=> 'Message',
			'date_submit'=> 'Date',
			'is_send'    => 'Send',
			'action'     => 'Action'
		];

		return $columns;
	}

	public function column_default($item, $column_name) {
		switch ($column_name) {
			case 'first_name':
			case 'last_name':
			case 'phone':
			case 'email':
			case 'description':
				return $item[$column_name];
				break;
			case 'date_submit':
				if(!empty($item[$column_name])) return date('m/d/Y', strtotime($item[$column_name]));
				else return '-';
				break;
			case 'is_send':
				if($item[$column_name]) return 'Success';
				else return 'Fail';
				break;
			case 'action':
				$delete_nonce = wp_create_nonce( 'sp_delete_row' );
				return sprintf( '<a class="inventory-cms-wp-delete" href="?post_type=%s&page=%s&action=%s&row_id=%s&_wpnonce=%s">Delete</a>', esc_attr( $_REQUEST['post_type'] ), esc_attr( $_REQUEST['page'] ), 'delete', absint( $item['id'] ), $delete_nonce );
			default:
				return "-";
		}
	}

	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="bt-bulk-delete[]" value="%s" />', $item['id']
		);
	}

	public function get_bulk_actions() {
		$actions = [
			'bt-bulk-delete' => 'Delete'
		];

		return $actions;
	}

	public function process_bulk_action() {
		//Detect when a bulk action is being triggered...
		if ( 'delete' === $this->current_action() ) {
			$nonce = esc_attr( $_REQUEST['_wpnonce'] );
			if (wp_verify_nonce( $nonce, 'sp_delete_row')) {
				$this->delete_customer(absint( $_GET['row_id']));
			}
		}

		// If the delete bulk action is triggered
		if ( ((isset($_POST['action']) && $_POST['action'] == 'bt-bulk-delete') || (isset($_POST['action2']) && $_POST['action2'] == 'bulk-delete')) && !empty($_POST['bt-bulk-delete']) ) {

			$delete_ids = esc_sql($_POST['bt-bulk-delete']);
			foreach ( $delete_ids as $id ) {
				$this->delete_customer( $id );
			}
		}
	}
}

function show_sumbmit_form_list_table() {
	$sumbmit_form_table = new Submit_Form_List();
	?>	
		<div class="wrap">
			<h1>Users Submitted</h1>
			<form method="POST" id="form-inventory-cms-wp-list">
				<?php
					$sumbmit_form_table->prepare_items();
					$sumbmit_form_table->search_box("Search", "search_submit_form");
					$sumbmit_form_table->display();
				?>
			</form>
		</div>
	<?php
}

show_sumbmit_form_list_table();