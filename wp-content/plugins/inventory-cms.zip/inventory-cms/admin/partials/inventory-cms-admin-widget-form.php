<?php
	$type_recaptcha = 0;
	$site_key_recaptcha = '';
	$secret_key_recaptcha = '';
	if(!empty($setting) && !empty($setting->type_recaptcha)) {
		$type_recaptcha = $setting->type_recaptcha;
	}

	if($type_recaptcha == 2 && !empty($setting->site_key_recaptcha_2) && !empty($setting->secret_key_recaptcha_2)) {
		$site_key_recaptcha   = $setting->site_key_recaptcha_2;
		$secret_key_recaptcha = $setting->secret_key_recaptcha_2;
	}

	if($type_recaptcha == 3 && !empty($setting->site_key_recaptcha_3) && !empty($setting->secret_key_recaptcha_3)) {
		$site_key_recaptcha   = $setting->site_key_recaptcha_3;
		$secret_key_recaptcha = $setting->secret_key_recaptcha_3;
	}

	//$isReCAPTCHA = !empty($setting) && !empty($setting->site_key_recaptcha) && !empty($setting->secret_key_recaptcha) ? true : false; 
?>
<div id="bt-form-widget" class="bt-form">
	<h4><?php echo $title; ?></h4>
	<form method="POST" action="<?php echo admin_url( 'admin-post.php' ); ?>" id="form-bti-more-info">
		<input type="hidden" name="action" value="submit_action_send_mail_more_info">
	  	<div class="bti-form-group">
		    <label for="first_name">First name: <sup><span class="bti-required">*</span></sup></label>
		    <input type="text" id="first_name" name="first_name" class="bti-form-control">
		    <div class="bt-invalid">First Name must only contain letters, min 2 and max 20 characters!</div>
	  	</div>
	  	<div class="bti-form-group">
		    <label for="last_name">Last name: <sup><span class="bti-required">*</span></sup></label>
		    <input type="text" id="last_name" name="last_name" class="bti-form-control">
		    <div class="bt-invalid">Last Name must only contain letters, min 2 and max 20 characters!</div>
	  	</div>
	  	<div class="bti-form-group">
		    <label for="phone">Phone:</label>
		    <input type="text" id="phone" name="phone" class="bti-form-control">
		    <div class="bt-invalid">Please enter a valid phone number in the format XXX-XXX-XXXX ext 123.</div>
	  	</div>
	  	<div class="bti-form-group">
		    <label for="email">Email: <sup><span class="bti-required">*</span></sup></label>
		    <input type="email" id="email" name="email" class="bti-form-control">
		    <div class="bt-invalid">The email address you entered is not valid.</div>
	  	</div>
	  	<div class="bti-form-group">
		    <label for="description">Message: <sup><span class="bti-required">*</span></sup></label>
		    <textarea id="description" name="description" class="bti-form-control" rows="4" cols="50"></textarea>
		    <div class="bt-invalid">This field is required.</div>
	  	</div>
	  	<?php if($type_recaptcha == 2) { ?>
		  	<div class="g-recaptcha" data-sitekey="<?php echo $site_key_recaptcha; ?>"></div>
		  	<div class="bt-invalid">Please complete the ReCaptcha field.</div>
		<?php } ?>
		<?php if($type_recaptcha == 3) { ?>
		  	<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response" value="">
		<?php } ?>
	  	<button type="button" id="btn-more-info" class="btn btn-single-boat">I Want More Info</button>
	  	<p class="form_required_fields_msg"><sup><span class="bti-required">*</span></sup> These fields are required.</p>
	</form>
</div>
