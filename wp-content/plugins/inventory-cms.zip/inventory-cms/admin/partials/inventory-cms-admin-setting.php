<div class="bt-wrap">
    <!-- Print the page title -->
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <!-- Here are our tabs -->
    <nav class="nav-tab-wrapper">
      <a href="?post_type=<?php echo $post_type ?>&page=<?php echo $name_plugin; ?>" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Settings</a>
      <a href="?post_type=<?php echo $post_type ?>&page=<?php echo $name_plugin; ?>&tab=contact-form" class="nav-tab <?php if($tab==='contact-form'):?>nav-tab-active<?php endif; ?>">Contact Form Settings</a>
      <a href="?post_type=<?php echo $post_type ?>&page=<?php echo $name_plugin; ?>&tab=single-boat" class="nav-tab <?php if($tab==='single-boat'):?>nav-tab-active<?php endif; ?>">Single Boat Settings</a>
    </nav>
    <div class="tab-content">
    	<?php if($tab===null) : ?>
	    	<div class="bt-setting bt-form bt-inventory-page-filter form-bt-setting">
				<h2><span class="dashicons dashicons-performance"></span>Settings</h2>
				<form action="javascript:void(0)" id="form-bt-setting-page">
					<div class="bti-form-group">
						<label for="api_key">API Key: <sup><span class="bti-required">*</span></sup></label>
					    <input type="text" name="api_key" class="bti-form-control" value="<?php if(!empty($setting->api_key)) { echo $setting->api_key; } ?>" required>
					    <div class="bt-invalid">This is field required.</div>
					</div>
					<div class="bti-form-group">
						<label for="slug">Page Slug: <sup><span class="bti-required">*</span></sup></label>
					    <input type="text" name="slug" class="bti-form-control" value="<?php if(!empty($setting->slug)) { echo $setting->slug; } ?>" required>
					    <div class="bt-invalid">This is field required.</div>
					</div>
					<div class="bti-form-group">
						<label for="slug">Inventory Page Title: <sup><span class="bti-required">*</span></sup></label>
					    <input type="text" name="name_default" class="bti-form-control" value="<?php if(!empty($setting->name_default)) { echo $setting->name_default; } ?>" required>
					    <div class="bt-invalid">This is field required.</div>
					</div>
					<div class="bti-form-group">
						<label for="row_limit">Listings Per Page: <sup><span class="bti-required">*</span></sup></label>
					    <input type="text" name="row_limit" class="bti-form-control" value="<?php if(!empty($setting->row_limit)) { echo $setting->row_limit; } ?>" required>
					    <div class="bt-invalid">This is field required.</div>
					</div>
					
					<div class="bti-form-group filter-position">
						<label for="filter_position">Filter position: </label>
						<div class="filter-box">
							<div class="bti-form-group">
								<input type="radio" name="filter_position" value="1" <?php if(!empty($setting->filter_position) && $setting->filter_position == 1) { echo "checked"; } ?>><label for="filter_position">Left</label><br>
							</div>
							<div class="bti-form-group">
								<input type="radio" name="filter_position" value="2" <?php if(!empty($setting->type_recaptcha) && $setting->filter_position == 2) { echo "checked"; } ?>><label for="filter_position">Top</label><br>
							</div>
						</div>
					</div>
					<div class="bti-row">
						<div class="bti-col-1">
							<div class="bti-form-group">
								<label for="primary_color">Primary Color: <sup><span class="bti-required">*</span></sup></label>
							    <input type="color" name="primary_color" value="<?php if(!empty($setting->primary_color)) { echo $setting->primary_color; } ?>">
							</div>
						</div>
						<div class="bti-col-1">
							<div class="bti-form-group">
								<label for="primary_color_btn">Button Color: <sup><span class="bti-required">*</span></sup></label>
							    <input type="color" name="primary_color_btn" value="<?php if(!empty($setting->primary_color_btn)) { echo $setting->primary_color_btn; } ?>">
							</div>
						</div>
					</div>					
					<div class="bti-form-group">
						<label for="slug">BT Inventory Filter Option:</label>
						<?php if(!empty($field_filters)) {
								echo '<ul id="bt-inventory-sortable" class="bt-inventory-ui-sortable" name="filters">';
								foreach ($field_filters as $field) {
									if($field->field_key == 'boattype') continue;
									$html_li = '<li class="bt-inventory-sort-item ' . (!empty($field->sort) ?  'active' : '') .'" data-key="' . $field->field_key .'"><span class="dashicons' . (!empty($field->sort) ?  ' dashicons-yes-alt' : '') .'"></span>' . $field->field_value;

									if(!empty($field->sort)) {
										$html_li .= '<input type="hidden" name="filters[]" value="' . $field->field_key . '">';
									}

									$html_li .= '</li>';
									echo $html_li;
								}
								echo '</ul>';
							}
						?>
					</div>
					<div class="bti-form-group">
						<label for="slug">BT Inventory Sort Option:</label>
						<?php if(!empty($field_sorts)) {
								echo '<ul id="bt-inventory-option-sortable" class="bt-inventory-ui-sortable" name="sorts">';
								foreach ($field_sorts as $field) {
									if($field->field_key == 'boattype') continue;
									$html_li = '<li class="bt-inventory-sort-item ' . (!empty($field->sort) ?  'active' : '') .'" data-key="' . $field->field_key .'"><span class="dashicons' . (!empty($field->sort) ?  ' dashicons-yes-alt' : '') .'"></span>' . $field->field_value;

									if(!empty($field->sort)) {
										$html_li .= '<input type="hidden" name="sorts[]" value="' . $field->field_key . '">';
									}

									$html_li .= '</li>';
									echo $html_li;
								}
								echo '</ul>';
							}
						?>
					</div>
					<button type="submit" class="btn btn-submit">Save</button>
				</form>
			</div>
		<?php endif; ?>
		<?php if($tab==='contact-form') : ?>
	    	<div class="bt-form bt-inventory-page-filter form-bt-setting">
				<form action="javascript:void(0)" id="form-bt-setting-recaptcha">
					<h2><span class="dashicons dashicons-admin-network"></span>reCAPTCHA</h2>
					<div class="bti-row">
						<div class="bti-col-6">
							<div class="bti-form-group">
								<input type="radio" name="recaptcha" value="2" <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 2) { echo "checked"; } ?>><label for="recaptcha">reCAPTCHA V2</label><br>
							</div>
							<div class="bti-form-group">
								<label for="api_key">Site Key: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="site_key_recaptcha_2" class="bti-form-control" value="<?php if(!empty($setting->site_key_recaptcha_2)) { echo $setting->site_key_recaptcha_2; } ?>" required <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 3) { echo "disabled"; } ?>>
							    <div class="bt-invalid">This is field required.</div>
							</div>
							<div class="bti-form-group">
								<label for="slug">Secret Key: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="secret_key_recaptcha_2" class="bti-form-control" value="<?php if(!empty($setting->secret_key_recaptcha_2)) { echo $setting->secret_key_recaptcha_2; } ?>" required <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 3) { echo "disabled"; } ?>>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
						<div class="bti-col-6">
							<div class="bti-form-group">
								<input type="radio" name="recaptcha" value="3" <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 3) { echo "checked"; } ?>><label for="recaptcha">reCAPTCHA V3</label><br>
							</div>
							<div class="bti-form-group">
								<label for="api_key">Site Key: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="site_key_recaptcha_3" class="bti-form-control" value="<?php if(!empty($setting->site_key_recaptcha_3)) { echo $setting->site_key_recaptcha_3; } ?>" required <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 2) { echo "disabled"; } ?>>
							    <div class="bt-invalid">This is field required.</div>
							</div>
							<div class="bti-form-group">
								<label for="slug">Secret Key: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="secret_key_recaptcha_3" class="bti-form-control" value="<?php if(!empty($setting->secret_key_recaptcha_3)) { echo $setting->secret_key_recaptcha_3; } ?>" required <?php if(!empty($setting->type_recaptcha) && $setting->type_recaptcha == 2) { echo "disabled"; } ?>>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
					</div>
					
					<h2><span class="dashicons dashicons-email"></span></span>Notification</h2>
					<div class="bti-row">
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">Username SMTP: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="username_smtp" class="bti-form-control" value="<?php if(!empty($setting->username_smtp)) { echo $setting->username_smtp; } ?>" required>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">Password SMTP: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="password_smtp" class="bti-form-control" value="<?php if(!empty($setting->password_smtp)) { echo $setting->password_smtp; } ?>" required>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
					</div>
					<div class="bti-row">
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">From Name:</label>
							    <input type="text" name="from_name" class="bti-form-control" value="<?php if(!empty($setting->from_name)) { echo $setting->from_name; } ?>">
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">From Email:</label>
							    <input type="text" name="from_email" class="bti-form-control" value="<?php if(!empty($setting->from_email)) { echo $setting->from_email; } ?>">
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
					</div>
					<div class="bti-row">
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">Subject: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="subject_email" class="bti-form-control" value="<?php if(!empty($setting->subject_email)) { echo $setting->subject_email; } ?>" required>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
						<div class="bti-col-6">
							<div class="bti-form-group">
								<label for="slug">Notice - Thank you: <sup><span class="bti-required">*</span></sup></label>
							    <input type="text" name="notice_thanks" class="bti-form-control" value="<?php if(!empty($setting->notice_thanks)) { echo $setting->notice_thanks; } ?>" required>
							    <div class="bt-invalid">This is field required.</div>
							</div>
						</div>
					</div>
					<div class="bti-row">
						<div class="bti-col-12">
							<div class="bti-form-group">
								<label for="slug">Message: <sup><span class="bti-required">*</span></sup> - Support keyword: {first_name}, {last_name}, {phone}, {email}</label>
							    <?php 
							    	$msg = !empty($setting->message_email) ? stripslashes(html_entity_decode($setting->message_email)) : '';
								    wp_editor($msg,
									    'message_email',
									   	array(
									      	'media_buttons' => true,
									      	'textarea_rows' => 8,
									      	'tabindex' => 4,
									      	'tinymce' => array(
									        	'theme_advanced_buttons1' => 'bold, italic, ul, min_size, max_size',
									        	'theme_advanced_buttons2' => 'buttons',
									      	),
									    )
								   	);
								?>
							</div>
						</div>
					</div>
					
					<button type="submit" class="btn btn-submit">Save</button>
				</form>
			</div>
		<?php endif; ?>
		<?php if($tab==='single-boat') : ?>
	    	<div class="bt-setting bt-form bt-inventory-page-filter form-bt-setting">
				<form action="javascript:void(0)" id="form-bt-setting-single-boat">
					<div class="bti-form-group">
						<label for="slug">Permalink: <sup><span class="bti-required">*</span></sup></label>
					    <div id="sample-permalink">
					    	<a href="javascript:void(0)" class="text-decoration-none"><?php echo site_url('/'); ?></a>
					    	<div class="box-permalink">
					    		<input type="text" class="bti-form-control" name="slug_single" value="<?php if(!empty($setting->slug_single)) { echo $setting->slug_single; } ?>">
					    		<?php
					    			//'boats/
					    			echo '/';
					    			$params = !empty($setting->single_params) ? unserialize($setting->single_params) : [];
						    		if(!empty($fields)) {
										for($i = 0; $i < 3; $i++) {
											echo '<strong><select class="bti-form-control" name="params[]">';
											foreach ($fields as $field) {
												echo '<option value="none">None</option>';
												if($field->field_key_api == 'NormPrice' || $field->field_key_api == 'NormNominalLength') continue;
												if(in_array($field->field_key_api, $params) && $params[$i] == $field->field_key_api) {

													echo '<option value="' . $field->field_key_api . '" selected>' . $field->field_value . '</option>';
													continue;
												}
												echo '<option value="' . $field->field_key_api . '">' . $field->field_value . '</option>';
											}
											echo '</select></strong>-';
										}
										echo 'id';
									}
					    		?>
					    	</div>
				    	</div>
					</div>
					<div class="bti-form-group">
						<label for="slug">Attributes:</label>
						<?php if(!empty($field_attributes)) { ?>
						    <ul id="bt-inventory-single-sortable" class="bt-inventory-ui-sortable" name="sorts">
								<?php
									$single_attributes = !empty($setting->single_attributes) ? unserialize($setting->single_attributes) : [];
									foreach($single_attributes as $attribute) {
										$field = $field_attributes[$attribute];
										if($field->field_key == 'boattype') continue;
										$html_li = '<li class="bt-inventory-sort-item active" data-key="' . $field->field_key .'"><span class="dashicons dashicons-yes-alt"></span>' . $field->field_value . '<input type="hidden" name="sorts[]" value="' . $field->field_key . '">';
										$html_li .= '</li>';
										echo $html_li;
									}
									foreach ($field_attributes as $key => $field) {
										if(!in_array($field->field_key, $single_attributes) && $field->field_key != 'boattype') {
											$html_li = '<li class="bt-inventory-sort-item" data-key="' . $field->field_key .'"><span class="dashicons"></span>' . $field->field_value;

											if(!empty($field->sort)) {
												$html_li .= '<input type="hidden" name="sorts[]" value="' . $field->field_key . '">';
											}

											$html_li .= '</li>';
											echo $html_li;
										}
										
									}
								?>
							</ul>
						<?php } ?>
					</div>
					<div class="bti-form-group">
						<label for="slug">Disclaimer: </label>
					   	<textarea name="single_disclaimer" class="bti-form-control" rows="4"><?php if(!empty($setting->single_disclaimer)) { echo $setting->single_disclaimer; } ?></textarea>
					    <div class="bt-invalid">This is field required.</div>
					</div>
					<button type="submit" class="btn btn-submit">Save</button>
				</form>
			</div>
		<?php endif; ?>
    </div>
</div>