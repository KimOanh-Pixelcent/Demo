<?php if(!empty($instance['bti_contact_address']) || !empty($instance['bti_contact_phone']) || !empty($instance['bti_contact_hours'])) : ?>
<div class="bt-widget-contact">
	<h4><?php echo $instance['title']; ?></h4>
	<ul class="bti-contact-list">
		<?php if(!empty($instance['bti_contact_address'])) : ?>
		<li>
			<div class="bti-icon"><i class="stm-icon-pin">&nbsp;</i></div>
			<div class="bti-text"><?php echo $instance['bti_contact_address']; ?></div>
		</li>
		<?php
			endif;
			if(!empty($instance['bti_contact_phone'])) :
		?>
		<li>
			<div class="bti-icon"><i class="stm-service-icon-sales_phone">&nbsp;</i></div>
			<div class="bti-text"><?php echo $instance['bti_contact_phone']; ?></div>
		</li>
		<?php
			endif;
			if(!empty($instance['bti_contact_hours'])) :
		?>
		<li>
			<div class="bti-icon"><i class="stm-service-icon-sales_hours">&nbsp;</i></div>
			<div class="bti-text"><?php echo $instance['bti_contact_hours']; ?></div>
		</li>
		<?php endif; ?>
	</ul>
</div>
<?php endif; ?>