<?php
class WP_Widget_Contact extends WP_Widget {
  
	function __construct() {
		parent::__construct(
		  
			// Base ID of your widget
			'WP_Widget_Contact', 
			  
			// Widget name will appear in UI
			__('BT Inventory Widget Contact', 'wpb_widget_domain'), 
			  
			// Widget description
			array( 'description' => __( 'Contact of BT Inventory Plugin', 'wpb_widget_domain' ), ) 
		);
	}
	  
	// Creating widget front-end
	public function widget( $args, $instance ) {
		ob_start();
		include_once plugin_dir_path( __FILE__ ) .'partials/inventory-cms-admin-widget-contact.php';
		$template = ob_get_contents();
		ob_end_clean();
		echo $template;
	}
	          
	// Widget Backend 
	public function form( $instance ) {
		if ( isset( $instance[ 'title' ] ) ) {
			$title = $instance[ 'title' ];
		}
		else {
			$title = __( 'Title', 'wpb_widget_domain' );
		}
		// Widget admin form
		?>
			<p>
				<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'bti_contact_address' ); ?>"><?php _e( 'Contact Address:' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'bti_contact_address' ); ?>" name="<?php echo $this->get_field_name( 'bti_contact_address' ); ?>" type="text" value="<?php if(!empty($instance[ 'bti_contact_hours'])) { echo esc_attr( $instance[ 'bti_contact_address'] ); } ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'bti_contact_phone' ); ?>"><?php _e( 'Contact Phone:' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'bti_contact_phone' ); ?>" name="<?php echo $this->get_field_name( 'bti_contact_phone' ); ?>" type="text" value="<?php if(!empty($instance[ 'bti_contact_hours'])) { echo esc_attr( $instance[ 'bti_contact_phone'] ); } ?>" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id( 'bti_contact_hours' ); ?>"><?php _e( 'Contact Hours:' ); ?></label> 
				<input class="widefat" id="<?php echo $this->get_field_id( 'bti_contact_hours' ); ?>" name="<?php echo $this->get_field_name( 'bti_contact_hours' ); ?>" type="text" value="<?php if(!empty($instance[ 'bti_contact_hours'])) { echo esc_attr( $instance[ 'bti_contact_hours'] ); } ?>" />
			</p>
		<?php 
	}
	      
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] 				 = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['bti_contact_phone']   = ( ! empty( $new_instance['bti_contact_phone'] ) ) ? strip_tags( $new_instance['bti_contact_phone'] ) : '';
		$instance['bti_contact_hours']   = ( ! empty( $new_instance['bti_contact_hours'] ) ) ? strip_tags( $new_instance['bti_contact_hours'] ) : '';
		$instance['bti_contact_address'] = ( ! empty( $new_instance['bti_contact_address'] ) ) ? strip_tags( $new_instance['bti_contact_address'] ) : '';
		return $instance;
	}
}