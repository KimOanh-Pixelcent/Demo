(function( jQuery ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * jQuery function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * jQuery(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * jQuery( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
    jQuery(document).ready(function () {
    	var ajaxUrl = bt_inventory.ajax_url;

    	/* BT Inventory Filter */
        let key_selected = '';
        let val_selected = '';
    	jQuery(document).on("change", "#bt-inventory-field", function() {
            key_selected = jQuery(this).children("option:selected").val();
            val_selected = jQuery(this).children("option:selected").html();
    		ajax_filter(key_selected, val_selected);
        });

        jQuery(document).on("click", ".close-alert", function() {
            jQuery("#bt-inventory-field").children("option:selected").attr("disabled", false);
        	jQuery(".bt-inventory-page-filter .page-filter-content .alert").hide();
        });

        jQuery(document).on("click", "#btn-update-filter", function() {
            let key = key_selected;
            let val = val_selected;
    		
            let sign = ",";
            let value_filter = '';
            if(key == 'length') {
                value_filter = jQuery("#"+key).children("option:selected").val();
            }
            
            if(key == 'price') {
                sign = ":";
                let min_price = jQuery("input[name*='min_price']").val();
                let max_price = jQuery("input[name*='max_price']").val();
                if(!min_price || !max_price) {
                    alert('Please select the value first.');
                    return;
                }
                
                value_filter = [min_price, max_price];
            }

            if(key != 'length' && key != 'price') {
                value_filter = jQuery("#bt-inventory-filter-select").select2('data');
                if(value_filter.length) {
                    value_filter = value_filter.map(item => item.id)
                } else {
                    value_filter = null
                }
            }
            
            if(!value_filter) {
                alert('Please select the value first.');
                return;
            }

            if(!jQuery("input[name='post_filters']").length) {
                jQuery("#list-filter-tag").append("<input type='hidden' name='post_filters' value=''/>");
            }
            let post_filters = jQuery("input[name='post_filters']").val();
            if(!post_filters) {
                post_filters = [];
            }

            if(post_filters && typeof post_filters == 'string') {
                post_filters = JSON.parse(post_filters);
            }

            let key_exists = -1;
            if(post_filters.length > 0) {
                post_filters.forEach((item, index) => {
                    if(typeof item == 'string') {
                        item = JSON.parse(item);
                    }

                    if(item.hasOwnProperty(key)) {
                        key_exists = index;
                        return;
                    }
                })
            }

            let value_input = {[key]: value_filter};
            if(key_exists >= 0) {
                post_filters[key_exists] = value_input;
                jQuery("."+key).remove();
            } else {
                post_filters.push(JSON.stringify(value_input));
            }

            let textHtml = val + ': ';
            if(typeof value_filter == 'object') {
                textHtml += '<u><strong>' + value_filter.join(sign) + '</strong></u>';
            } else {
                textHtml += '<u><strong>' + value_filter + '</strong></u>';
            }


            let html = "<div class='filter-tag "+ key +"' id='"+key+"' data-text='"+val+"'><span>" + textHtml +"</span><input type='hidden' name='page_filters[]' value='" + JSON.stringify(value_input) +"' /><button type='button' class='btn-close tag-close'>×</button></div>";
            jQuery("#list-filter-tag").append(html);
            jQuery("input[name='post_filters']").val(JSON.stringify(post_filters));
            action_list_tag();
            action_del_tag();

    		/*reset filter*/
    		jQuery(".bt-inventory-page-filter .page-filter-content .alert").hide();
        	jQuery("#bt-inventory-field").val("None");
        });

        var action_del_tag = function() {
            jQuery( ".tag-close" ).on("click", function(e) {
                jQuery(this).parent(".filter-tag").remove();
                e.preventDefault();
            });
        };

        action_del_tag();

        var ajax_filter = function(key, val, set_val = '') {
            jQuery(".bt-inventory-page-filter .page-filter-content #bt-inventory-filter-ajax").html("");
            jQuery(".bt-inventory-page-filter .page-filter-content .alert").hide();
            jQuery(".bt-inventory-page-filter .page-filter-content .alert #field-choosen").html(val);
            jQuery(".bt-loader").removeClass("bt-d-none");

            let html = '';
            if(key != 'price' && key != 'length') {
                let postData = "&action=bt_inventory_ajax_field_data&param=field_data_inventory_ajax&field=" + key;
                jQuery.post(ajaxUrl, postData, function(response) {
                    if(response.data && response.data.length > 0) {
                        html = '<label for="' + key + '">Select the optional filter</label><input type="hidden" id="bt-inventory-filter-select" />';
                        jQuery(".bt-inventory-page-filter .page-filter-content #bt-inventory-filter-ajax").html(html);

                        let data = [];
                        for(let i = 0; i < response.data.length; i++) {
                            data.push({
                                id: response.data[i],
                                text: response.data[i]
                            });
                        }
                        
                        jQuery(".bt-inventory-page-filter .page-filter-content .alert").show();
                        jQuery(".bt-loader").addClass("bt-d-none");
                        jQuery('#bt-inventory-filter-select').select2({
                            data: data,
                            multiple: true,
                            maximumSelectionLength: 3,
                            placeholder: val,
                            allowClear: true
                        });
                        if(set_val) {
                            jQuery('#bt-inventory-filter-select').val(set_val).trigger('change');
                        }
                        return;
                    }
                    jQuery(".bt-loader").addClass("bt-d-none");
                    if(response.status == 0) {
                        alert(response.msg);
                        return;
                    }
                    alert("An error has occurred. Please try again.");
                })
                return;
            }

            if(key == 'price') {
                let val_min = 0;
                let val_max = '&infin';
                if(set_val && typeof set_val == 'object' && set_val.length == 2) {
                    val_min = set_val[0];
                    val_max = set_val[1];
                }
                html = '<div class="filter-ajax-item"><label for="min_price">Minimum Price</label><input type="text" name="min_price" value="'+val_min+'" /></div>';
                html += '<div class="filter-ajax-item"><label for="max_price">Maximum Price</label><input type="text" name="max_price" value="'+val_max+'" /></div>';
            }

            if(key == 'length') {
                let boat_length = [{
                        value: '0:200',
                        text: 'Boat Length'
                    },
                    {
                        value: '0:10',
                        text: '1 - 10ft'
                    },
                    {
                        value: '10:20',
                        text: '10 - 20ft'
                    },
                    {
                        value: '20:30',
                        text: '20 - 30ft'
                    },{
                        value: '30:40',
                        text: '30 - 40ft'
                    },
                    {
                        value: '40:50',
                        text: '40 - 50ft'
                    }];

                html = '<label for="' + key + '">Select the optional filter</label>';
                html += '<select name="' + key + '" id="' + key + '">';
                for(let i = 0; i < boat_length.length; i++) {
                    html += '<option value="' + boat_length[i].value + '"';
                    if(set_val && set_val == boat_length[i].value) {
                        html += 'selected="selected"';
                    }
                    
                    html += '>' + boat_length[i].text + '</option>';
                }
                html += '</select';
            }

            jQuery(".bt-inventory-page-filter .page-filter-content #bt-inventory-filter-ajax").html(html);
            jQuery(".bt-inventory-page-filter .page-filter-content .alert").show();
            jQuery(".bt-loader").addClass("bt-d-none");
        };

        var action_list_tag = function() {
            jQuery( "#list-filter-tag .filter-tag" ).on("click", function() {
                key_selected = jQuery(this).attr("id");
                val_selected = jQuery(this).attr("data-text");
                let val_input = jQuery(this).children('input[name="page_filters[]"]').val();
                val_input = JSON.parse(val_input);
                let set_val = val_input[key_selected];
                ajax_filter(key_selected, val_selected, set_val);
            });
        };

        action_list_tag();

    	/* BT Inventory Filter Options */
        if(jQuery( "#bt-inventory-sortable" ).length) {
            jQuery( "#bt-inventory-sortable" ).sortable();
            jQuery( "#bt-inventory-sortable" ).disableSelection();
        }
    	
        if(jQuery( "#bt-inventory-option-sortable" ).length) {
            jQuery( "#bt-inventory-option-sortable" ).sortable();
            jQuery( "#bt-inventory-option-sortable" ).disableSelection();
        }

        let bt_inventory_single_sortable = "#bt-inventory-single-sortable";
        if(jQuery( bt_inventory_single_sortable ).length) {
            jQuery( bt_inventory_single_sortable ).sortable();
            jQuery( bt_inventory_single_sortable ).disableSelection();
        }

        jQuery(document).on("mouseover", ".bt-inventory-ui-sortable .bt-inventory-sort-item", function() {
        	let cls = jQuery(this).attr("class");
        	if(cls.indexOf("active") != -1) {
        		jQuery(this).children("span").addClass("dashicons-dismiss");
        		jQuery(this).children("span").removeClass("dashicons-yes-alt");
        	}

        	if(cls.indexOf("active") == -1) {
        		jQuery(this).children("span").addClass("dashicons-plus-alt");
        		jQuery(this).children("span").css("display", "inline-block");
        	}
        });

        jQuery(document).on("mouseout", ".bt-inventory-ui-sortable .bt-inventory-sort-item", function() {
        	let cls = jQuery(this).attr("class");
        	jQuery(this).children("span").removeClass("dashicons-dismiss");
        	jQuery(this).children("span").removeClass("dashicons-plus-alt");
        	if(cls.indexOf("active") == -1) {
        		jQuery(this).children("span").css("display", "none");
        	}

        	if(cls.indexOf("active") != -1) {
    	    	jQuery(this).children("span").addClass("dashicons-yes-alt");
        	}
        });

        jQuery(document).on("click", ".bt-inventory-ui-sortable .bt-inventory-sort-item", function() {
        	let cls = jQuery(this).attr("class");
        	jQuery(this).children("span").removeClass("dashicons-dismiss");
        	jQuery(this).children("span").removeClass("dashicons-plus-alt");

        	/* add input hidden for submit sort and filter */
        	let name_parent = jQuery(this).parent("ul").attr("name");
        	if(jQuery(this).children("input[name*='" + name_parent + "[]']")) {
        		jQuery(this).children("input[name*='" + name_parent + "[]']").remove("");
        	}

        	if(cls.indexOf("active") == -1) {
        		if(jQuery(this).attr("data-key")) {
        			jQuery(this).append('<input type="hidden" name="' + name_parent +'[]" value="' + jQuery(this).attr("data-key") + '" />');
        		}
        		
        		jQuery(this).children("span").addClass("dashicons-dismiss");
        	}

        	if(cls.indexOf("active") != -1) {
        		jQuery(this).children("span").addClass("dashicons-plus-alt");
        	}
        	jQuery(this).toggleClass("active");
        });

        /*Setting*/
        jQuery(".form-bt-setting form input[type*='text']").keyup(function() {
            if(jQuery(this).val() && jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
                jQuery(this).next(".bt-invalid").removeClass("bt-invalid-error")
            }

            if(!jQuery(this).val() && !jQuery(this).next(".bt-invalid").hasClass("bt-invalid-error")) {
                jQuery(this).next(".bt-invalid").addClass("bt-invalid-error")
            } 
        });

        var ajaxSetting = function(ajax_url, form_id, action, param) {
            var post_data = jQuery("#" + form_id).serialize();
            post_data += "&action=" + action +"&param=" + param;

            if(!jQuery("#" + form_id).hasClass("bt-form-validate")) {
                jQuery("#" + form_id).addClass("bt-form-validate");
            }
           
            let isCheck = true;
            for (const obj of jQuery("#" + form_id).serializeArray()) {
                jQuery("input[name*='" + obj.name + "'").next('.bt-invalid').removeClass("bt-invalid-error");
                if(!obj.value && jQuery("input[name*='" + obj.name + "'").prop('required')) {
                    isCheck = false;
                    jQuery("input[name*='" + obj.name + "'").next('.bt-invalid').addClass("bt-invalid-error");
                }
            }

            if(isCheck) {
                jQuery("#" + form_id).removeClass("bt-form-validate");
                jQuery.post(ajax_url, post_data, function(response) {
                    if(response.hasOwnProperty('msg')) {
                        alert(response.msg);
                        return;
                    }
                    alert("Failed!");
                });
            }
        };

        jQuery("input[type='radio'][name='recaptcha']").change(function() {
            let val = this.value;
            if(val == 2 || val == 3) {
                jQuery("input[type='text'][name='secret_key_recaptcha_"+val+"']").attr("disabled", false);
                jQuery("input[type='text'][name='site_key_recaptcha_"+val+"']").attr("disabled", false);

                if(val == 2) val = 3
                else val = 2;

                jQuery("input[type='text'][name='secret_key_recaptcha_"+val+"']").attr("disabled", true);
                jQuery("input[type='text'][name='site_key_recaptcha_"+val+"']").attr("disabled", true);
               
            }
        });

        jQuery("#form-bt-setting-page").submit(function() {
            ajaxSetting(ajaxUrl, 'form-bt-setting-page', 'bt_inventory_ajax_field_data', 'update_setting');
        });

        jQuery("#form-bt-setting-recaptcha").submit(function() {
            ajaxSetting(ajaxUrl, 'form-bt-setting-recaptcha', 'bt_inventory_ajax_field_data', 'update_setting_recaptcha');
        });

        jQuery("#form-bt-setting-single-boat").submit(function() {
            ajaxSetting(ajaxUrl, 'form-bt-setting-single-boat', 'bt_inventory_ajax_field_data', 'update_setting_single_boat');
        });

        jQuery(document).on("click", ".inventory-cms-wp-delete", function(e) {
            e.preventDefault();
            if (confirm("Are you sure you want to delete this item?")) {
                window.location = jQuery(this).attr("href");
            }
        })

        jQuery(document).on("click", "#form-inventory-cms-wp-list #doaction", function(e) {
            //#bulk-action-selector-top
            if(jQuery('#form-inventory-cms-wp-list #bulk-action-selector-top').val() == 'bt-bulk-delete') {
                e.preventDefault();
                if (confirm("Are you sure you want to delete items?")) {
                    jQuery("#form-inventory-cms-wp-list").submit();
                }
            }
        })
    });
    
})( jQuery );
